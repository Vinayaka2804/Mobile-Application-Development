/*
Name : Group : 43
    Bharath P
    Vinayaka Narayan


 */


package com.example.vnara.bloodalocholcontent;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    String gender = "M";
    double savedBac=0.00;
    Map<String,Double> saveWeightGender = new HashMap<String,Double>();
    int savedWeight;
    int ounces = 1;
    int alcoholpercent=5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //getSupportActionBar().setDisplayShowHomeEnabled(true);
        //getSupportActionBar().setIcon(R.drawable.);
        setContentView(R.layout.activity_main);

        //seekbar
        SeekBar seek = (SeekBar) findViewById(R.id.seekBar);
        seek.setMax(25);
            if (seek != null) {
            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
                {
                    int yourStep=5;
                    progress = ((int)Math.round(progress/yourStep ))*yourStep;
                    TextView seekBarValue = (TextView) findViewById(R.id.slidertext);
                    seekBarValue.setText(progress+"%");
                    alcoholpercent = progress;
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                }
            } );

        }
        //seebar

        //Gender selection
        Switch s = (Switch) findViewById(R.id.switch1);
        s.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    gender = "F";
                } else {
                    gender = "M";
                }
            }
        });
        //gender selection

        //radio buttons
        RadioGroup radiobtn= (RadioGroup) findViewById(R.id.radioGroup);
        radiobtn.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
               if(checkedId==R.id.radioButton1){ ounces = 1;}
                if(checkedId==R.id.radioButton2){ ounces = 5;}
                if(checkedId==R.id.radioButton3){ounces = 12;}
            }
        });

        //save Button
        final Button saveButton = (Button) findViewById(R.id.savebutton);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               TextView enteredweight= (TextView) findViewById(R.id.weight);
                if(enteredweight.getText().length() == 0) {
                    enteredweight.setError("Enter the weight in lbs");
                } else {
                    savedWeight = Integer.valueOf(enteredweight.getText().toString());
                    if(!saveWeightGender.containsKey(gender.concat(",").concat(Integer.valueOf(savedWeight).toString()))) {
                        saveWeightGender.put(gender.concat(",").concat(Integer.valueOf(savedWeight).toString()), 0.00);
                    }
                }
            }
            //Save Button
        });

        //Add Drink Button
        Button addDrinkButton = (Button) findViewById(R.id.addDrinkButton);
        addDrinkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /* A = Drink size * alcohol percent
                 w= weight
                r = gender, r= 0.68 for male , r =0.55 for women
                 BAC= ((A* 6.24)/(w*R))*/
                TextView enteredweight = (TextView) findViewById(R.id.weight);
                //Log.d("value is", enteredweight.getText().toString());
                if((enteredweight.getText().length() == 0) || (saveWeightGender.isEmpty())) {
                    enteredweight.setError("Enter the weight in lbs");
                } else {
                    if(saveWeightGender.containsKey(gender.concat(",").concat(Integer.valueOf(savedWeight).toString()))) {
                        savedBac = saveWeightGender.get(gender.concat(",").concat(Integer.valueOf(savedWeight).toString()));
                    }
                    if (gender == "M") {
                        double bacValue = ((alcoholpercent * 6.24 * 0.01) / (savedWeight * 0.68));
                        savedBac = savedBac + bacValue;
                        saveWeightGender.put(gender.concat(",").concat(Integer.valueOf(savedWeight).toString()), savedBac);
                        TextView bac = (TextView) findViewById(R.id.bac);
                        bac.setText(Double.valueOf(Math.round(savedBac * 100) / 100D).toString());
                    } else {
                        double bacValue = ((alcoholpercent * 6.24 * 0.01) / (savedWeight * 0.55));
                        savedBac = savedBac + bacValue;
                        saveWeightGender.put(gender.concat(",").concat(Integer.valueOf(savedWeight).toString()), savedBac);
                        TextView bac = (TextView) findViewById(R.id.bac);
                        bac.setText(Double.valueOf(Math.round(savedBac * 100) / 100D).toString());
                    }

                    savedBac = saveWeightGender.get(gender.concat(",").concat(Integer.valueOf(savedWeight).toString()));
                    ProgressBar mProgress = (ProgressBar) findViewById(R.id.progressBar);
                    Double d = new Double(savedBac);
                    int i = (int) (d * 100);
                    int progress_value = i;
                    mProgress.setProgress(progress_value);

                    if (savedBac >= 0.25) {
                        //Enable/disable
                        Button saveButton = (Button) findViewById(R.id.savebutton);
                        Toast.makeText(getApplicationContext(),"No more drinks for you", Toast.LENGTH_LONG).show();
                        if (saveButton.isEnabled())
                        {
                            saveButton.setEnabled(false);
                        }
                        Button addButton = (Button) findViewById(R.id.addDrinkButton);
                        if (addButton.isEnabled())
                        {
                            addButton.setEnabled(false);
                        }
                        //Enable
                    }

                    if (savedBac > 0.08 && savedBac <= 0.20) {
                        ((TextView) findViewById(R.id.status)).setText("Be Careful...");
                        ((TextView) findViewById(R.id.status)).setBackgroundColor(Color.parseColor("yellow"));
                    } else if (savedBac > 0.20) {
                        ((TextView) findViewById(R.id.status)).setText("Over The Limit");
                        ((TextView) findViewById(R.id.status)).setBackgroundColor(Color.parseColor("red"));
                    } else {
                        ((TextView) findViewById(R.id.status)).setText("You're safe");
                        ((TextView) findViewById(R.id.status)).setBackgroundColor(Color.parseColor("green"));
                    }
                }
            }

        });

      Button resetButton = (Button) findViewById(R.id.reset);
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioGroup rb = (RadioGroup) findViewById(R.id.radioGroup);
                rb.clearCheck();
                rb.check(R.id.radioButton1);
                ((SeekBar) findViewById(R.id.seekBar)).setProgress(5);
                ((TextView)findViewById(R.id.weight)).setText("");
                ((Switch)findViewById(R.id.switch1)).setChecked(false);

                //Enable/disable
                Button saveButton = (Button) findViewById(R.id.savebutton);
                if(!saveButton.isEnabled()) {
                    saveButton.setEnabled(true);
                }
                Button addButton = (Button) findViewById(R.id.addDrinkButton);
                if(!addButton.isEnabled()) {
                    addButton.setEnabled(true);
                }
                ((TextView)findViewById(R.id.bac)).setText("0.00");
                TextView enteredweight= (TextView) findViewById(R.id.weight);
                enteredweight.setError(null);
                ((TextView)findViewById(R.id.slidertext)).setText("5%");
                ProgressBar mProgress =(ProgressBar) findViewById(R.id.progressBar);
                mProgress.setProgress(0);

                ((TextView) findViewById(R.id.status)).setText("You're safe");
                ((TextView) findViewById(R.id.status)).setBackgroundColor(Color.parseColor("green"));

                savedBac=0.00;
                ounces = 1;
                saveWeightGender = new HashMap<String, Double>();
                gender = "M";
                //Enable
            }
        });
    }
}
