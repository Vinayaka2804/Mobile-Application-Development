package com.example.vnara.bloodalocholcontent;

import java.io.Serializable;

/**
 * Created by vnara on 9/1/2016.
 */
public class BacStatistics implements Serializable {

    private String gender;
    private int weight;
    private double savedBac;


    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public double getSavedBac() {
        return savedBac;
    }

    public void setSavedBac(double savedBac) {
        this.savedBac = savedBac;
    }
}
