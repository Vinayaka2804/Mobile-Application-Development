package com.example.vinayakanarayan.itunespodcast;

import android.os.AsyncTask;
import android.util.Log;

import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by Vinayaka Narayan on 10/3/2016.
 */
public class iTuneAsyncTask extends AsyncTask<String,Void,ArrayList<iTunes>> {

    DataRetreiver activity;


    public iTuneAsyncTask(DataRetreiver activity) {
        this.activity=activity;

    }

    @Override
    protected ArrayList<iTunes> doInBackground(String... params) {
        try {

            URL myurl = new URL(params[0]);
            Log.d("Inside",myurl.toString());
            HttpURLConnection con = (HttpURLConnection) myurl.openConnection();
            con.setRequestMethod("GET");
            con.connect();
            int responsecode = con.getResponseCode();
            Log.d("Response code", String.valueOf(responsecode));

            if (responsecode == HttpURLConnection.HTTP_OK) {
                // Log.d("Connection ok","Boss");
                InputStream in = con.getInputStream();
                return ParseiTunesXML.parsemyurl(in);
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        }
        return null;

    }

    @Override
    protected void onPostExecute(ArrayList<iTunes> iTunes) {
        super.onPostExecute(iTunes);
        Log.d("Demo.....", iTunes.toString());
        activity.setData(iTunes);
    }

    interface DataRetreiver{
        void setData(ArrayList<iTunes> newsList);
    }

}
