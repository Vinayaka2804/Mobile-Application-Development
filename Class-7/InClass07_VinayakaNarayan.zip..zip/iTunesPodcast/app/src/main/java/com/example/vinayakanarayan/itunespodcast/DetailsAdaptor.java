package com.example.vinayakanarayan.itunespodcast;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Vinayaka Narayan on 10/3/2016.
 */
public class DetailsAdaptor extends ArrayAdapter<iTunes>
{


    Context mContext;
    int mResource;
    List<iTunes> mData;

    public DetailsAdaptor(Context context, int resource, List<iTunes> objects)
    {
        super(context, resource, objects);
        this.mContext = context;
        this.mResource = resource;
        this.mData = objects;

    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if(convertView == null) {
            LayoutInflater inflater =  (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(mResource,parent,false);
        }

        iTunes news = mData.get(position);

        if(news.isSearched())
            {

                ImageView imageView = (ImageView) convertView.findViewById(R.id.imageView);
                imageView.setBackgroundColor(Color.GREEN);
                Picasso.with(mContext).load(news.getThumbnail()).into(imageView);

                TextView textView = (TextView) convertView.findViewById(R.id.textView);
                textView.setText(news.getTitle());
                textView.setBackgroundColor(Color.GREEN);
            } else {
                ImageView imageView = (ImageView) convertView.findViewById(R.id.imageView);

                Picasso.with(mContext).load(news.getThumbnail()).into(imageView);

                TextView textView = (TextView) convertView.findViewById(R.id.textView);
                textView.setText(news.getTitle());

            }

        return convertView;
    }



}
