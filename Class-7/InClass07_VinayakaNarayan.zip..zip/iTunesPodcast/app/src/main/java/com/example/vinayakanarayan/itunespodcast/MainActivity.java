package com.example.vinayakanarayan.itunespodcast;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity implements iTuneAsyncTask.DataRetreiver
{
    ProgressDialog pd;
    ArrayList<iTunes> masterItunesItems = new ArrayList<iTunes>();
    ArrayList<iTunes> itunesItems = new ArrayList<iTunes>();
    ArrayList<iTunes> itunesNewItems = new ArrayList<iTunes>();
    boolean clearFlag = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pd=new ProgressDialog(this);
        pd.setCancelable(false);
        pd.setTitle("loading_text");
        pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        pd.show();

        new iTuneAsyncTask(this).execute("https://itunes.apple.com/us/rss/toppodcasts/limit=30/xml");
        pd.dismiss();
        findViewById(R.id.goButton).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                EditText searchText = ((EditText)findViewById(R.id.searchtext));
                if(searchText != null && !searchText.getText().toString().trim().isEmpty()){
                    String text = searchText.getText().toString().trim();
                    for(iTunes itunesItem : itunesItems) {
                        Pattern p = Pattern.compile(text);
                        Matcher m = p.matcher(itunesItem.getTitle());
                        if(m.find()) {
                            itunesItem.setSearched(true);
                            itunesNewItems.add(itunesItem);
                        }
                    }
                    itunesItems.removeAll(itunesNewItems);
                    itunesNewItems.addAll(itunesItems);
                    Log.d("sizeis:", itunesItems.size() + "");

                    renderNewListView(itunesNewItems);
                }
            }
        });

        findViewById(R.id.Clearbutton).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                EditText searchText = ((EditText)findViewById(R.id.searchtext));
                searchText.setText("");
                clearFlag = true;
                setData(masterItunesItems);
                Log.d("Size of master",masterItunesItems.size()+"");
            }
        });
    }

    @Override
    public void setData(final ArrayList<iTunes> newsList)
    {
        Collections.sort(newsList);
        masterItunesItems = newsList;
        itunesItems = newsList;
        Log.d("Main","SetData");
        final ListView listView = (ListView) findViewById(R.id.listView);
        DetailsAdaptor adaptor = new DetailsAdaptor(MainActivity.this, R.layout.row_item_layout, newsList);
         listView.setAdapter(adaptor);
        adaptor.notifyDataSetChanged();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, Main2Activity.class);
              //  Log.d("Position..",newsList.get(position).toString());
               intent.putExtra("News",newsList.get(position));
                startActivity(intent);
            }
        });


    }

    private void renderNewListView(ArrayList<iTunes> items) {
        ListView listView = (ListView) findViewById(R.id.listView);
        DetailsAdaptor adapter = new DetailsAdaptor(this, R.layout.row_item_layout, itunesNewItems);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent detailsIntent = new Intent(MainActivity.this, Main2Activity.class);
                detailsIntent.putExtra("News", itunesNewItems.get(position));
                startActivity(detailsIntent);
            }
        });

    }
}