package com.example.vinayakanarayan.itunespodcast;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

public class Main2Activity extends AppCompatActivity {

    iTunes item;
    String strDate;
    TextView title;
    TextView story;
    TextView date;
    ImageView displayImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        title = (TextView) findViewById(R.id.textTitle);
        date = (TextView) findViewById(R.id.date);
        story = (TextView) findViewById(R.id.summary);
        displayImage = (ImageView) findViewById(R.id.imageView2);
        //MM/DD/YYYY HH:MM AM/ PM
        item = (iTunes) getIntent().getSerializableExtra("News");
        Log.d("Position",item.getTitle());
        title.setText(item.getTitle());

        //My code
        String date1= item.getReleasedate().toString();
        Log.d("New Date",date1);

        SimpleDateFormat xmlDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZZZ");
        SimpleDateFormat reqdDateFormat = new SimpleDateFormat("MM/dd/yyyy HH:MM a");
        //2016-09-28T17:29:00-07:00

        try {
            strDate = reqdDateFormat.format(xmlDateFormat.parse(date1));
        } catch (ParseException pe) {
            pe.printStackTrace();
        }

        Log.d("Date formatted",strDate);
        date.setText(strDate);

        story.setText(item.getSummary());
        String id = "" + displayImage.getId();
        ImageView image = (ImageView) findViewById(R.id.imageView2);
        Picasso.with(getBaseContext()).load(item.getImage_url()).into(image);

    }
}
