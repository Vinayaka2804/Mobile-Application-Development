package com.example.vinayakanarayan.itunespodcast;

import android.util.Log;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created by Vinayaka Narayan on 10/3/2016.
 */
public class ParseiTunesXML {

        public static ArrayList<iTunes> parsemyurl(InputStream in) throws XmlPullParserException, IOException {

            ArrayList<iTunes> ituneItems;
            iTunes ituneItem = null;
            XmlPullParser pullParser = XmlPullParserFactory.newInstance().newPullParser();
            pullParser.setInput(in, "UTF-8");
            ituneItems = new ArrayList<iTunes>();
            int event = pullParser.getEventType();
            int height = 0;

            while (event != XmlPullParser.END_DOCUMENT) {
                switch (event) {
                    case XmlPullParser.START_TAG:
                        if (pullParser.getName().equals("entry")) {
                            ituneItem = new iTunes();
                        } else if (pullParser.getName().equals("title")) {
                            if (ituneItem != null) {
                                ituneItem.setTitle(pullParser.nextText().trim());
                            }
                        } else if (pullParser.getName().equals("summary")) {
                            if (ituneItem != null) {
                                ituneItem.setSummary(pullParser.nextText().trim());
                            }
                        } else if (pullParser.getName().equals("im:releaseDate")) {
                            if (ituneItem != null) {
                                ituneItem.setReleasedate(pullParser.nextText().trim());
                                SimpleDateFormat xmlDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZZZ");
                                SimpleDateFormat reqdDateFormat = new SimpleDateFormat("MM/dd/yyyy HH:MM a");
                                try {
                                    String s = reqdDateFormat.format(xmlDateFormat.parse(ituneItem.getReleasedate()));
                                    Date d = reqdDateFormat.parse(s);
                                    ituneItem.setFormattedDate(d);
                                }catch(Exception e) {

                                }


                            }
                        } else if (pullParser.getName().equals("im:image")) {
                            int currentHeight = Integer.parseInt(pullParser.getAttributeValue(null, "height").trim());
                            if(height != 0 && currentHeight >= height) {
                                ituneItem.setImage_url(pullParser.nextText().trim());
                            } else {
                                ituneItem.setThumbnail(pullParser.nextText().trim());
                            }
                            height = currentHeight;
                        }
                        break;
                    case XmlPullParser.END_TAG:
                        if (pullParser.getName().equals("entry")) {
                            ituneItems.add(ituneItem);
                        }
                        break;
                    default:
                        break;
                }
                event = pullParser.next();
            }
            return ituneItems;
        }
    }
