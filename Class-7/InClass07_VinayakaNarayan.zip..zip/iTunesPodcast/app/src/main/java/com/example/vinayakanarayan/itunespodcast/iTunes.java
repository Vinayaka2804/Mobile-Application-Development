package com.example.vinayakanarayan.itunespodcast;

import java.io.Serializable;
import java.util.Comparator;
import java.util.Date;

/**
 * Created by Vinayaka Narayan on 10/3/2016.
 */
public class iTunes implements Serializable, Comparable<iTunes> {

    String title, summary, releasedate,thumbnail,image_url;
    boolean isSearched;
    Date formattedDate;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getReleasedate() {
        return releasedate;
    }

    public void setReleasedate(String releasedate) {
        this.releasedate = releasedate;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public boolean isSearched() {
        return isSearched;
    }

    public void setSearched(boolean searched) {
        isSearched = searched;
    }

    public Date getFormattedDate() {
        return formattedDate;
    }

    public void setFormattedDate(Date formattedDate) {
        this.formattedDate = formattedDate;
    }

    @Override
    public String toString() {
        return "iTunes{" +
                "title='" + title + '\'' +
                ", summary='" + summary + '\'' +
                ", releasedate='" + releasedate + '\'' +
                ", thumbnail='" + thumbnail + '\'' +
                ", image_url='" + image_url + '\'' +
                '}';
    }

    @Override
    public int compareTo(iTunes lhs) {
        return this.formattedDate.compareTo(lhs.getFormattedDate());
    }
}
