package com.example.vinayakanarayan.inclass08;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ExpenseAppFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public ExpenseAppFragment() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().setTitle("Expense App");
        return inflater.inflate(R.layout.fragment_expense_app, container, false);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if (activity instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) activity;
        } else {
            throw new RuntimeException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        final ListView listView = (ListView) getActivity().findViewById(R.id.expenseListView);
        ArrayList<Expense> expenseList = mListener.onFragmentInteraction();
        if(expenseList.isEmpty()) {
            getActivity().findViewById(R.id.noExpenseLbl).setVisibility(View.VISIBLE);
            getActivity().findViewById(R.id.expenseListView).setVisibility(View.INVISIBLE);
        } else {
            getActivity().findViewById(R.id.noExpenseLbl).setVisibility(View.INVISIBLE);
            getActivity().findViewById(R.id.expenseListView).setVisibility(View.VISIBLE);
            ExpenseAdapter adapter = new ExpenseAdapter(getActivity(), R.layout.expense, expenseList);
            listView.setAdapter(adapter);
        }

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ArrayList<Expense> expenseList = mListener.onFragmentInteraction();
                Expense expense = expenseList.get(position);
                mListener.selectedItem(expense);
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                ArrayList<Expense> expenseList = mListener.onFragmentInteraction();
                Expense expense = expenseList.get(position);
                expenseList.remove(expense);

                ExpenseAdapter adapter = new ExpenseAdapter(getActivity(), R.layout.expense, expenseList);
                listView.setAdapter(adapter);
                Toast.makeText(getActivity(), "Expense Deleted", Toast.LENGTH_LONG).show();
                mListener.onExpenseDelete(expenseList);
                return true;
            }
        });

        getActivity().findViewById(R.id.addButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.gotoAddFragment();
            }
        });
    }

    public interface OnFragmentInteractionListener {
        ArrayList<Expense> onFragmentInteraction();
        void onExpenseDelete(ArrayList<Expense> refreshedExpenses);
        void gotoAddFragment();
        void selectedItem(Expense expense);
    }
}
