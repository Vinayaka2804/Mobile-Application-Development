/*Vinayaka Narayan
800911516
 */
package com.example.vinayakanarayan.inclass08;

import java.io.Serializable;

public class Expense implements Serializable {

    private String expenseName;
    private String category;
    private String amount;
    private String dateAdded;

    public Expense(String expenseName, String category, String amount, String dateAdded) {
        this.expenseName = expenseName;
        this.category = category;
        this.amount = amount;
        this.dateAdded = dateAdded;
    }

    public Expense() {

    }

    public String getExpenseName() {
        return expenseName;
    }

    public void setExpenseName(String expenseName) {
        this.expenseName = expenseName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getDateAdded() {
        return dateAdded;
    }

    public void setDateAdded(String dateAdded) {
        this.dateAdded = dateAdded;
    }

    @Override
    public String toString() {
        return "Expense{" +
                "expenseName='" + expenseName + '\'' +
                ", category='" + category + '\'' +
                ", amount='" + amount + '\'' +
                ", dateAdded='" + dateAdded + '\'' +
                '}';
    }
}
