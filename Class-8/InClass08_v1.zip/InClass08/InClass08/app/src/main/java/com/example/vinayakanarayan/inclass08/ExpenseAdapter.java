package com.example.vinayakanarayan.inclass08;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class ExpenseAdapter extends ArrayAdapter<Expense> {

    Context mContext;
    List<Expense> mObjects;
    int mResource;

    public ExpenseAdapter(Context context, int resource, List<Expense> objects) {
        super(context, resource, objects);
        this.mContext = context;
        this.mObjects = objects;
        this.mResource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.expense, parent, false);
        }

        Expense expense = mObjects.get(position);
        TextView textView = (TextView) convertView.findViewById(R.id.expenseNameList);
        textView.setText(expense.getExpenseName());

        TextView textView2 = (TextView) convertView.findViewById(R.id.expenseAmntList);
        textView2.setText(expense.getAmount());

        return convertView;
    }
}
