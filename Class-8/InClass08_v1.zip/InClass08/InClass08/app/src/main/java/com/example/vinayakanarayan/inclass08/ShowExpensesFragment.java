/*Vinayaka Narayan
800911516
 */
package com.example.vinayakanarayan.inclass08;

import android.app.Activity;
import android.os.Bundle;
import android.app.Fragment;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class ShowExpensesFragment extends Fragment {
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public ShowExpensesFragment() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().setTitle("Show Expense");
        return inflater.inflate(R.layout.fragment_show_expenses, container, false);
    }

    @Override
    public void onAttach(Activity context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Expense expense = mListener.expenseShown();
        ((TextView)getActivity().findViewById(R.id.detailsAmnt)).setText("$ ".concat(expense.getAmount()));
        ((TextView)getActivity().findViewById(R.id.detailsCategory)).setText(expense.getCategory());
        ((TextView)getActivity().findViewById(R.id.detailsName)).setText(expense.getExpenseName());
        ((TextView)getActivity().findViewById(R.id.detailsDate)).setText(expense.getDateAdded());

        getActivity().findViewById(R.id.btnCLose).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onCloseFragment();
            }
        });

    }

    public interface OnFragmentInteractionListener {
        void onCloseFragment();
        Expense expenseShown();
    }
}
