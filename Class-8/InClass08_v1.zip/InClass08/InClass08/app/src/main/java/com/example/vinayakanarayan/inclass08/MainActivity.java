/*Vinayaka Narayan
800911516
 */
package com.example.vinayakanarayan.inclass08;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements ExpenseAppFragment.OnFragmentInteractionListener,
        AddExpenseFragment.OnFragmentInteractionListener, ShowExpensesFragment.OnFragmentInteractionListener
{
    public ArrayList<Expense> expenseList = new ArrayList<Expense>();
    Expense expenseSelected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getFragmentManager().beginTransaction()
                .add(R.id.mainContainer, new ExpenseAppFragment(), "expense_app")
                .commit();
    }

    @Override
    public ArrayList<Expense> onFragmentInteraction() {
        return expenseList;
    }

    @Override
    public void gotoAddFragment() {
        getFragmentManager().beginTransaction()
                .replace(R.id.mainContainer, new AddExpenseFragment(), "add_expense")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public ArrayList<Expense> onAddFragmentInteraction() {
        return expenseList;
    }

    @Override
    public void setNewExpenses(ArrayList<Expense> addedExpenseList) {
        expenseList = addedExpenseList;
    }

    @Override
    public void gotoExpenseAppFragment() {
        getFragmentManager().beginTransaction()
                .replace(R.id.mainContainer, new ExpenseAppFragment(), "expense_app")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void selectedItem(Expense expense) {
        expenseSelected = expense;
        getFragmentManager().beginTransaction()
                .replace(R.id.mainContainer, new ShowExpensesFragment(), "show_expenses")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public Expense expenseShown() {
        return expenseSelected;
    }

    @Override
    public void onCloseFragment(){
        getFragmentManager().beginTransaction()
                .replace(R.id.mainContainer, new ExpenseAppFragment(), "expense_app")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void onExpenseDelete(ArrayList<Expense> refreshedExpenses) {
        expenseList = refreshedExpenses;
    }
}
