/*Vinayaka Narayan
800911516
 */
package com.example.vinayakanarayan.inclass08;

import android.app.Activity;
import android.os.Bundle;
import android.app.Fragment;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


public class AddExpenseFragment extends Fragment {
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    String selectedCategory = "Select Category";
    private OnFragmentInteractionListener mListener;

    public AddExpenseFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().setTitle("Add Expense");
        return inflater.inflate(R.layout.fragment_add_expense, container, false);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if (activity instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) activity;
        } else {
            throw new RuntimeException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        Spinner staticSpinner = (Spinner) getActivity().findViewById(R.id.categorySpinner);
        ArrayAdapter<CharSequence> staticAdapter = ArrayAdapter
                .createFromResource(getActivity(), R.array.categories,
                        android.R.layout.simple_spinner_item);
        staticAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        staticSpinner.setAdapter(staticAdapter);
        staticSpinner.setOnItemSelectedListener(new CategorySelectedListener());

        getActivity().findViewById(R.id.cancelBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.gotoExpenseAppFragment();
            }
        });

        getActivity().findViewById(R.id.addExpenseBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText name = (EditText)getActivity().findViewById(R.id.nameText);
                EditText amount = (EditText)getActivity().findViewById(R.id.amountText);

                if(name.getText().toString().trim().isEmpty() || amount.getText().toString().trim().isEmpty()
                        || selectedCategory.equals("Select Category")) {
                    Toast.makeText(getActivity(), "Please enter/select all the fields.", Toast.LENGTH_LONG).show();
                } else {

                    DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
                    Date dateobj = new Date();

                    Expense expense = new Expense(name.getText().toString().trim(),
                            selectedCategory,
                            amount.getText().toString().trim(),
                            df.format(dateobj));

                    ArrayList<Expense> expenseList = mListener.onAddFragmentInteraction();
                    expenseList.add(expense);
                    mListener.setNewExpenses(expenseList);
                    mListener.gotoExpenseAppFragment();
                }
            }
        });
    }

    public interface OnFragmentInteractionListener {
        ArrayList<Expense> onAddFragmentInteraction();
        void setNewExpenses(ArrayList<Expense> addedExpenseList);
        void gotoExpenseAppFragment();
    }

    public class CategorySelectedListener implements AdapterView.OnItemSelectedListener {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
            selectedCategory = parent.getItemAtPosition(pos).toString();
        }
        @Override
        public void onNothingSelected(AdapterView parent) {
        }
    }
}
