/*
HW 2
Group 43 - Bharat Pothina, Vinayaka Narayan
EditExpenseActivity.java
 */

package com.example.srujanpothina.expensemanagement;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class EditExpenseActivity extends AppCompatActivity {

    static String activeDate;
    String selectedCategory;
    ArrayList<Expense> expenses;
    Expense editedExpense;
    CharSequence[] expenseNamesSequence;
    String selectedExpenseName;
    Spinner staticSpinner;
    Uri selectedImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_expense);

        //Editing receipt
        findViewById(R.id.editReceiptPicker).setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent1, 10);
            }
        });

        //Categories in Edit Screen
        staticSpinner = (Spinner) findViewById(R.id.editCategorySelect);
        ArrayAdapter<CharSequence> staticAdapter = ArrayAdapter
                .createFromResource(this, R.array.categories,
                        android.R.layout.simple_spinner_item);
        staticAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        staticSpinner.setAdapter(staticAdapter);
        staticSpinner.setOnItemSelectedListener(new CategorySelectedListener());

        //Gather all expense names
        expenses = getIntent().getParcelableArrayListExtra(MainActivity.EDIT_KEY);
        Set<String> expenseNames = new TreeSet<String>();
        for(Expense expense : expenses) {
            expenseNames.add(expense.getName());
        }

        //Dropdown Alert Box
        expenseNamesSequence = expenseNames.toArray(new CharSequence[expenseNames.size()]);
        AlertDialog.Builder dropList = new AlertDialog.Builder(this);
        dropList.setTitle("Select a Expense")
                .setItems(expenseNamesSequence, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        selectedExpenseName = (String) expenseNamesSequence[which];

                        for(Expense expense : expenses) {
                            if(selectedExpenseName.equals(expense.getName())) {
                                editedExpense = expense;
                                EditText name = (EditText)findViewById(R.id.editExpenseNameText);
                                name.setText(expense.getName());
                                name.setEnabled(true);

                                EditText amount = (EditText)findViewById(R.id.editAmountText);
                                amount.setText(expense.getAmount().toString());
                                amount.setEnabled(true);

                                TextView date = (TextView)findViewById(R.id.editDateText);
                                activeDate = expense.getDate();
                                date.setText(activeDate);
                                ((ImageButton)findViewById(R.id.editDatePicker)).setClickable(true);

                                selectedCategory = expense.getCategory();
                                staticSpinner.setSelection(selectedCategoryPosition(selectedCategory));
                                staticSpinner.setEnabled(true);

                                selectedImage = Uri.parse(expense.getUri());
                                ((ImageView) findViewById(R.id.editReceiptPicker)).setImageURI(selectedImage);
                                ((ImageButton) findViewById(R.id.editReceiptPicker)).setClickable(true);

                                break;
                            }
                        }
                    }
                });

        final AlertDialog listPopulated = dropList.create();
        findViewById(R.id.editSelectExpenseButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listPopulated.show();
            }
        });

        //Date Picker
        ImageButton imageButton = (ImageButton)findViewById(R.id.editDatePicker);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment newFragment = new DatePickerFragment();
                newFragment.show(getSupportFragmentManager(), "datePicker");
            }
        });

        //Disable clickable on page load as the user can click only on selection of expense name from Select Expense dialog.
        ((EditText)findViewById(R.id.editExpenseNameText)).setEnabled(false);
        ((EditText)findViewById(R.id.editAmountText)).setEnabled(false);
        staticSpinner.setEnabled(false);
        ((ImageButton)findViewById(R.id.editDatePicker)).setClickable(false);
        ((ImageButton) findViewById(R.id.editReceiptPicker)).setClickable(false);


        //Save button click
        findViewById(R.id.editSaveButton).setOnClickListener(new View.OnClickListener() {
            EditText name = (EditText)findViewById(R.id.editExpenseNameText);
            EditText amount = (EditText)findViewById(R.id.editAmountText);
            TextView date = (TextView)findViewById(R.id.editDateText);

            @Override
            public void onClick(View v) {
                if(selectedExpenseName == null || selectedExpenseName.isEmpty()){
                    Toast.makeText(getApplicationContext(), "Please Select Expense to edit", Toast.LENGTH_LONG).show();
                } else if((name.getText() == null || name.getText().toString().trim().length() == 0)
                        || (amount.getText() == null || amount.getText().toString().length() == 0)
                        || (date.getText() == null || date.getText().toString().trim().length() == 0)
                        || (selectedCategory.equals("Select Category")))
                {
                    Toast.makeText(getApplicationContext(), "Please enter/select all the fields", Toast.LENGTH_LONG).show();
                } else {
                    Expense expense = new Expense(name.getText().toString().trim(),
                            selectedCategory,
                            Double.parseDouble(amount.getText().toString()),
                            date.getText().toString().trim(),
                            selectedImage.toString());
                    expenses = getIntent().getParcelableArrayListExtra(MainActivity.EDIT_KEY);
                    expenses.remove(editedExpense);
                    expenses.add(expense);

                    Intent displayIntent = new Intent();
                    displayIntent.putParcelableArrayListExtra(MainActivity.EDIT_KEY, expenses);
                    setResult(RESULT_OK, displayIntent);
                    finish();
                }
            }
        });

        findViewById(R.id.editCancelButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent displayIntent = new Intent();
                setResult(RESULT_CANCELED, displayIntent);
                finish();
                }
        });
    }

    public class CategorySelectedListener implements AdapterView.OnItemSelectedListener {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
            selectedCategory = parent.getItemAtPosition(pos).toString();
        }
        @Override
        public void onNothingSelected(AdapterView parent) {
        }
    }

    public static class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            String date = EditExpenseActivity.activeDate;
            int year = Integer.parseInt(date.split("/")[2]);
            int month = Integer.parseInt(date.split("/")[0]) - 1;
            int day = Integer.parseInt(date.split("/")[1]);
            return new DatePickerDialog(getActivity(), this, year, month, day);
        }

        @Override
        public void onDateSet(DatePicker view, int year, int month, int day) {
            String selectedDate = (Integer.valueOf(month+1).toString()).concat("/").concat((Integer.valueOf(day).toString()))
                    .concat("/").concat((Integer.valueOf(year).toString()));
            EditExpenseActivity.activeDate = selectedDate;
            ((TextView)getActivity().findViewById(R.id.editDateText)).setText(selectedDate);
        }
    }

    //Select a different image receipt
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 10 && resultCode == RESULT_OK && null != data) {
            selectedImage = data.getData();
            ((ImageView) findViewById(R.id.editReceiptPicker)).setImageURI(selectedImage);

        }
    }

    private int selectedCategoryPosition(String categoryName) {
        int position;
        switch(categoryName){
            case "Groceries":
                position = 1;
                break;
            case "Invoice":
                position = 2;
                break;
            case "Transportation":
                position = 3;
                break;
            case "Shopping":
                position = 4;
                break;
            case "Rent":
                position = 5;
                break;
            case "Trips":
                position = 6;
                break;
            case "Utilities":
                position = 7;
                break;
            case "Other":
                position = 8;
                break;
            default:
                position = 0;
        }
        return position;
    }
}
