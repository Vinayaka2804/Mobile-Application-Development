/*
HW 2
Group 43 - Bharat Pothina, Vinayaka Narayan
Expense.java
 */

package com.example.srujanpothina.expensemanagement;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;

import java.util.Date;

public class Expense implements Parcelable, Comparable<Expense> {
    private String name;
    private String category;
    private Double amount;
    private String date;
    private String uri;

    public Expense(String name, String category, Double amount, String date, String uri) {
        super();
        this.name = name;
        this.category = category;
        this.amount = amount;
        this.date = date;
        this.uri = uri;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(category);
        dest.writeDouble(amount);
        dest.writeString(date);
        dest.writeString(uri);
    }

    public static final Parcelable.Creator<Expense> CREATOR = new Parcelable.Creator<Expense>() {
        @Override
        public Expense createFromParcel(Parcel in) {
            return new Expense(in);
        }

        @Override
        public Expense[] newArray(int size) {
            return new Expense[size];
        }
    };

    private Expense(Parcel in) {
        this.name = in.readString();
        this.category = in.readString();
        this.amount = in.readDouble();
        this.date = in.readString();
        this.uri = in.readString();
    }

    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }

    public Double getAmount() {
        return amount;
    }

    public String getDate() {
        return date;
    }

    public String getUri() {
        return uri;
    }

    @Override
    public int compareTo(Expense expense) {
        return this.name.compareTo(expense.getName());
    }
}
