/*
HW 2
Group 43 - Bharat Pothina, Vinayaka Narayan
MainActivity.java
 */

package com.example.srujanpothina.expensemanagement;

import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static String ADD_KEY = "ADD";
    public static String EDIT_KEY = "EDIT";
    public static String DELETE_KEY = "DELETE";
    public static String SHOW_KEY = "SHOW";

    public static int ADD_REQ_CODE = 100;
    public static int EDIT_REQ_CODE = 200;
    public static int DELETE_REQ_CODE = 300;
    public static int SHOW_REQ_CODE = 400;

    ArrayList<Expense> expenses = new ArrayList<Expense>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.homeAddButton).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent i = new Intent("com.example.srujanpothina.expensemanagement.ADD");
                i.addCategory(Intent.CATEGORY_DEFAULT);
                i.putParcelableArrayListExtra(ADD_KEY, expenses);
                startActivityForResult(i, ADD_REQ_CODE);
            }
        });

        findViewById(R.id.homeEditButton).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(expenses.size() == 0) {
                    Toast.makeText(getApplicationContext(), "You do not have expenses to edit. Please Add Expense before editing", Toast.LENGTH_LONG).show();
                } else {
                    Intent i = new Intent("com.example.srujanpothina.expensemanagement.EDIT");
                    i.addCategory(Intent.CATEGORY_DEFAULT);
                    i.putParcelableArrayListExtra(EDIT_KEY, expenses);
                    startActivityForResult(i, EDIT_REQ_CODE);
                }
            }
        });

        findViewById(R.id.homeDeleteButton).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(expenses.size() == 0) {
                    Toast.makeText(getApplicationContext(), "You do not have expenses to delete. Please Add Expense before deleting", Toast.LENGTH_LONG).show();
                } else {
                    Intent i = new Intent("com.example.srujanpothina.expensemanagement.DELETE");
                    i.addCategory(Intent.CATEGORY_DEFAULT);
                    i.putParcelableArrayListExtra(DELETE_KEY, expenses);
                    startActivityForResult(i, DELETE_REQ_CODE);
                }
            }
        });

        findViewById(R.id.homeShowButton).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(expenses.size() == 0) {
                    Toast.makeText(getApplicationContext(), "No expenses to show. Please Add Expense for seeing your expenses", Toast.LENGTH_LONG).show();
                } else {
                    Intent i = new Intent("com.example.srujanpothina.expensemanagement.SHOW");
                    i.addCategory(Intent.CATEGORY_DEFAULT);
                    i.putParcelableArrayListExtra(SHOW_KEY, expenses);
                    startActivityForResult(i, SHOW_REQ_CODE);
                }
            }
        });

        findViewById(R.id.homeFinish).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == ADD_REQ_CODE) {
            if(resultCode == RESULT_OK){
                expenses = data.getParcelableArrayListExtra(ADD_KEY);
                Collections.sort(expenses);
                Log.d("add final", Integer.valueOf(expenses.size()).toString());
                listExpenses(expenses);
            }
        } else if(requestCode == EDIT_REQ_CODE) {
            if(resultCode == RESULT_OK){
                expenses = data.getParcelableArrayListExtra(EDIT_KEY);
                Collections.sort(expenses);
                Log.d("edit final", Integer.valueOf(expenses.size()).toString());
                listExpenses(expenses);
            } else if(resultCode == RESULT_CANCELED) {
                Collections.sort(expenses);
                Log.d("edit cancel final", Integer.valueOf(expenses.size()).toString());
                listExpenses(expenses);
            }
        } else if(requestCode == DELETE_REQ_CODE) {
            if(resultCode == RESULT_OK){
                expenses = data.getParcelableArrayListExtra(DELETE_KEY);
                Collections.sort(expenses);
                Log.d("delete final", Integer.valueOf(expenses.size()).toString());
                listExpenses(expenses);
            } else if(resultCode == RESULT_CANCELED) {
                Collections.sort(expenses);
                Log.d("del cancel final", Integer.valueOf(expenses.size()).toString());
                listExpenses(expenses);
            }
        } else if(requestCode == SHOW_REQ_CODE) {
            if(resultCode == RESULT_OK){
                Log.d("show final", Integer.valueOf(expenses.size()).toString());
                listExpenses(expenses);
            }
        }
    }

    private void listExpenses(ArrayList<Expense> expenseList) {
        for(Expense expense : expenseList) {
            Log.d("Expense -->", expense.getName() + ":" + expense.getCategory() + ":" + Double.valueOf(expense.getAmount()).toString() + ":" + expense.getDate());
        }
    }

}
