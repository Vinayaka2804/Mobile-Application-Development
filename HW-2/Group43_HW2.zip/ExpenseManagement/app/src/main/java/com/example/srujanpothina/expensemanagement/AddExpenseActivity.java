/*
HW 2
Group 43 - Bharat Pothina, Vinayaka Narayan
AddExpenseActivity.java
 */

package com.example.srujanpothina.expensemanagement;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;

public class AddExpenseActivity extends AppCompatActivity {

    String selectedCategory = "Select Category";
    ArrayList<Expense> expenses;
    public Uri selectedUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);

        //Categories in Add Screen
        Spinner staticSpinner = (Spinner) findViewById(R.id.addCategorySelect);
        ArrayAdapter<CharSequence> staticAdapter = ArrayAdapter
                .createFromResource(this, R.array.categories,
                        android.R.layout.simple_spinner_item);
        staticAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        staticSpinner.setAdapter(staticAdapter);
        staticSpinner.setOnItemSelectedListener(new CategorySelectedListener());

        //Date Picker
        ImageButton imageButton = (ImageButton)findViewById(R.id.addDatePicker);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment newFragment = new DatePickerFragment();
                newFragment.show(getSupportFragmentManager(), "datePicker");
            }
        });

        findViewById(R.id.addReceiptPicker).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(intent, 10);
            }
        });

        //AddExpense button click
        findViewById(R.id.addExpenseAddButton).setOnClickListener(new View.OnClickListener() {
            EditText name = (EditText)findViewById(R.id.addExpenseNameText);
            EditText amount = (EditText)findViewById(R.id.addAmountText);
            TextView date = (TextView)findViewById(R.id.addDateText);

            @Override
            public void onClick(View v) {
                Log.d("category is:", selectedCategory);
                if((name.getText() == null || name.getText().toString().trim().length() == 0)
                        || (amount.getText() == null || amount.getText().toString().length() == 0)
                        || (date.getText() == null || date.getText().toString().trim().length() == 0)
                        || (selectedCategory.equals("Select Category"))
                        || (selectedUri == null))
                {
                    Toast.makeText(getApplicationContext(), "Please enter/select all the fields", Toast.LENGTH_LONG).show();
                } else {
                    Expense expense = new Expense(name.getText().toString().trim(),
                                                    selectedCategory,
                                                    Double.parseDouble(amount.getText().toString()),
                                                    date.getText().toString().trim(),
                                                    selectedUri.toString());
                    expenses = getIntent().getParcelableArrayListExtra(MainActivity.ADD_KEY);
                    expenses.add(expense);

                    Intent displayIntent = new Intent();
                    displayIntent.putParcelableArrayListExtra(MainActivity.ADD_KEY, expenses);
                    setResult(RESULT_OK, displayIntent);
                    finish();
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 10 && resultCode == RESULT_OK && null != data) {
            selectedUri = data.getData();
            ((ImageView) findViewById(R.id.addReceiptPicker)).setImageURI(selectedUri);
        }
    }


    public static class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            int year;
            int month;
            int day;

            TextView dateText = (TextView)getActivity().findViewById(R.id.addDateText);
            if(dateText.getText() == null || dateText.getText().toString().length() == 0) {
                final Calendar c = Calendar.getInstance();
                year = c.get(Calendar.YEAR);
                month = c.get(Calendar.MONTH);
                day = c.get(Calendar.DAY_OF_MONTH);
            } else {
                String date = dateText.getText().toString();
                year = Integer.parseInt(date.split("/")[2]);
                month = Integer.parseInt(date.split("/")[0]) - 1;
                day = Integer.parseInt(date.split("/")[1]);
            }
            return new DatePickerDialog(getActivity(), this, year, month, day);
        }

        @Override
        public void onDateSet(DatePicker view, int year, int month, int day) {
            String selectedDate = (Integer.valueOf(month+1).toString()).concat("/").concat((Integer.valueOf(day).toString()))
                                .concat("/").concat((Integer.valueOf(year).toString()));
            ((TextView)getActivity().findViewById(R.id.addDateText)).setText(selectedDate);
        }
    }

    public class CategorySelectedListener implements AdapterView.OnItemSelectedListener {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
            selectedCategory = parent.getItemAtPosition(pos).toString();
        }
        @Override
        public void onNothingSelected(AdapterView parent) {
        }
    }
}
