/*
HW 2
Group 43 - Bharat Pothina, Vinayaka Narayan
DeleteExpenseActivity.java
 */

package com.example.srujanpothina.expensemanagement;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;

public class DeleteExpenseActivity extends AppCompatActivity {

    static String activeDate;
    String selectedCategory;
    ArrayList<Expense> expenses;
    Expense deleteExpense;
    CharSequence[] expenseNamesSequence;
    String selectedExpenseName;
    Spinner categorySpinner;
    Uri selectedImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_expense);

        //Gather all expense names
        expenses = getIntent().getParcelableArrayListExtra(MainActivity.DELETE_KEY);
        final Set<String> expenseNames = new TreeSet<String>();
        for(Expense expense : expenses) {
            expenseNames.add(expense.getName());
        }

        categorySpinner = (Spinner) findViewById(R.id.deleteCategorySelect);
        ArrayAdapter<CharSequence> staticAdapter = ArrayAdapter
                .createFromResource(this, R.array.categories,
                        android.R.layout.simple_spinner_item);
        staticAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(staticAdapter);

        //Dropdown Alert Box
        expenseNamesSequence = expenseNames.toArray(new CharSequence[expenseNames.size()]);
        AlertDialog.Builder dropList = new AlertDialog.Builder(this);
        dropList.setTitle("Select a Expense")
                .setItems(expenseNamesSequence, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        selectedExpenseName = (String) expenseNamesSequence[which];

                        for(Expense expense : expenses) {
                            if(selectedExpenseName.equals(expense.getName())) {
                                deleteExpense = expense;
                                EditText name = (EditText)findViewById(R.id.deleteExpenseNameText);
                                name.setText(expense.getName());

                                EditText amount = (EditText)findViewById(R.id.deleteAmountText);
                                amount.setText(expense.getAmount().toString());

                                TextView date = (TextView)findViewById(R.id.deleteDateText);
                                activeDate = expense.getDate();
                                date.setText(activeDate);

                                selectedCategory = expense.getCategory();
                                categorySpinner.setSelection(selectedCategoryPosition(selectedCategory));

                                Uri selectedImage = Uri.parse(expense.getUri());
                                ((ImageView) findViewById(R.id.deleteReceiptPicker)).setImageURI(selectedImage);

                                break;
                            }
                        }
                    }
                });

        //Disable clickable on page load as the user can click only on selection of expense name from Select Expense dialog.
        ((EditText)findViewById(R.id.deleteExpenseNameText)).setEnabled(false);
        ((EditText)findViewById(R.id.deleteAmountText)).setEnabled(false);
        categorySpinner.setEnabled(false);
        ((ImageButton)findViewById(R.id.deleteDatePicker)).setClickable(false);
        ((ImageView) findViewById(R.id.deleteReceiptPicker)).setClickable(false);

        final AlertDialog listPopulated = dropList.create();
        findViewById(R.id.deleteSelectExpenseButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("Expense Name",Integer.valueOf(expenseNames.size()).toString());
                listPopulated.show();
            }
        });

        //Delete button click
        findViewById(R.id.deleteDelButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(deleteExpense == null) {
                    Toast.makeText(getApplicationContext(), "Please Select Expense to delete", Toast.LENGTH_LONG).show();
                } else {
                    expenses.remove(deleteExpense);
                    Intent displayIntent = new Intent();
                    displayIntent.putParcelableArrayListExtra(MainActivity.DELETE_KEY, expenses);
                    setResult(RESULT_OK, displayIntent);
                    finish();
                }
            }
        });

        findViewById(R.id.deleteCancelButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent displayIntent = new Intent();
                setResult(RESULT_CANCELED, displayIntent);
                finish();
            }
        });
    }

    public class CategorySelectedListener implements AdapterView.OnItemSelectedListener {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
            selectedCategory = parent.getItemAtPosition(pos).toString();
        }
        @Override
        public void onNothingSelected(AdapterView parent) {
        }
    }

    private int selectedCategoryPosition(String categoryName) {
        int position;
        switch(categoryName){
            case "Groceries":
                position = 1;
                break;
            case "Invoice":
                position = 2;
                break;
            case "Transportation":
                position = 3;
                break;
            case "Shopping":
                position = 4;
                break;
            case "Rent":
                position = 5;
                break;
            case "Trips":
                position = 6;
                break;
            case "Utilities":
                position = 7;
                break;
            case "Other":
                position = 8;
                break;
            default:
                position = 0;
        }
        return position;
    }
}
