/*
HW 2
Group 43 - Bharat Pothina, Vinayaka Narayan
ShowExpenseActivity.java
 */

package com.example.srujanpothina.expensemanagement;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ShowExpenseActivity extends AppCompatActivity {

    ArrayList<Expense> expenses;
    Map<Integer, Expense> expenseMap = new HashMap<Integer, Expense>();
    Expense firstExpense;
    Expense lastExpense;
    int currentPosition = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_expense);
        expenses = getIntent().getParcelableArrayListExtra(MainActivity.SHOW_KEY);
        int i = 0;
        for(Expense expense : expenses) {
            expenseMap.put(i+1, expense);
            i++;
        }

        firstExpense = expenseMap.get(1);
        lastExpense = expenseMap.get(expenses.size());
        ((TextView)findViewById(R.id.showName)).setText(firstExpense.getName());
        ((TextView)findViewById(R.id.showCategory)).setText(firstExpense.getCategory());
        ((TextView)findViewById(R.id.showAmount)).setText("$ " + firstExpense.getAmount().toString());
        ((TextView)findViewById(R.id.showDate)).setText(firstExpense.getDate());

        findViewById(R.id.showFirstButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((TextView)findViewById(R.id.showName)).setText(firstExpense.getName());
                ((TextView)findViewById(R.id.showCategory)).setText(firstExpense.getCategory());
                ((TextView)findViewById(R.id.showAmount)).setText("$ " + firstExpense.getAmount().toString());
                ((TextView)findViewById(R.id.showDate)).setText(firstExpense.getDate());
                Uri selectedImage = Uri.parse(firstExpense.getUri());
                ((ImageView) findViewById(R.id.showReceipt)).setImageURI(selectedImage);
                currentPosition = 1;
            }
        });

        findViewById(R.id.showLastButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((TextView)findViewById(R.id.showName)).setText(lastExpense.getName());
                ((TextView)findViewById(R.id.showCategory)).setText(lastExpense.getCategory());
                ((TextView)findViewById(R.id.showAmount)).setText("$ " + lastExpense.getAmount().toString());
                ((TextView)findViewById(R.id.showDate)).setText(lastExpense.getDate());
                Uri selectedImage = Uri.parse(lastExpense.getUri());
                ((ImageView) findViewById(R.id.showReceipt)).setImageURI(selectedImage);
                currentPosition = expenses.size();
            }
        });

        findViewById(R.id.showPreviousButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(currentPosition != 1) {
                    currentPosition = currentPosition - 1;
                }
                Expense currentExpense = expenseMap.get(currentPosition);
                ((TextView)findViewById(R.id.showName)).setText(currentExpense.getName());
                ((TextView)findViewById(R.id.showCategory)).setText(currentExpense.getCategory());
                ((TextView)findViewById(R.id.showAmount)).setText("$ " + currentExpense.getAmount().toString());
                ((TextView)findViewById(R.id.showDate)).setText(currentExpense.getDate());
                Uri selectedImage = Uri.parse(currentExpense.getUri());
                ((ImageView) findViewById(R.id.showReceipt)).setImageURI(selectedImage);
            }
        });

        findViewById(R.id.showNextButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(currentPosition != expenses.size()) {
                    currentPosition = currentPosition + 1;
                }
                Expense currentExpense = expenseMap.get(currentPosition);
                ((TextView)findViewById(R.id.showName)).setText(currentExpense.getName());
                ((TextView)findViewById(R.id.showCategory)).setText(currentExpense.getCategory());
                ((TextView)findViewById(R.id.showAmount)).setText("$ " + currentExpense.getAmount().toString());
                ((TextView)findViewById(R.id.showDate)).setText(currentExpense.getDate());
                Uri selectedImage = Uri.parse(currentExpense.getUri());
                ((ImageView) findViewById(R.id.showReceipt)).setImageURI(selectedImage);
            }
        });

        findViewById(R.id.showFinishButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent displayIntent = new Intent();
                setResult(RESULT_OK, displayIntent);
                finish();
            }
        });
    }
}
