/*
Group#43 - Bharat Pothina, Vinayaka Narayan
HW# 4
GetQuestion.java
*/
package com.example.vinayakanarayan.triviaquiz;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by Vinayaka Narayan on 9/23/2016.
 */
public class GetQuestion extends AsyncTask<String, Void, ArrayList<Question>> {

    MainActivity mainActivity;
    ProgressDialog questionsLoadingProgress;
    ArrayList<Question> questions;

    public GetQuestion(MainActivity activity)
    {
        mainActivity = activity;
    }

    public GetQuestion() {
    }

    @Override
    protected ArrayList<Question> doInBackground(String... params) {
        //Get String from URL//
        URL url = null;
        try {
            url = new URL(params[0]);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.connect();

            int responseStatusCode = con.getResponseCode();
            if(responseStatusCode == HttpURLConnection.HTTP_OK)
            {
                BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line= reader.readLine();
                while(line!=null)
                {
                    sb.append(line);
                    line=reader.readLine();
                }
                questions = QuestionUtil.QuestionsJSONoarser.parseQuestions(sb.toString());
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return questions;
    }

    @Override
    protected void onPreExecute()
    {
        super.onPreExecute();
        questionsLoadingProgress = new ProgressDialog(mainActivity);
        questionsLoadingProgress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        questionsLoadingProgress.setTitle("Loading Trivia.");
        questionsLoadingProgress.show();
    }

    @Override
    protected void onPostExecute(ArrayList<Question> questionList)
    {
        super.onPostExecute(questionList);
        questionsLoadingProgress.dismiss();
        mainActivity.findViewById(R.id.triviaimage).setVisibility(View.VISIBLE);
        if(questionList != null && questionList.size() > 0) {
            mainActivity.findViewById(R.id.startbutton).setEnabled(true);
            mainActivity.findViewById(R.id.triviaready).setVisibility(View.VISIBLE);
            mainActivity.getQuestionsFromJson(questions);
        } else {
            ((TextView)mainActivity.findViewById(R.id.triviaready)).setText("Trivia Not Ready");
            mainActivity.findViewById(R.id.triviaready).setVisibility(View.VISIBLE);
        }
    }

    static public interface IData {
        public void getQuestionsFromJson(ArrayList<Question> result);
    }
}
