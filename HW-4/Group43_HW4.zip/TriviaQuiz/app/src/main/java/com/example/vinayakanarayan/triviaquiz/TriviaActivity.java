/*
Group#43 - Bharat Pothina, Vinayaka Narayan
HW# 4
TriviaActivity.java
*/
package com.example.vinayakanarayan.triviaquiz;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.CountDownTimer;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class TriviaActivity extends AppCompatActivity {

    public static String STATS_KEY = "Stats";
    public static String STATS_LIST = "questions";
    ArrayList<Question> questionsList;
    int currentPosition = 0;
    Question question;
    int noOfQuestions;
    int noOfCorrectAnswers = 0;
    LinearLayout radioLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trivia);

        CountDownTimer timer =  new CountDownTimer(120000, 1000) {
            public void onTick(long millisUntilFinished) {
                String v = String.format("%02d", millisUntilFinished/60000);
                int va = (int)((millisUntilFinished%60000)/1000);
                ((TextView)findViewById(R.id.timeLbl)).setText("Time Left: " + v + ":" + String.format("%02d",va) + " seconds");
            }
            public void onFinish() {
                Intent statsIntent = new Intent(TriviaActivity.this, StatsActivity.class);
                int percentage = Math.round((noOfCorrectAnswers * 100)/noOfQuestions);
                statsIntent.putExtra(STATS_KEY,  Integer.valueOf(percentage).toString());
                statsIntent.putParcelableArrayListExtra(STATS_LIST, questionsList);
                startActivity(statsIntent);
                finish();
            }
        };
        timer.start();

        if(getIntent().getParcelableArrayListExtra(MainActivity.TRIVIA_KEY) != null) {
            questionsList = getIntent().getParcelableArrayListExtra(MainActivity.TRIVIA_KEY);
        } else if (getIntent().getParcelableArrayListExtra(StatsActivity.TRIVIA_TRY) != null) {
            questionsList = getIntent().getParcelableArrayListExtra(StatsActivity.TRIVIA_TRY);
        }
        noOfQuestions = questionsList.size();

        question = questionsList.get(0);
        if(!question.getImageUrl().isEmpty()) {
            new GetImage(this).execute(question.getImageUrl());
        }
        currentPosition = question.getId();
        ((TextView)findViewById(R.id.qtnid)).setText("Q".concat((Integer.valueOf(currentPosition)).toString()));
        ((TextView)findViewById(R.id.question)).setText(question.getText());

        createRadioButton(question.getId(), question.getChoices());

        ((Button) findViewById(R.id.trivquit)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent mainIntent = new Intent(TriviaActivity.this, MainActivity.class);
                startActivity(mainIntent);
                finish();
            }
        });

        findViewById(R.id.next).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int selRadioBtnId = ((RadioGroup) findViewById(question.getId() + 10)).getCheckedRadioButtonId();
                if(currentPosition == (noOfQuestions - 1)) {
                    if (selRadioBtnId == question.getAnswer()) {
                        noOfCorrectAnswers++;
                    }

                    Intent statsIntent = new Intent(TriviaActivity.this, StatsActivity.class);
                    int percentage = Math.round((noOfCorrectAnswers * 100)/noOfQuestions);
                    statsIntent.putExtra(STATS_KEY,  Integer.valueOf(percentage).toString());
                    statsIntent.putParcelableArrayListExtra(STATS_LIST, questionsList);
                    startActivity(statsIntent);
                    finish();
                } else {
                    if (selRadioBtnId == question.getAnswer()) {
                        noOfCorrectAnswers++;
                    }
                    radioLayout.removeAllViews();
                    currentPosition++;
                    question = questionsList.get(currentPosition);

                    if(question.getImageUrl().isEmpty()) {
                        ((ImageView)findViewById(R.id.questionimage)).setImageDrawable(null);
                    } else {
                        new GetImage(TriviaActivity.this).execute(question.getImageUrl());
                    }
                    ((TextView) findViewById(R.id.qtnid)).setText("Q".concat((Integer.valueOf(question.getId())).toString()));
                    ((TextView) findViewById(R.id.question)).setText(question.getText());
                    createRadioButton(question.getId(), question.getChoices());
                }
            }
        });
    }

    //creating radio buttons
    private void createRadioButton(int questionId, List<String> choices)
    {
        RadioButton[] radioButton = new RadioButton[choices.size()];
        RadioGroup radioGroup = new RadioGroup(this); //create the RadioGroup
        radioGroup.setId(questionId + 10);
        radioGroup.setOrientation(RadioGroup.VERTICAL);
        for(int i = 1; i <= choices.size(); i++){
            radioButton[i-1]  = new RadioButton(this);
            radioGroup.addView(radioButton[i-1]);
            radioButton[i-1].setId(i + 0);
            radioButton[i-1].setText(choices.get(i-1));
        }
        radioLayout = (LinearLayout) findViewById(R.id.qtnlayout);
        radioLayout.addView(radioGroup);
    }
}
