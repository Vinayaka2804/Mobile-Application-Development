/*
Group#43 - Bharat Pothina, Vinayaka Narayan
HW# 4
GetImage.java
*/
package com.example.vinayakanarayan.triviaquiz;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.widget.ImageView;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by Vinayaka Narayan on 9/23/2016.
 */
public class GetImage extends AsyncTask<String,Void,Bitmap>{

    TriviaActivity triviaactivity;
    ProgressDialog imgLoadingProgress;
    ArrayList<Question> questions;

    public GetImage(TriviaActivity activity)
    {
        triviaactivity = activity;
    }

    public GetImage() {
    }

    @Override
    protected Bitmap doInBackground(String... params) {
        //Get String from URL//
        Bitmap image=null;
        URL url = null;
        try {
            url = new URL(params[0]);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.connect();

            int responseStatusCode = con.getResponseCode();
            if(responseStatusCode == HttpURLConnection.HTTP_OK)
            {
              image = BitmapFactory.decodeStream(con.getInputStream());
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        //Get String from URL//
        return image;

    }

    @Override
    protected void onPreExecute()
    {
        super.onPreExecute();
        imgLoadingProgress = new ProgressDialog(triviaactivity);
        imgLoadingProgress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        imgLoadingProgress.setTitle("Loading Image.");
        imgLoadingProgress.show();
    }

    @Override
    protected void onPostExecute(Bitmap img)
    {
        super.onPostExecute(img);
        imgLoadingProgress.dismiss();
        ((ImageView)triviaactivity.findViewById(R.id.questionimage)).setImageBitmap(img);
    }

}
