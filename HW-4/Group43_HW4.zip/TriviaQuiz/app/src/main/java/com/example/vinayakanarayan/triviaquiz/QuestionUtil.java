/*
Group#43 - Bharat Pothina, Vinayaka Narayan
HW# 4
QuestionUtil.java
*/
package com.example.vinayakanarayan.triviaquiz;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Vinayaka Narayan on 9/23/2016.
 */
public class QuestionUtil {

    static public class QuestionsJSONoarser
    {
        static ArrayList<Question> parseQuestions(String in) throws JSONException
        {
            ArrayList<Question> questionList = new ArrayList<Question>();
            JSONObject root = new JSONObject(in);
            JSONArray questionJSONArray = root.getJSONArray("questions");

            for(int i = 0; i < questionJSONArray.length(); i++)
            {
                JSONObject questionJSONObject = questionJSONArray.getJSONObject(i);
                int id = Integer.parseInt(questionJSONObject.getString("id"));
                String text = questionJSONObject.getString("text");
                String imageUrl = "";
                try {
                    imageUrl = questionJSONObject.getString("image");
                } catch(JSONException je) {
                    Log.d("No Image for id#: ", Integer.valueOf(i).toString());
                }

                JSONObject choicesJSONObject = questionJSONObject.getJSONObject("choices");
                int answer = Integer.parseInt(choicesJSONObject.getString("answer"));
                JSONArray choicesArray = choicesJSONObject.getJSONArray("choice");
                ArrayList<String> choices = new ArrayList<>();
                for(int k = 0; k < choicesArray.length(); k++)
                {
                    choices.add(choicesArray.getString(k));
                }
                Question question = new Question(id, text, imageUrl, answer, choices);
                questionList.add(question);
            }
            return questionList;
        }
    }
}
