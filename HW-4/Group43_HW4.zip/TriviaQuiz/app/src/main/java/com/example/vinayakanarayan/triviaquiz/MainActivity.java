/*
Group#43 - Bharat Pothina, Vinayaka Narayan
HW# 4
MainActivity.java
*/
package com.example.vinayakanarayan.triviaquiz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements GetQuestion.IData{

    public static String TRIVIA_KEY = "Trivia";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        new GetQuestion(this).execute("http://dev.theappsdr.com/apis/trivia_json/index.php");

        findViewById(R.id.exitbutton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    public void getQuestionsFromJson(final ArrayList<Question> result) {
        findViewById(R.id.startbutton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent triviaIntent = new Intent(MainActivity.this,TriviaActivity.class);
                triviaIntent.putParcelableArrayListExtra(TRIVIA_KEY, result);
                startActivity(triviaIntent);
                finish();
            }
        });
    }
}
