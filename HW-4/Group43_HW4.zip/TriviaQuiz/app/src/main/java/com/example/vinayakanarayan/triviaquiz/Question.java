/*
Group#43 - Bharat Pothina, Vinayaka Narayan
HW# 4
Question.java
*/
package com.example.vinayakanarayan.triviaquiz;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * Created by Vinayaka Narayan on 9/23/2016.
 */
public class Question implements Parcelable {

    private int id;
    private String text;
    private String imageUrl;
    private Integer answer;
    List<String> choices;

    public Question(int id, String text, String imageUrl, Integer answer, List<String> choices){
        super();
        this.id = id;
        this.text = text;
        this.imageUrl = imageUrl;
        this.answer = answer;
        this.choices = choices;
    }

    public int getId() {
        return id;
    }

    public String getText() {
        return text;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public Integer getAnswer() {
        return answer;
    }

    public List<String> getChoices() {
        return choices;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(text);
        dest.writeString(imageUrl);
        dest.writeInt(answer);
        dest.writeStringList(choices);
    }

    public static final Parcelable.Creator<Question> CREATOR = new Parcelable.Creator<Question>() {
        @Override
        public Question createFromParcel(Parcel in) {
            return new Question(in);
        }

        @Override
        public Question[] newArray(int size) {
            return new Question[size];
        }
    };

    private Question(Parcel in) {
        this.id = in.readInt();
        this.text = in.readString();
        this.imageUrl = in.readString();
        this.answer = in.readInt();
        this.choices = in.createStringArrayList();
    }

}
