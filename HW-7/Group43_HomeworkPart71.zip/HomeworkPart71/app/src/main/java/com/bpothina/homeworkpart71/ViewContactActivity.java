package com.bpothina.homeworkpart71;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;

public class ViewContactActivity extends AppCompatActivity {
    User user;

    private TextView fullName;
    private TextView displayName;
    private TextView email;
    private TextView phone;
    private ImageView profileImage;

    DatabaseReference firebaseDatabaseReference = FirebaseDatabase.getInstance().getReference();
    DatabaseReference usersDbRef;
    User loggedInUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_contact);
        usersDbRef = firebaseDatabaseReference.child("users");

        if (getIntent().getExtras() != null) {
            user = (User) getIntent().getExtras().getSerializable("CONTACT");//change to CONTACT
            loggedInUser = (User) getIntent().getExtras().getSerializable("PROFILE");
        }

        displayName = (TextView) findViewById(R.id.viewdisplayname);
        displayName.setText(user.getFullname());
        fullName = (TextView) findViewById(R.id.viewfullname);
        fullName.setText("Name: " + user.getFullname());
        email = (TextView) findViewById(R.id.viewemail);
        email.setText("Email: " + user.getEmail());
        phone = (TextView) findViewById(R.id.viewphone);
        phone.setText("Phone#: " + user.getPhoneNo());
        profileImage = (ImageView) findViewById(R.id.viewprofileimg);

        byte[] decodedString = Base64.decode(user.getProfilePic(), Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        profileImage.setImageBitmap(decodedByte);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_editprofile, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.EditProfileLogout:
                signOut();
                Intent intent = new Intent(ViewContactActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
                break;
            default:
                break;
        }
        return true;
    }

    private void signOut() {
        FirebaseAuth firebaseAuthentication = FirebaseAuth.getInstance();
        firebaseAuthentication.signOut();
    }
}
