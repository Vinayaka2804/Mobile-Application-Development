package com.bpothina.homeworkpart71;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;

import java.io.ByteArrayOutputStream;

public class EditProfileActivity extends AppCompatActivity {

    User user;

    private String selectedImagePath;
    private static final int SELECT_PICTURE = 1;
    private EditText fullName;
    private EditText email;
    private EditText phone;
    private EditText password;
    private ImageView profileImage;
    private Button buttonUpdate;
    private Button buttonCancel;

    DatabaseReference firebaseDatabaseReference = FirebaseDatabase.getInstance().getReference();
    DatabaseReference usersDbRef;
    String userSessionId = FirebaseAuth.getInstance().getCurrentUser().getUid();
    String strBase64;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        usersDbRef = firebaseDatabaseReference.child("users");

        if (getIntent().getExtras() != null) {
            user = (User) getIntent().getExtras().getSerializable("SHOW");
        }

        fullName = (EditText) findViewById(R.id.editfullname);
        fullName.setText(user.getFullname());
        email = (EditText) findViewById(R.id.editemail);
        email.setText(user.getEmail());
        phone = (EditText) findViewById(R.id.editphone);
        phone.setText(user.getPhoneNo());
        password = (EditText) findViewById(R.id.editpassword);
        password.setText(user.getPassword());
        profileImage = (ImageView) findViewById(R.id.editprofileimg);

        buttonUpdate = (Button) findViewById(R.id.edit_button_Update);
        buttonCancel = (Button) findViewById(R.id.edit_button_Cancel);

        byte[] decodedString = Base64.decode(user.getProfilePic(), Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        profileImage.setImageBitmap(decodedByte);
        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                        /*Intent i = new Intent(
                                Intent.ACTION_PICK,
                                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

                        startActivityForResult(i, RESULT_LOAD_IMAGE);*/
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent,"Select Picture"), SELECT_PICTURE);
            }
        });

        buttonUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //String userSessionId = user.getUid();
                user = new User();
                user.setPhoneNo(phone.getText().toString());
                user.setEmail(email.getText().toString());
                user.setFullname(fullName.getText().toString());
                user.setPassword(password.getText().toString());
                user.setUid(userSessionId);

                ImageView iv1 = (ImageView) findViewById(R.id.editprofileimg);
                BitmapDrawable drawable = (BitmapDrawable) iv1.getDrawable();
                Bitmap bitmap = drawable.getBitmap();
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                byte[] image = stream.toByteArray();
                String image_str = Base64.encodeToString(image, 0);

                user.setProfilePic(image_str);

                //update the database
                firebaseDatabaseReference.child("users").child(user.getUid()).setValue(user);
                Toast.makeText(EditProfileActivity.this, "Profile Updated", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(EditProfileActivity.this, UserListActivity.class);
                startActivity(intent);
                finish();
            }
        });

        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EditProfileActivity.this, UserListActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            if (requestCode == SELECT_PICTURE) {
                Uri selectedImageUri = data.getData();
                selectedImagePath = getPath(selectedImageUri);
                System.out.println("Image Path : " + selectedImagePath);
                profileImage.setImageURI(selectedImageUri);
            }
        }
    }

    public String getPath(Uri uri) {
        String[] projection = { MediaStore.Images.Media.DATA };
        Cursor cursor = managedQuery(uri, projection, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_editprofile,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // action with ID action_settings was selected
            case R.id.EditProfileLogout:
                signOut();
                Intent intent = new Intent(EditProfileActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
                break;
            default:
                break;
        }
        return true;
    }

    private void signOut() {
        FirebaseAuth firebaseAuthentication = FirebaseAuth.getInstance();
        firebaseAuthentication.signOut();
    }
}
