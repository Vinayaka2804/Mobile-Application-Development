package com.bpothina.homeworkpart71;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class ListViewAdapter extends ArrayAdapter<User> {

    List<User> userData;
    Context mContext;
    int mResource;
    User user;

    public ListViewAdapter(Context context, int resource, List<User> users) {
        super(context, resource, users);
        this.mContext = context;
        this.userData = users;
        this.mResource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(mResource, parent, false);
        }

        user = userData.get(position);

        ImageView imageView = (ImageView) convertView.findViewById(R.id.userlistimage);
        byte[] decodedString = Base64.decode(user.getProfilePic(), Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        imageView.setImageBitmap(decodedByte);

        TextView textViewExpenseName = (TextView) convertView.findViewById(R.id.userlistfullname);
        textViewExpenseName.setText(user.getFullname());

        ImageView readIcon = (ImageView) convertView.findViewById(R.id.userlistreadimage);
        if (user.isRead()) {
            readIcon.setVisibility(View.INVISIBLE);
        } else {
            readIcon.setVisibility(View.VISIBLE);
        }

        return convertView;
    }
}