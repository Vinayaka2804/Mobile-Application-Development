package com.bpothina.homeworkpart71;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

/**
 * Created by BhaBhaHP on 11/20/2016.
 */

public class Message implements Serializable,Parcelable
{
    String senderName;
    String receiverName;
    String messageText;
    String messageImage;
    String timeStamp;
    String pushId;
    boolean messageRead;
    boolean deleted;
    String sender;
    String receiver;

    protected Message(Parcel in) {
        senderName = in.readString();
        receiverName = in.readString();
        messageText = in.readString();
        messageImage = in.readString();
        timeStamp = in.readString();
        pushId = in.readString();
        messageRead = in.readByte() != 0;
        deleted = in.readByte() != 0;
        sender = in.readString();
        receiver = in.readString();

    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(senderName);
        dest.writeString(receiverName);
        dest.writeString(messageText);
        dest.writeString(messageImage);
        dest.writeString(timeStamp);
        dest.writeString(pushId);
        dest.writeByte((byte) (messageRead ? 1 : 0));
        dest.writeByte((byte) (deleted ? 1 : 0));
        dest.writeString(sender);
        dest.writeString(receiver);

    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Message> CREATOR = new Creator<Message>() {
        @Override
        public Message createFromParcel(Parcel in) {
            return new Message(in);
        }

        @Override
        public Message[] newArray(int size) {
            return new Message[size];
        }
    };

    public Message(String senderName, String receiverName, String messageText,
                   String messageImage, String timeStamp, String pushId, boolean messageRead,
                   boolean deleted, String sender, String receiver) {
        this.senderName = senderName;
        this.receiverName = receiverName;
        this.messageText = messageText;
        this.messageImage = messageImage;
        this.timeStamp = timeStamp;
        this.pushId = pushId;
        this.messageRead = messageRead;
        this.deleted = deleted;
        this.sender = sender;
        this.receiver = receiver;

    }

    public Message() {

    }

    @Override
    public String toString() {
        return "Message{" +
                "senderName='" + senderName + '\'' +
                ", receiverName='" + receiverName + '\'' +
                ", messageText='" + messageText + '\'' +
                ", messageImage='" + messageImage + '\'' +
                ", timeStamp='" + timeStamp + '\'' +
                ", pushId='" + pushId + '\'' +
                ", messageRead=" + messageRead +
                ", deleted=" + deleted +
                ", sender='" + sender + '\'' +
                ", receiver='" + receiver + '\'' +
                '}';
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public String getMessageText() {
        return messageText;
    }

    public void setMessageText(String messageText) {
        this.messageText = messageText;
    }

    public String getMessageImage() {
        return messageImage;
    }

    public void setMessageImage(String messageImage) {
        this.messageImage = messageImage;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getPushId() {
        return pushId;
    }

    public void setPushId(String pushId) {
        this.pushId = pushId;
    }

    public boolean isMessageRead() {
        return messageRead;
    }

    public void setMessageRead(boolean messageRead) {
        this.messageRead = messageRead;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }
}
