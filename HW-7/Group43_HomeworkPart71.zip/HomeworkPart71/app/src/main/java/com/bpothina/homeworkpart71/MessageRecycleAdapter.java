package com.bpothina.homeworkpart71;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by BhaBhaHP on 11/22/2016.
 */

public class MessageRecycleAdapter extends
        RecyclerView.Adapter<MessageRecycleAdapter.ViewHolder> {

    private ArrayList<Message> mMessages;
    private Context mContext;
    Message msg;
    public MyAdapterListener onClickListener;

    ViewHolder viewHolder;

    public MessageRecycleAdapter(Context context, ArrayList<Message> msgs, MyAdapterListener listener) {
        mMessages = msgs;
        mContext = context;
        this.onClickListener = listener;
    }

    private Context getContext() {
        return mContext;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView messageName;
        public TextView messageText;
        public TextView messageTime;
        public ImageView imageview;
        public ImageView deleteBtn;

        public ViewHolder(View itemView) {
            super(itemView);
            messageName = (TextView) itemView.findViewById(R.id.msgName);
            messageText = (TextView) itemView.findViewById(R.id.msgText);
            messageTime = (TextView) itemView.findViewById(R.id.msgTime);
            imageview = (ImageView) itemView.findViewById(R.id.msgImage);
            deleteBtn = (ImageView) itemView.findViewById(R.id.msgDeleteBtn);
        }
    }

    @Override
    public MessageRecycleAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View msgView = inflater.inflate(R.layout.messages, parent, false);
        viewHolder = new ViewHolder(msgView);
        return viewHolder;
    }


    @Override
    public void onBindViewHolder(MessageRecycleAdapter.ViewHolder viewHolder, final int position) {
       msg = mMessages.get(position);

        viewHolder.deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickListener.deleteOnClick(v, position);
            }
        });

        TextView msgName = viewHolder.messageName;
        msgName.setText(msg.getReceiver());

        TextView msgText = viewHolder.messageText;
        if(msg.getMessageText() != null) {
            msgText.setText(msg.getMessageText());
        }

        TextView msgTime = viewHolder.messageTime;
        msgTime.setText(msg.getTimeStamp());

        if(msg.getMessageImage() != null && !msg.getMessageImage().isEmpty()) {
            byte[] decodedString = Base64.decode(msg.getMessageImage(), Base64.DEFAULT);
            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            viewHolder.imageview.setImageBitmap(decodedByte);
            //Picasso.with(mContext).load(msg.getMessageImage()).into(viewHolder.imageview);
        }

    }

    @Override
    public int getItemCount() {
        return mMessages.size();
    }

    public interface MyAdapterListener {
        void deleteOnClick(View v, int position);
    }
}
