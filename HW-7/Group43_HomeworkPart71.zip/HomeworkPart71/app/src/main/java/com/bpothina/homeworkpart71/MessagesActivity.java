package com.bpothina.homeworkpart71;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Base64;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class MessagesActivity extends AppCompatActivity {

    User contactUser;
    User loggedInUser;
    private String selectedImagePath;
    ImageView replyImage;
    private static final String DISPLAY_USER = "CONTACT";
    private static final String PROFILE_USER = "PROFILE";
    boolean replied = false;
    boolean imagereplied = false;
    int messageCount = 0;
    ArrayList<Message> displayMessages = new ArrayList<Message>();
    MessageRecycleAdapter adapter;
    RecyclerView recycleView;
    Message deletedMessage;
    String userSessionId;


    Button replyImageBtn;
    DatabaseReference firebaseDatabaseReference = FirebaseDatabase.getInstance().getReference();
    DatabaseReference ref = firebaseDatabaseReference.child("messages");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_messages);

        loggedInUser = (User) getIntent().getExtras().getSerializable(PROFILE_USER);
        userSessionId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        contactUser = (User) getIntent().getExtras().getSerializable(DISPLAY_USER);
        messageCount = getIntent().getIntExtra("MESSAGECOUNT", 0);
        //displayMessages = getIntent().getExtras().getParcelableArrayList("MESSAGES");

        loggedInUser.setRead(false);
        firebaseDatabaseReference.child("users").child(userSessionId).setValue(loggedInUser);

        Thread thread = new Thread(new DoWorkMessage());
        thread.start();



        getValueRef();
        Button inbox = (Button) findViewById(R.id.InboxBack);
        inbox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateBackToInbox();
            }
        });

        Button send = (Button) findViewById(R.id.replyButton);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String textreply = ((EditText)findViewById(R.id.txtReply)).getText().toString().trim();
                if(TextUtils.isEmpty(textreply)){
                    replied = false;
                } else {
                    replied = true;
                }

                if(imagereplied || replied) {
                    String image_str = "";
                    if(imagereplied) {
                        ImageView iv1 = (ImageView) findViewById(R.id.imgViewReplyImage);
                        BitmapDrawable drawable = (BitmapDrawable) iv1.getDrawable();
                        Bitmap bitmap = drawable.getBitmap();
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                        byte[] image = stream.toByteArray();
                        image_str = Base64.encodeToString(image, 0);
                    }

                    SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
                    messageCount++;
                    Message message = new Message(loggedInUser.getUid(), contactUser.getUid(),
                            textreply, image_str, dateFormat.format(new Date()),
                            loggedInUser.getUid().concat("=").concat(contactUser.getUid()).concat("=").concat("Message=").concat(messageCount + ""),
                            false, false, loggedInUser.getFullname(), contactUser.getFullname());
                    firebaseDatabaseReference.child("messages").child(message.getPushId()).setValue(message);

                } else {
                    Toast.makeText(MessagesActivity.this, "Empty reply. Please select an image or enter text.",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });




        /*byte[] decodedString = Base64.decode(user.getProfilePic(), Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);*/
        replyImage = (ImageView) findViewById(R.id.imgViewReplyImage);
        replyImageBtn = (Button) findViewById(R.id.btnReplyImage);
        //replyImage.setImageBitmap(decodedByte);
        replyImageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                        /*Intent i = new Intent(
                                Intent.ACTION_PICK,
                                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

                        startActivityForResult(i, RESULT_LOAD_IMAGE);*/
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent,"Attach Image"), 2);
            }
        });

        assignRecyclerView();

    }

    private void navigateBackToInbox(){
        Intent intent = new Intent(MessagesActivity.this,UserListActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_contact,menu);
        return true;
    }

    private void getValueRef(){
        for(int i=0; i<=1000; i++) {

        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.ViewContact:
                Intent editIntent = new Intent(MessagesActivity.this, ViewContactActivity.class);
                Bundle expenseBundle = new Bundle();
                expenseBundle.putSerializable(PROFILE_USER, loggedInUser);
                expenseBundle.putSerializable(DISPLAY_USER, contactUser);
                editIntent.putExtras(expenseBundle);
                startActivity(editIntent);
                finish();
                break;
            case R.id.ContactLogout:
                signOut();
                Intent intent = new Intent(MessagesActivity.this,LoginActivity.class);
                startActivity(intent);
                finish();
                break;
            default:
                break;
        }
        return true;
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            if (requestCode == 2) {
                Uri selectedImageUri = data.getData();
                selectedImagePath = getPath(selectedImageUri);
                System.out.println("Image Path : " + selectedImagePath);
                replyImage.setImageURI(selectedImageUri);
                imagereplied = true;
            }
        }
    }

    public String getPath(Uri uri) {
        String[] projection = { MediaStore.Images.Media.DATA };
        Cursor cursor = managedQuery(uri, projection, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }

    private void signOut() {
        FirebaseAuth firebaseAuthentication = FirebaseAuth.getInstance();
        firebaseAuthentication.signOut();
    }

    private void assignRecyclerView() {
        recycleView = (RecyclerView) findViewById(R.id.chatRecycleView);
        adapter = new MessageRecycleAdapter(this, displayMessages, new MessageRecycleAdapter.MyAdapterListener() {
            @Override
            public void deleteOnClick(View v, int position) {
                deletedMessage = displayMessages.get(position);
                displayMessages.remove(position);

                recycleView.removeViewAt(position);
                adapter.notifyItemRemoved(position);
                adapter.notifyItemRangeChanged(0, displayMessages.size());

                Query msgsQuery;
                msgsQuery = firebaseDatabaseReference.child("messages").orderByChild("pushId")
                            .equalTo(deletedMessage.pushId);

                msgsQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for (DataSnapshot msgSnapshot : dataSnapshot.getChildren()) {
                            msgSnapshot.getRef().removeValue();
                        }
                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }
        });

        recycleView.setAdapter(adapter);
        recycleView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
    }

    class DoWorkMessage implements Runnable {
        @Override
        public void run() {
            ref.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    for (DataSnapshot data : dataSnapshot.getChildren()) {
                        Message msg = data.getValue(Message.class);
                        if (msg.getSenderName().equalsIgnoreCase(loggedInUser.getUid())
                                && (msg.getReceiverName().equalsIgnoreCase(contactUser.getUid()))) {
                            /*String[] pushId = msg.getPushId().split("=");
                            if(messageCount > tempCount) {
                                tempCount = messageCount;
                                messageCount = Integer.valueOf(pushId[3]);
                            } else if(messageCount == 0) {
                                messageCount = Integer.valueOf(pushId[3]);
                                tempCount = messageCount;
                            }*/
                        } else if (msg.getSenderName().equalsIgnoreCase(contactUser.getUid())
                                && (msg.getReceiverName().equalsIgnoreCase(loggedInUser.getUid()))){
                            displayMessages.add(msg);
                        }
                    }
                   //resultVal.put(messageCount, displayMessages);
                    ref.removeEventListener(this);

                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }
    }
}
