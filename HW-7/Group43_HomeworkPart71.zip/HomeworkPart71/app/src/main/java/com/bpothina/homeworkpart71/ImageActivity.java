package com.bpothina.homeworkpart71;

import android.graphics.Bitmap;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.util.UUID;

public class ImageActivity extends AppCompatActivity {

    FirebaseStorage storage = FirebaseStorage.getInstance();
    private static final String USER_SESSION_ID = "UID";
    private String userSessionId;

    private ImageView imageView;
    private TextView overLayText;
    private ProgressBar progressBar;
    private Button uploadButton;
    private TextView downloadUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image);

        imageView = (ImageView)findViewById(R.id.imageView);
        overLayText = (TextView)findViewById(R.id.overlaytext);
        overLayText.setText("");
        overLayText.setVisibility(View.INVISIBLE);

        EditText textInpout = (EditText) findViewById(R.id.editText);
        textInpout.addTextChangedListener(new InputTextWatcher());

        uploadButton = (Button) findViewById(R.id.btn);
        uploadButton.setOnClickListener(new UploadOnClickListener());

        progressBar = (ProgressBar) findViewById(R.id.progressBar3);
        progressBar.setVisibility(View.GONE);
        downloadUrl = (TextView) findViewById(R.id.downloadUrl);

        userSessionId = getIntent().getStringExtra(USER_SESSION_ID);
    }

    private class UploadOnClickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            imageView.setDrawingCacheEnabled(true);
            imageView.buildDrawingCache();
            Bitmap bitmap = imageView.getDrawingCache();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
            byte[] data = baos.toByteArray();

            String path = "firepbimages/" + UUID.randomUUID() + ".png";
            StorageReference imagesRef = storage.getReference(path);

            StorageMetadata metadata = new StorageMetadata.Builder()
                    .setCustomMetadata("text", overLayText.getText().toString())
                    .build();

            progressBar.setVisibility(View.VISIBLE);
            uploadButton.setEnabled(false);

            UploadTask uploadImagesTask = imagesRef.putBytes(data, metadata);
            uploadImagesTask.addOnSuccessListener(ImageActivity.this, new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    // taskSnapshot.getMetadata() contains file metadata such as size, content-type, and download URL.

                    progressBar.setVisibility(View.INVISIBLE);
                    uploadButton.setEnabled(true);
                    Uri url = taskSnapshot.getDownloadUrl();
                    downloadUrl.setText(url.toString());
                    Log.d("downloadUrl:", url.toString());
                }
            });
        }
    }

    private class InputTextWatcher implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            overLayText.setVisibility(s.length() > 0 ? View.VISIBLE : View.INVISIBLE);
            overLayText.setText(s.toString());
        }
    }
}
