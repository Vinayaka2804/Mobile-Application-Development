package com.bpothina.homeworkpart71;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.RunnableFuture;

public class UserListActivity extends AppCompatActivity{

    final ArrayList<User> usersArrayList = new ArrayList<>();
    private ListView userListView;
    private static final String DISPLAY_USER = "CONTACT";
    private static final String PROFILE_USER = "PROFILE";
    User currentUser;
    private ListViewAdapter adapter;
    int messageCount = 0;
    ArrayList<Message> displayMessages = new ArrayList<Message>();
    User contactUser;
    int selectedPosition;
    Map <Integer, ArrayList<Message>> resultVal = new HashMap<Integer, ArrayList<Message>>();

    DatabaseReference firebaseDatabaseReference = FirebaseDatabase.getInstance().getReference();
    DatabaseReference usersDbRef;
    DatabaseReference ref = firebaseDatabaseReference.child("messages");
    String userSessionId = FirebaseAuth.getInstance().getCurrentUser().getUid();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_list);

        usersDbRef = firebaseDatabaseReference.child("users");

        userListView = (ListView) findViewById(R.id.userlisview);

        usersDbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot data : dataSnapshot.getChildren()) {
                    User user = data.getValue(User.class);
                    if (user.getUid().equalsIgnoreCase(userSessionId)) {
                        currentUser = user;
                    } else {
                        usersArrayList.add(user);
                    }
                }

                adapter = new ListViewAdapter
                        (UserListActivity.this, R.layout.userlist, usersArrayList);
                userListView.setAdapter(adapter);
                adapter.setNotifyOnChange(true);

                userListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        selectedPosition = position;
                        contactUser = usersArrayList.get(position);

                        Thread thread = new Thread(new DoWork());
                        thread.start();

                    }
                });
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_user,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.EditProfile:
                Intent editIntent = new Intent(UserListActivity.this, EditProfileActivity.class);
                Bundle expenseBundle = new Bundle();
                expenseBundle.putSerializable(DISPLAY_USER, currentUser);
                editIntent.putExtras(expenseBundle);
                startActivity(editIntent);
                finish();
                break;
            case R.id.Logout:
                signOut();
                Intent intent = new Intent(UserListActivity.this,LoginActivity.class);
                startActivity(intent);
                finish();
                break;
            default:
                break;
        }
        return true;
    }

    private void signOut() {
        FirebaseAuth firebaseAuthentication = FirebaseAuth.getInstance();
        firebaseAuthentication.signOut();
    }


    class DoWork implements Runnable {
        @Override
        public void run() {
            ref.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    int tempCount = 0;
                    for (DataSnapshot data : dataSnapshot.getChildren()) {
                        Message msg = data.getValue(Message.class);
                        if (msg.getSenderName().equalsIgnoreCase(currentUser.getUid())
                                && (msg.getReceiverName().equalsIgnoreCase(contactUser.getUid()))) {
                            String[] pushId = msg.getPushId().split("=");
                            if(messageCount > tempCount) {
                                tempCount = messageCount;
                                messageCount = Integer.valueOf(pushId[3]);
                            } else if(messageCount == 0) {
                                messageCount = Integer.valueOf(pushId[3]);
                                tempCount = messageCount;
                            }
                        } else if (msg.getSenderName().equalsIgnoreCase(contactUser.getUid())
                                && (msg.getReceiverName().equalsIgnoreCase(currentUser.getUid()))){
                            displayMessages.add(msg);
                        }
                    }
                    resultVal.put(messageCount, displayMessages);
                    ref.removeEventListener(this);

                    Intent showExpenseIntent = new Intent(UserListActivity.this, MessagesActivity.class);
                    Bundle expenseBundle = new Bundle();
                    expenseBundle.putSerializable(DISPLAY_USER, usersArrayList.get(selectedPosition));
                    expenseBundle.putSerializable(PROFILE_USER, currentUser);
                    showExpenseIntent.putExtra("MESSAGECOUNT", messageCount);
                    //xpenseBundle.putParcelableArrayList("MESSAGES", displayMessages);
                    //showExpenseIntent.putParcelableArrayListExtra("MESSAGES", displayMessages);
                    showExpenseIntent.putExtras(expenseBundle);
                    startActivity(showExpenseIntent);
                    finish();


                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }
    }
}
