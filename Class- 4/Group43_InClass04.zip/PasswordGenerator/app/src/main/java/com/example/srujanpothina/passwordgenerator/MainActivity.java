/*
InClass# 04
Bharat Pothina, Vinayaka Narayan
 */

package com.example.srujanpothina.passwordgenerator;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    List<String> passwordList = new ArrayList<String>();
    List<String> asynpasswordList = new ArrayList<String>();
    int passwordCount;
    int passwordLength;
    ExecutorService threadPool;
    ProgressDialog progressDialog;
    Handler handler;
    int status = 0;

    String password;
    CharSequence[] threadPasswords;
    CharSequence[] asyncPasswords;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //status = 0;
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Generating Passwords ...");
        progressDialog.setMax(100);
        progressDialog.setCancelable(false);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        threadPool = Executors.newFixedThreadPool(2);

        SeekBar passwordCountSeek = (SeekBar) findViewById(R.id.seekBar1);

        SeekBar passwordLengthSeek = (SeekBar) findViewById(R.id.seekBar2);

        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                switch (msg.what) {
                    case DoWork.STATUS_START:
                        progressDialog.show();
                        break;
                    case DoWork.STATUS_STEP:
                        progressDialog.setProgress((Integer) msg.obj);
                        break;
                    case DoWork.STATUS_DONE:
                        status = 1;
                        progressDialog.dismiss();
                        Log.d("here", "here");
                        threadPasswords = passwordList.toArray(new CharSequence[passwordList.size()]);
                        AlertDialog.Builder dropList = new AlertDialog.Builder(MainActivity.this);
                        dropList.setTitle("Passwords")
                                .setItems(threadPasswords, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        password = (String) threadPasswords[which];
                                        ((TextView)findViewById(R.id.passwordValue)).setText(password);
                                    }
                                });

                        final AlertDialog listPopulated = dropList.create();
                        listPopulated.show();

                        break;
                }
                return false;
            }
        });

        findViewById(R.id.button1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("test1","Test1");

                threadPool.execute(new DoWork());
            }
        });

        findViewById(R.id.button2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("test1","Test1");

                new DoAsyncWork().execute();

            }
        });

        passwordCountSeek.setMax(10);
        if (passwordCountSeek != null) {
            passwordCountSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    int yourStep = 1;
                    progress = ((int) Math.round(progress / yourStep)) * yourStep;
                    TextView seekBarValue = (TextView) findViewById(R.id.passwordCount);
                    seekBarValue.setText(Integer.valueOf(progress).toString());
                    passwordCount = progress;
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                }
            });
        }

        passwordLengthSeek.setMax(23);
        if (passwordLengthSeek != null) {
            passwordLengthSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    int yourStep = 1;
                    progress = ((int) Math.round(progress / yourStep)) * yourStep;
                    TextView seekBarValue = (TextView) findViewById(R.id.pwdLength);
                    seekBarValue.setText(Integer.valueOf(progress).toString());
                    passwordLength = progress;
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                }
            });
        }
    }

    class DoWork implements Runnable {
        static final int STATUS_START = 0x00;
        static final int STATUS_STEP = 0x01;
        static final int STATUS_DONE = 0x02;

        @Override
        public void run() {
            Message msg = new Message();
            msg.what = STATUS_START;
            handler.sendMessage(msg);

            for(int i = 0; i < passwordCount; i++) {
                String password = Util.getPassword(passwordLength);
                passwordList.add(password);
                Log.d("password is:", password);
                msg = new Message();
                msg.what = STATUS_STEP;
                msg.obj = i + 1;

                Bundle data = new Bundle();
                data.putInt("PROGRESS", i+1);
                msg.setData(data);
                handler.sendMessage(msg);
            }
            msg = new Message();
            msg.what = STATUS_DONE;
            handler.sendMessage(msg);
        }
    }


    class DoAsyncWork extends AsyncTask<Void, Integer, Void> {
        @Override
        protected Void doInBackground(Void... params) {
            for(int i = 0; i < passwordCount; i++) {
                String password = Util.getPassword(passwordLength);
                asynpasswordList.add(password);
                Log.d("password is:", password);
                publishProgress(i + 1);
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            progressDialog.dismiss();
            asyncPasswords = asynpasswordList.toArray(new CharSequence[asynpasswordList.size()]);
            AlertDialog.Builder dropList = new AlertDialog.Builder(MainActivity.this);
            dropList.setTitle("Passwords")
                    .setItems(asyncPasswords, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            password = (String) asyncPasswords[which];
                            ((TextView) findViewById(R.id.passwordValue)).setText(password);
                        }
                    });

            final AlertDialog listPopulated = dropList.create();
            listPopulated.show();
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(MainActivity.this);
            progressDialog.setMessage("Generating Passwords ...");
            progressDialog.setMax(100);
            progressDialog.setCancelable(false);
            progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            progressDialog.show();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            progressDialog.setProgress(values[0]);
        }


    }
}
