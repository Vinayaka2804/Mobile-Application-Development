package com.bpothina.inclass13;

import io.realm.RealmObject;

public class Cat extends RealmObject {
    public  String name;
}