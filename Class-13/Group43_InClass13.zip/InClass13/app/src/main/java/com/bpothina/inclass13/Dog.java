package com.bpothina.inclass13;

import io.realm.RealmObject;

public class Dog extends RealmObject {
    public String name;
}