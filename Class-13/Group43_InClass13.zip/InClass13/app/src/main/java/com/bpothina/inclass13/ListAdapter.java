package com.bpothina.inclass13;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by BhaBhaHP on 12/5/2016.
 */

public class ListAdapter extends ArrayAdapter<Expense> {

    Context mContext;
    List<Expense> mObjects;
    int mResource;

    public ListAdapter(Context context, int resource, List<Expense> objects) {
        super(context, resource, objects);
        this.mContext = context;
        this.mObjects = objects;
        this.mResource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.expenses, parent, false);
        }

        Expense expense = mObjects.get(position);
        TextView textView = (TextView) convertView.findViewById(R.id.expnamelistview);
        textView.setText(expense.getName());

        TextView textView2 = (TextView) convertView.findViewById(R.id.expamntlistview);
        textView2.setText("$" + expense.getPrice() + "");

        return convertView;
    }

}
