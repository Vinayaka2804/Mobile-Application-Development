/*
Group 43 - Bharat Pothina, Vinayaka Narayan
InClass 10
ExpenseListActivity.java
 */

package com.bpothina.inclass10;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ExpenseListActivity extends AppCompatActivity {

    private static final String USER_SESSION_ID = "UID";
    private static final String DISPLAY_EXPENSE = "SHOW";

    private ArrayList<Expense> expenseList = new ArrayList<Expense>();
    private Expense deletedExpenseObj;
    private ListView expenseListView;
    private String uid;
    private ExpenseListAdapter adapter;
    private boolean isListModified = false;

    DatabaseReference firebaseDatabaseReference = FirebaseDatabase.getInstance().getReference();
    DatabaseReference expensesDatabaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense_list);

        expensesDatabaseReference = firebaseDatabaseReference.child("expenses");
        uid = getIntent().getStringExtra(USER_SESSION_ID);

        ImageButton addExpenseImageButton = (ImageButton) findViewById(R.id.addexpensebtn);
        addExpenseImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ExpenseListActivity.this, AddExpenseActivity.class);
                i.putExtra(USER_SESSION_ID, uid);
                startActivity(i);
                finish();
            }
        });

        expenseListView = (ListView) findViewById(R.id.expenseListView);

        expensesDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (isListModified) {
                    expenseList = new ArrayList<Expense>();
                }
                for (DataSnapshot data : dataSnapshot.getChildren()) {
                    Expense expense = data.getValue(Expense.class);
                    if (expense.getUid().equalsIgnoreCase(uid)) {
                        expenseList.add(expense);
                    }
                }

                if (expenseList.isEmpty()) {
                    findViewById(R.id.noExpenseLbl).setVisibility(View.VISIBLE);
                } else {
                    findViewById(R.id.noExpenseLbl).setVisibility(View.INVISIBLE);
                }

                adapter = new ExpenseListAdapter
                        (ExpenseListActivity.this, R.layout.expenses_listview, expenseList);
                expenseListView.setAdapter(adapter);
                adapter.setNotifyOnChange(true);

                expenseListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Intent showExpenseIntent = new Intent(ExpenseListActivity.this, ShowExpenseActivity.class);
                        Bundle expenseBundle = new Bundle();
                        expenseBundle.putSerializable(DISPLAY_EXPENSE, expenseList.get(position));
                        showExpenseIntent.putExtras(expenseBundle);
                        startActivity(showExpenseIntent);
                        finish();
                    }
                });

                expenseListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                        isListModified = true;
                        deletedExpenseObj = expenseList.get(position);
                        expensesDatabaseReference = firebaseDatabaseReference.child("expenses");
                        expensesDatabaseReference.child(uid.concat(deletedExpenseObj.getExpenseName())).setValue(null);

                        if (expenseList.isEmpty()) {
                            findViewById(R.id.noExpenseLbl).setVisibility(View.VISIBLE);
                        } else {
                            findViewById(R.id.noExpenseLbl).setVisibility(View.INVISIBLE);
                            adapter.remove(deletedExpenseObj);
                            adapter.notifyDataSetChanged();
                            Toast.makeText(ExpenseListActivity.this, "Expense Deleted",
                                    Toast.LENGTH_SHORT).show();
                        }
                        return false;
                    }
                });
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }
}