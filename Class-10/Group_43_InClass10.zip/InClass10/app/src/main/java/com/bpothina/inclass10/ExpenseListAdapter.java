/*
Group 43 - Bharat Pothina, Vinayaka Narayan
InClass 10
ExpenseListAdapter.java
 */

package com.bpothina.inclass10;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class ExpenseListAdapter extends ArrayAdapter<Expense> {

    List<Expense> expenseData;
    Context mContext;
    int mResource;

    public ExpenseListAdapter(Context context, int resource, List<Expense> expenseList) {
        super(context, resource, expenseList);
        this.mContext = context;
        this.expenseData = expenseList;
        this.mResource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(mResource, parent, false);
        }

        Expense expense = expenseData.get(position);

        TextView textViewExpenseName = (TextView) convertView.findViewById(R.id.expensenamelistview);
        textViewExpenseName.setText(expense.getExpenseName());

        TextView textViewAmount = (TextView) convertView.findViewById(R.id.expenselistviewamont);
        textViewAmount.setText("$ " + expense.getAmount());

        return convertView;
    }
}