/*
Group 43 - Bharat Pothina, Vinayaka Narayan
InClass 10
ShowExpenseActivity.java
 */

package com.bpothina.inclass10;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class ShowExpenseActivity extends AppCompatActivity {

    private static final String DISPLAY_EXPENSE = "SHOW";
    private static final String USER_SESSION_ID = "UID";
    private Expense displaySelectedExpense;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_expense);

        displaySelectedExpense = (Expense) getIntent().getExtras().getSerializable(DISPLAY_EXPENSE);

        TextView expenseName = (TextView) findViewById(R.id.detailsnametxct);
        TextView expenseCategory = (TextView) findViewById(R.id.detailscattxt);
        TextView expenseAmount = (TextView) findViewById(R.id.detailsamnttxt);
        TextView expenseAddedDate = (TextView) findViewById(R.id.detailsdatetxt);

        expenseName.setText(displaySelectedExpense.getExpenseName());
        expenseCategory.setText(displaySelectedExpense.getCategory());
        expenseAmount.setText("$ " + displaySelectedExpense.getAmount());
        expenseAddedDate.setText(displaySelectedExpense.getDateAdded());

        Button closeButton = (Button) findViewById(R.id.closebtn);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent expenseListIntent = new Intent(ShowExpenseActivity.this, ExpenseListActivity.class);
                expenseListIntent.putExtra(USER_SESSION_ID, displaySelectedExpense.getUid());
                startActivity(expenseListIntent);
                finish();
            }
        });

        Button signOutButton = (Button) findViewById(R.id.signoutbutton);
        signOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signOut();
                Intent loginIntent = new Intent(ShowExpenseActivity.this, LoginActivity.class);
                startActivity(loginIntent);
                finish();
            }
        });
    }

    private void signOut() {
        FirebaseAuth firebaseAuthentication = FirebaseAuth.getInstance();
        firebaseAuthentication.signOut();
    }
}
