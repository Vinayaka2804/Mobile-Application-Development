/*
Group 43 - Bharat Pothina, Vinayaka Narayan
InClass 10
SignupActivity.java
 */

package com.bpothina.inclass10;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignupActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "SignupActivity";

    private FirebaseUser firebaseUser;
    private FirebaseAuth firebaseAuthentication;
    private FirebaseAuth.AuthStateListener firebaseAuthenticationListener;

    private EditText signupEmail;
    private EditText signupPassword;
    private EditText signupFullName;
    private String userSessionId;

    DatabaseReference firebaseDatabaseReference = FirebaseDatabase.getInstance().getReference();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        signupEmail = (EditText) findViewById(R.id.signupEmailTxt);
        signupPassword = (EditText) findViewById(R.id.signupPwdText);
        signupFullName = (EditText) findViewById(R.id.fullNameText);

        findViewById(R.id.signupbtn).setOnClickListener(this);
        findViewById(R.id.cancelBtn).setOnClickListener(this);

        firebaseAuthentication = FirebaseAuth.getInstance();

        firebaseAuthenticationListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                firebaseUser = firebaseAuth.getCurrentUser();
                if (firebaseUser != null) {
                    // User is signed in
                    userSessionId = firebaseUser.getUid();
                    Log.d(TAG, "onAuthStateChanged: Signed In sessionId: " + userSessionId);
                } else {
                    // User is signed out
                    userSessionId = "";
                    Log.d(TAG, "onAuthStateChanged:signed_out");
                }
            }
        };
    }

    @Override
    public void onStart() {
        super.onStart();
        firebaseAuthentication.addAuthStateListener(firebaseAuthenticationListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (firebaseAuthenticationListener != null) {
            firebaseAuthentication.removeAuthStateListener(firebaseAuthenticationListener);
        }
    }

    private boolean validateForm() {
        boolean valid = true;

        String email = signupEmail.getText().toString().trim();
        if (TextUtils.isEmpty(email)) {
            signupEmail.setError("Required.");
            valid = false;
        } else {
            signupEmail.setError(null);
        }

        String password = signupPassword.getText().toString().trim();
        if (TextUtils.isEmpty(password)) {
            signupPassword.setError("Required.");
            valid = false;
        } else {
            signupPassword.setError(null);
        }

        String fullName = signupFullName.getText().toString().trim();
        if (TextUtils.isEmpty(fullName)) {
            signupFullName.setError("Required.");
            valid = false;
        } else {
            signupFullName.setError(null);
        }
        return valid;
    }

    @Override
    public void onClick(View v) {
        int viewId = v.getId();
        if (viewId == R.id.signupbtn) {
            createNewUserAccount(signupEmail.getText().toString().trim(),
                    signupPassword.getText().toString().trim());
        } else if (viewId == R.id.cancelBtn) {
            Intent loginIntent = new Intent(SignupActivity.this, LoginActivity.class);
            startActivity(loginIntent);
            finish();
        }
    }

    private void createNewUserAccount(final String email, final String password) {
        Log.d(TAG, "Email of the createNewUserAccount: " + email);
        if (!validateForm()) {
            return;
        }

        firebaseAuthentication.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        Log.d(TAG, "createUserWithEmail:onComplete:" + task.isSuccessful());

                        if (!task.isSuccessful()) {
                            Toast.makeText(SignupActivity.this, "Signup failed. Email already exists. Please create a new one",
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            storeSignedupUserInDB(
                                    new User(userSessionId, signupFullName.getText().toString().trim(),
                                            email,
                                            password));
                            Toast.makeText(SignupActivity.this, "Signup successful. New user created.",
                                    Toast.LENGTH_SHORT).show();
                            Intent loginIntent = new Intent(SignupActivity.this, LoginActivity.class);
                            startActivity(loginIntent);
                            finish();
                        }
                    }
                });
    }

    private void storeSignedupUserInDB(User userInfo) {
        //Storing the signed up user in firebase db as - /users/sessionId/{user object}
        firebaseDatabaseReference.child("users").child(userSessionId).setValue(userInfo);
    }
}