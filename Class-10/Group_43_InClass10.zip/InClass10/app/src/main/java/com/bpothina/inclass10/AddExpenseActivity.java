/*
Group 43 - Bharat Pothina, Vinayaka Narayan
InClass 10
AddExpenseActivity.java
 */

package com.bpothina.inclass10;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class AddExpenseActivity extends AppCompatActivity {

    private static final String USER_SESSION_ID = "UID";
    String userSessionId;
    String selectedCategory = "";
    DatabaseReference firebaseDatabaseReference = FirebaseDatabase.getInstance().getReference();
    final DatabaseReference expensesDatabaseReference = firebaseDatabaseReference.child("expenses");
    private boolean isExpenseNameExists = false;
    private ArrayList<String> existingExpenseNamesForUser = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);

        if (getIntent().getExtras() != null) {
            userSessionId = getIntent().getExtras().getString(USER_SESSION_ID);
        }

        final Spinner spinner = (Spinner) findViewById(R.id.categorySpinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.categories, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new CategorySelectedListener());

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedCategory = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        final EditText enteredExpenseName = (EditText) findViewById(R.id.expenseNameText);
        final EditText enteredExpenseAmount = (EditText) findViewById(R.id.amntText);

        expensesDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot data : dataSnapshot.getChildren()) {
                    Expense expense = data.getValue(Expense.class);
                    if (expense.getUid().equals(userSessionId)) {
                        existingExpenseNamesForUser.add(expense.getExpenseName());
                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        Button addNewExpenseButton = (Button) findViewById(R.id.addExpensesButton);
        addNewExpenseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (enteredExpenseName.getText().toString() == null ||
                        enteredExpenseAmount.getText().toString() == null ||
                        enteredExpenseName.getText().toString().trim().isEmpty() ||
                        enteredExpenseAmount.getText().toString().trim().isEmpty() ||
                        selectedCategory.equals("Select Category")
                        ) {
                    Toast.makeText(AddExpenseActivity.this, "Please enter all fields",
                            Toast.LENGTH_SHORT).show();
                } else if (existingExpenseNamesForUser.contains(enteredExpenseName.getText().toString().trim())) {
                    Toast.makeText(AddExpenseActivity.this,
                            "Your expenselist contains an expense with same name. Please enter a different name.",
                            Toast.LENGTH_SHORT).show();
                } else {
                    java.text.DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                    Date addedDate = new Date();

                    firebaseDatabaseReference.child("expenses")
                            .child(userSessionId.concat(enteredExpenseName.getText().toString()))
                            .setValue
                                    (new Expense(enteredExpenseName.getText().toString().trim(),
                                            selectedCategory,
                                            enteredExpenseAmount.getText().toString().trim(),
                                            dateFormat.format(addedDate), userSessionId));
                    Intent expenseListIntent = new Intent(AddExpenseActivity.this, ExpenseListActivity.class);
                    expenseListIntent.putExtra(USER_SESSION_ID, userSessionId);
                    startActivity(expenseListIntent);
                    finish();
                }
            }
        });

        Button cancelAddExpenseButton = (Button) findViewById(R.id.cancelExpense);
        cancelAddExpenseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent expenseListIntentOnCancel = new Intent(AddExpenseActivity.this, ExpenseListActivity.class);
                expenseListIntentOnCancel.putExtra(USER_SESSION_ID, userSessionId);
                startActivity(expenseListIntentOnCancel);
                finish();
            }
        });
    }

    public class CategorySelectedListener implements AdapterView.OnItemSelectedListener {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
            selectedCategory = parent.getItemAtPosition(pos).toString();
        }

        @Override
        public void onNothingSelected(AdapterView parent) {
        }
    }
}