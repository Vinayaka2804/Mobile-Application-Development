/*
Group 43 - Bharat Pothina, Vinayaka Narayan
InClass 10
Expense.java
 */

package com.bpothina.inclass10;

import com.google.firebase.database.IgnoreExtraProperties;

import java.io.Serializable;

@IgnoreExtraProperties
public class Expense implements Serializable {

    private String expenseName, category, amount, dateAdded, uid;

    public Expense(String expenseName, String category, String amount, String dateAdded, String uid) {
        this.expenseName = expenseName;
        this.category = category;
        this.amount = amount;
        this.dateAdded = dateAdded;
        this.uid = uid;
    }

    public Expense() {
    }

    public String getExpenseName() {
        return expenseName;
    }

    public void setExpenseName(String expenseName) {
        this.expenseName = expenseName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getDateAdded() {
        return dateAdded;
    }

    public void setDateAdded(String dateAdded) {
        this.dateAdded = dateAdded;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    @Override
    public String toString() {
        return "Expense{" +
                "expenseName='" + expenseName + '\'' +
                ", category='" + category + '\'' +
                ", amount='" + amount + '\'' +
                ", dateAdded='" + dateAdded + '\'' +
                ", uid='" + uid + '\'' +
                '}';
    }
}
