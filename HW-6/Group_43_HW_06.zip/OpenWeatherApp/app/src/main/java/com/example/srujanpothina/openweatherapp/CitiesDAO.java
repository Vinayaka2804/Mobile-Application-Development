package com.example.srujanpothina.openweatherapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by SRUJAN POTHINA on 10/19/2016.
 */
public class CitiesDAO {

    private SQLiteDatabase db;

    public CitiesDAO(SQLiteDatabase db) {
        this.db = db;
    }

    public long save(City city) {
        ContentValues values = new ContentValues();
        values.put(CitiesTable.COLUMN_CITY, city.getCityname());
        values.put(CitiesTable.COLUMN_COUNTRY, city.getCountry());
        values.put(CitiesTable.COLUMN_TEMPERATURE, city.getTemperaturecelsius());
        values.put(CitiesTable.COLUMN_FAVORITE, city.getFavorite());
        values.put(CitiesTable.COLUMN_DATE, city.getUpdateddate());
        return db.insert(CitiesTable.TABLENAME, null, values);
    }

    public boolean update(City city) {
        ContentValues values = new ContentValues();
        values.put(CitiesTable.COLUMN_CITY, city.getCityname());
        values.put(CitiesTable.COLUMN_COUNTRY, city.getCountry());
        values.put(CitiesTable.COLUMN_TEMPERATURE, city.getTemperaturecelsius());
        values.put(CitiesTable.COLUMN_FAVORITE, city.getFavorite());
        values.put(CitiesTable.COLUMN_DATE, city.getUpdateddate());
        return db.update(CitiesTable.TABLENAME, values, CitiesTable.COLUMN_CITY + "=?" + " and " + CitiesTable.COLUMN_COUNTRY + "=?"
                , new String[]{city.getCityname(), city.getCountry()}) > 0;
    }

    public boolean delete(City city) {
        return db.delete(CitiesTable.TABLENAME, CitiesTable.COLUMN_CITY + "=?" + " and " + CitiesTable.COLUMN_COUNTRY + "=?"
                , new String[]{city.getCityname(), city.getCountry()}) > 0;
    }

    public List<City> getAll() {
        List<City> cities = new ArrayList<City>();

        Cursor c = db.query(CitiesTable.TABLENAME, new String[]{CitiesTable.COLUMN_ID, CitiesTable.COLUMN_CITY,
                        CitiesTable.COLUMN_COUNTRY, CitiesTable.COLUMN_TEMPERATURE, CitiesTable.COLUMN_FAVORITE, CitiesTable.COLUMN_DATE },
                null, null, null, null, null);

        if(c != null && c.moveToFirst()) {
            do {
                City city = buildCityFromCursor(c);
                if(city != null) {
                    cities.add(city);
                }
            } while(c.moveToNext());

            if(!c.isClosed()) {
                c.close();
            }
        }
        return cities;
    }

    public City get(String cityname, String country) {
        City city = null;
        Cursor c = db.query(true, CitiesTable.TABLENAME, new String[]{
                CitiesTable.COLUMN_ID, CitiesTable.COLUMN_CITY,
                CitiesTable.COLUMN_COUNTRY, CitiesTable.COLUMN_TEMPERATURE, CitiesTable.COLUMN_FAVORITE, CitiesTable.COLUMN_DATE},
                CitiesTable.COLUMN_CITY + "=?" + " and " + CitiesTable.COLUMN_COUNTRY + "=?", new String[] {cityname, country},
                null, null, null, null, null);

        if(c!=null && c.moveToFirst()) {
            city = buildCityFromCursor(c);
            if(!c.isClosed()) {
                c.close();
            }
        }
        return city;
    }

    private City buildCityFromCursor(Cursor c) {
        City city = null;
        if(c != null) {
            city = new City();
            city.set_id(c.getLong(0));
            city.setCityname(c.getString(1));
            city.setCountry(c.getString(2));
            city.setTemperaturecelsius(c.getString(3));
            city.setFavorite(c.getString(4));
            city.setUpdateddate(c.getString(5));
        }
        return city;
    }

}
