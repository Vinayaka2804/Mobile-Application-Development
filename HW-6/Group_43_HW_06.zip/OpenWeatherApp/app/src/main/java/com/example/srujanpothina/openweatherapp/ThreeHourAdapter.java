package com.example.srujanpothina.openweatherapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by SRUJAN POTHINA on 10/20/2016.
 */
public class ThreeHourAdapter extends RecyclerView.Adapter<ThreeHourAdapter.ViewHolder> {

    private List<ThreeHourForecast> mForecast;
    private Context mContext;

    ThreeHourForecast threeHourForecast;

    ViewHolder viewHolder;

    public ThreeHourAdapter(Context context, List<ThreeHourForecast> forecast) {
        mForecast = forecast;
        mContext = context;
    }

    private Context getContext() {
        return mContext;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView timeTextView;
        public TextView tempTextView;
        public TextView conditionTextView;
        public ImageView imageView;
        public TextView pressureTextView;
        public TextView humidityTextView;
        public TextView windTextView;

        public ViewHolder(View itemView) {
            super(itemView);
            timeTextView = (TextView) itemView.findViewById(R.id.finaltime);
            tempTextView = (TextView) itemView.findViewById(R.id.finaltemp);
            imageView = (ImageView) itemView.findViewById(R.id.finalImage);
            conditionTextView = (TextView) itemView.findViewById(R.id.finalcondition);
            pressureTextView = (TextView) itemView.findViewById(R.id.finalpressure);
            humidityTextView = (TextView) itemView.findViewById(R.id.finalhumidity);
            windTextView = (TextView) itemView.findViewById(R.id.finalwind);
        }
    }

    @Override
    public ThreeHourAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.threehourforecast, parent, false);
        viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ThreeHourAdapter.ViewHolder viewHolder, int position) {

        threeHourForecast = mForecast.get(position);
        SharedPreferences mypref = getContext().getSharedPreferences("WeatherFavorite", Context.MODE_PRIVATE);
        String savedTempUnit = "C";
        if(mypref != null && mypref.contains("Unit")){
            savedTempUnit = mypref.getString("Unit", "").equals("C") ? savedTempUnit : "F";
        }

        TextView timeView = viewHolder.timeTextView;
        timeView.setText(threeHourForecast.getFormattedTime());
        TextView tempView = viewHolder.tempTextView;
        tempView.setText(threeHourForecast.getTemperature() + "°" + savedTempUnit);
        TextView humidityView = viewHolder.humidityTextView;
        humidityView.setText(threeHourForecast.getHumidity() + "%");
        TextView pressureView = viewHolder.pressureTextView;
        pressureView.setText(threeHourForecast.getPressure() + "hPa");
        TextView windView = viewHolder.windTextView;
        windView.setText(threeHourForecast.getWindSpeed() + "," + threeHourForecast.getWindDirection());
        TextView condView = viewHolder.conditionTextView;
        condView.setText(threeHourForecast.getCondition());

        String img = "http://openweathermap.org/img/w/"+threeHourForecast.getSymbol()+".png";
        Picasso.with(mContext).load(img).into(viewHolder.imageView);
    }

    @Override
    public int getItemCount() {
        return mForecast.size();
    }

    private static float round(float d) {
        BigDecimal bd = new BigDecimal(Float.toString(d));
        bd = bd.setScale(2, BigDecimal.ROUND_HALF_UP);
        return bd.floatValue();
    }

}
