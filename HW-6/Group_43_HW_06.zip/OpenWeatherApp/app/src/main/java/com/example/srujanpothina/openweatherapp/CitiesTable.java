package com.example.srujanpothina.openweatherapp;

import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

/**
 * Created by SRUJAN POTHINA on 10/19/2016.
 */
public class CitiesTable {

    static final String TABLENAME = "cities";
    static final String COLUMN_ID = "_id";
    static final String COLUMN_CITY = "cityname";
    static final String COLUMN_COUNTRY = "country";
    static final String COLUMN_TEMPERATURE = "temperaturecelsius";
    static final String COLUMN_FAVORITE = "favorite";
    static final String COLUMN_DATE = "updateddate";

    static public void onCreate(SQLiteDatabase db) {
        StringBuilder sb = new StringBuilder();
        sb.append("CREATE TABLE " + TABLENAME + " (");
        sb.append(COLUMN_ID + " integer primary key autoincrement, ");
        sb.append(COLUMN_CITY + " text not null, ");
        sb.append(COLUMN_COUNTRY + " text not null, ");
        sb.append(COLUMN_TEMPERATURE + " text not null, ");
        sb.append(COLUMN_FAVORITE + " text not null, ");
        sb.append(COLUMN_DATE + " text not null);");

        try{
            db.execSQL(sb.toString());
        } catch(SQLException se) {
            se.printStackTrace();
        }
    }

    static public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLENAME);
        CitiesTable.onCreate(db);
    }

}
