package com.example.srujanpothina.openweatherapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.util.List;

public class DatabaseDataManager {

    private Context context;
    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;
    private CitiesDAO citiesDao;

    public DatabaseDataManager(Context context) {
        this.context = context;
        dbHelper = new DatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
        citiesDao = new CitiesDAO(db);
    }

    public void close() {
        if(db != null) {
            db.close();
        }
    }

    public CitiesDAO getCitiesDao() {
        return this.citiesDao;
    }

    public long saveCity(City city) {
        return this.citiesDao.save(city);
    }

    public boolean updateCity(City city) {
        return this.citiesDao.update(city);
    }

    public boolean deleteCity(City city) {
        return this.citiesDao.delete(city);
    }

    public City getCity(String city, String country) {
        return this.citiesDao.get(city, country);
    }

    public List<City> getAllCities() {
        return this.citiesDao.getAll();
    }
}
