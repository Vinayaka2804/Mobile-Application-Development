package com.example.srujanpothina.openweatherapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.util.Log;
import android.widget.Toast;

public class SettingsActivity extends PreferenceActivity {

    ListPreference listPreference;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.temperaturepref);
        listPreference = (ListPreference)findPreference("pref_temp");

        Preference.OnPreferenceChangeListener listener = new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                listPreference.setValue(newValue.toString());

                SharedPreferences mypref = getSharedPreferences("WeatherFavorite", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = mypref.edit();
                editor.clear();
                editor.putString("Unit", listPreference.getValue());
                editor.commit();

                Toast.makeText(SettingsActivity.this, "Temperature Unit has been changed to °"
                        .concat(listPreference.getValue()), Toast.LENGTH_LONG).show();

                Intent displayIntent;
                if(getIntent().getStringExtra(MainActivity.MAIN_ACTIVITY).equals("YES")) {
                    displayIntent = new Intent(SettingsActivity.this, MainActivity.class);
                    startActivity(displayIntent);
                } /*else {
                    displayIntent = new Intent(SettingsActivity.this, CityWeatherActivity.class);
                }*/
                //startActivity(displayIntent);
                return true;
            }
        };
        listPreference.setOnPreferenceChangeListener(listener);
    }
}
