package com.example.srujanpothina.openweatherapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.math.BigDecimal;
import java.util.List;

public class SavedCitiesAdapter extends
        RecyclerView.Adapter<SavedCitiesAdapter.ViewHolder> {

    private List<City> mCities;
    private Context mContext;
    City modifiedCity;

    ViewHolder viewHolder;

    public SavedCitiesAdapter(Context context, List<City> cities) {
        mCities = cities;
        mContext = context;
    }

    private Context getContext() {
        return mContext;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView favLocationTextView;
        public TextView favDetailsTextView;
        public ImageButton favButton;

        public ViewHolder(View itemView) {
            super(itemView);
            favLocationTextView = (TextView) itemView.findViewById(R.id.favLocation);
            favDetailsTextView = (TextView) itemView.findViewById(R.id.favDetail);
            favButton = (ImageButton) itemView.findViewById(R.id.favButton);
        }
    }

    @Override
    public SavedCitiesAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View cityView = inflater.inflate(R.layout.saved_cities, parent, false);
        viewHolder = new ViewHolder(cityView);
        return viewHolder;
    }


    @Override
    public void onBindViewHolder(SavedCitiesAdapter.ViewHolder viewHolder, int position) {
        viewHolder.itemView.setLongClickable(true);

        modifiedCity = mCities.get(position);
        SharedPreferences mypref = getContext().getSharedPreferences("WeatherFavorite", Context.MODE_PRIVATE);
        String savedTempUnit = "C";
        if(mypref != null && mypref.contains("Unit")){
            savedTempUnit = mypref.getString("Unit", "").equals("C") ? savedTempUnit : "F";
        }

        TextView textView = viewHolder.favLocationTextView;
        textView.setText(modifiedCity.getCityname().concat(", ").concat(modifiedCity.getCountry()));

        TextView detailsView = viewHolder.favDetailsTextView;
        String savedTemperature = modifiedCity.getTemperaturecelsius();
        String displayTemperature = savedTempUnit.equals("C")
                ? savedTemperature.concat("°C")
                :((Float.valueOf(round(((Float.parseFloat(savedTemperature)) * 1.8f) + 32))).toString()).concat("°F");
        detailsView.setText("\t\t\t".concat(displayTemperature).concat("\n").concat("Updated on:\n   ")
                .concat(modifiedCity.getUpdateddate()));

        ImageButton button = viewHolder.favButton;
        Bitmap bitmap = modifiedCity.getFavorite().equals("Y")
                    ? BitmapFactory.decodeResource(getContext().getResources(), R.drawable.ic_star_gold)
                    : BitmapFactory.decodeResource(getContext().getResources(), R.drawable.ic_star_gray);
        button.setImageBitmap(bitmap);
    }

    @Override
    public int getItemCount() {
        return mCities.size();
    }

    private static float round(float d) {
        BigDecimal bd = new BigDecimal(Float.toString(d));
        bd = bd.setScale(2, BigDecimal.ROUND_HALF_UP);
        return bd.floatValue();
    }
}
