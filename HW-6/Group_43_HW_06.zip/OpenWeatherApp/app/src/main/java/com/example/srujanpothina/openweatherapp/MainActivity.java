package com.example.srujanpothina.openweatherapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.GestureDetector;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Toast;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    public static final String CITY_INFO = "CityInfo";
    public static final String MAIN_ACTIVITY = "MainActivity";
    public static final int UNIT_CHANGED_CODE = 100;

    String unit;
    Weather weather;
    String city;
    String country;
    String[] currentLocationInfo;
    DatabaseDataManager dm;
    List<City> cityList;
    SavedCitiesAdapter adapter;
    RecyclerView favoritesRecylceView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dm = new DatabaseDataManager(getBaseContext());
        cityList = dm.getAllCities();

        Comparator comparator = Collections.reverseOrder();
        Collections.sort(cityList, comparator);

        if(cityList.isEmpty()) {
            findViewById(R.id.favoritesRecyclerView).setVisibility(View.INVISIBLE);
            findViewById(R.id.favoritesLabel).setVisibility(View.INVISIBLE);
            findViewById(R.id.noFavoritesText).setVisibility(View.VISIBLE);
        } else {
            findViewById(R.id.noFavoritesText).setVisibility(View.INVISIBLE);
            findViewById(R.id.favoritesRecyclerView).setVisibility(View.VISIBLE);
            findViewById(R.id.favoritesLabel).setVisibility(View.VISIBLE);
        }

        List<City> cities = cityList;
        favoritesRecylceView = (RecyclerView) findViewById(R.id.favoritesRecyclerView);
        adapter = new SavedCitiesAdapter(this, cities);
        favoritesRecylceView.setAdapter(adapter);
        favoritesRecylceView.setLayoutManager(new LinearLayoutManager(this));

        favoritesRecylceView.addOnItemTouchListener(new RecyclerTouchListener(this,
                favoritesRecylceView, new RecycleClickListener() {
            @Override
            public void onClick(View view, final int position) {
                City city = cityList.get(position);
                if(city.getFavorite().equals("Y")){
                    city.setFavorite("N");
                } else {
                    city.setFavorite("Y");
                }
                dm.updateCity(city);
                cityList = dm.getAllCities();
                Comparator comparator = Collections.reverseOrder();
                Collections.sort(cityList, comparator);

                favoritesRecylceView = (RecyclerView) findViewById(R.id.favoritesRecyclerView);
                adapter = new SavedCitiesAdapter(getBaseContext(), cityList);
                favoritesRecylceView.setAdapter(adapter);
                favoritesRecylceView.setLayoutManager(new LinearLayoutManager(getBaseContext()));
            }

            @Override
            public void onLongClick(View view, int position) {
                Comparator comparator = Collections.reverseOrder();
                Collections.sort(cityList, comparator);

                City city = cityList.get(position);
                cityList.remove(position);
                if(cityList.isEmpty()) {
                    findViewById(R.id.favoritesRecyclerView).setVisibility(View.INVISIBLE);
                    findViewById(R.id.favoritesLabel).setVisibility(View.INVISIBLE);
                    findViewById(R.id.noFavoritesText).setVisibility(View.VISIBLE);
                } else {
                    findViewById(R.id.favoritesRecyclerView).setVisibility(View.VISIBLE);
                    findViewById(R.id.favoritesLabel).setVisibility(View.VISIBLE);
                    findViewById(R.id.noFavoritesText).setVisibility(View.INVISIBLE);
                    favoritesRecylceView.removeViewAt(position);
                    adapter.notifyItemRemoved(position);
                    adapter.notifyItemRangeChanged(0, cityList.size());
                }

                dm.deleteCity(city);
                Toast.makeText(MainActivity.this, city.getCityname().concat(",").concat(city.getCountry()) + " deleted",
                        Toast.LENGTH_LONG).show();
            }
        }));

        Log.d("cities are: ", cityList.toString());

        //On click of Submit
        findViewById(R.id.searchButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Get entered City and Country
                EditText cityText = (EditText) findViewById(R.id.cityText);
                city = cityText.getText().toString().trim();
                EditText countryText = (EditText) findViewById(R.id.countryText);
                country = countryText.getText().toString().trim();
                boolean isInputEmpty = false;
                if (city.isEmpty()) {
                    cityText.setError("City cannot be blank");
                    isInputEmpty = true;
                }
                if (country.isEmpty()) {
                    countryText.setError("Country cannot be blank");
                    isInputEmpty = true;
                }

                if(!isInputEmpty) {
                    currentLocationInfo = new String[]{city, country};
                    Intent i = new Intent(MainActivity.this, CityWeatherActivity.class);
                    i.putExtra(CITY_INFO, currentLocationInfo);
                    startActivity(i);
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflator = getMenuInflater();
        inflator.inflate(R.menu.favorite_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.Settings:
                Intent i = new Intent(MainActivity.this, SettingsActivity.class);
                i.putExtra(MAIN_ACTIVITY, "YES");
                startActivity(i);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    public static interface RecycleClickListener {
        public void onClick(View view, int position);
        public void onLongClick(View view, int position);
    }

    class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {
        private RecycleClickListener clicklistener;
        private GestureDetector gestureDetector;

        public RecyclerTouchListener(Context context, final RecyclerView recycleView, final RecycleClickListener clicklistener){

            this.clicklistener=clicklistener;
            gestureDetector=new GestureDetector(context,new GestureDetector.SimpleOnGestureListener(){
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child=recycleView.findChildViewUnder(e.getX(),e.getY());
                    if(child!=null && clicklistener!=null){
                        clicklistener.onLongClick(child,recycleView.getChildAdapterPosition(child));
                    }
                }

            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {
            View child = rv.findChildViewUnder(e.getX(),e.getY());
            if(child!=null && clicklistener!=null && gestureDetector.onTouchEvent(e)){
                clicklistener.onClick(child,rv.getChildAdapterPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {

        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {
        }
    }

}
