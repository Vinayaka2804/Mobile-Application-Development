package com.example.srujanpothina.openweatherapp;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class GetForecastApiData extends AsyncTask<String, Void, Weather> {

    CityWeatherActivity cityWeatherActivity;
    ProgressDialog weatherLoadingProgress;
    Weather weather = new Weather();
    Weather apiResult = null;

    public GetForecastApiData(CityWeatherActivity activity)
    {
        cityWeatherActivity = activity;
    }

    public GetForecastApiData() {
    }

    @Override
    protected Weather doInBackground(String... params) {
        URL url = null;
        try {
            url = new URL(params[0]);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.connect();

            int responseStatusCode = con.getResponseCode();
            if(responseStatusCode == HttpURLConnection.HTTP_OK)
            {
                BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line= reader.readLine();
                while(line!=null)
                {
                    sb.append(line);
                    line=reader.readLine();
                }
                apiResult = WeatherUtil.WeatherJSONParser.parseWeather(sb.toString());
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return apiResult;
    }

    @Override
    protected void onPreExecute()
    {
        super.onPreExecute();
        weatherLoadingProgress = new ProgressDialog(cityWeatherActivity);
        weatherLoadingProgress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        weatherLoadingProgress.setTitle("Loading Data");
        weatherLoadingProgress.show();
    }

    @Override
    protected void onPostExecute(Weather result)
    {
        super.onPostExecute(result);
        weatherLoadingProgress.dismiss();
        cityWeatherActivity.getWeatherForecast(result);
    }

    static public interface IData {
        public void getWeatherForecast(Weather result);
    }
}
