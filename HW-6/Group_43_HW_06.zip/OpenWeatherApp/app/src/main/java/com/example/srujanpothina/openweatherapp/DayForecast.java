package com.example.srujanpothina.openweatherapp;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by SRUJAN POTHINA on 10/15/2016.
 */
public class DayForecast implements Serializable {

    private String date;
    private String formattedDate;
    private String avgTemperature;
    private String symbolForDay;
    private List<ThreeHourForecast> threeHourForecastList =  new ArrayList<ThreeHourForecast>();

    public DayForecast(String date, String avgTemperature, String symbolForDay, List<ThreeHourForecast> threeHourForecastList) {
        this.date = date;
        this.avgTemperature = avgTemperature;
        this.symbolForDay = symbolForDay;
        this.threeHourForecastList = threeHourForecastList;
    }

    public DayForecast() {
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getAvgTemperature() {
        float total = 0.00f;
        for(ThreeHourForecast hourForecast : threeHourForecastList) {
            total = total + Float.parseFloat(hourForecast.getTemperature());
        }
        BigDecimal bd = new BigDecimal(Float.toString(total));
        bd = bd.setScale(2, BigDecimal.ROUND_HALF_UP);
        return Float.valueOf(bd.floatValue()/threeHourForecastList.size()).toString();
    }

    public List<ThreeHourForecast> getThreeHourForecastList() {
        return threeHourForecastList;
    }

    public void setThreeHourForecastList(List<ThreeHourForecast> threeHourForecastList) {
        this.threeHourForecastList = threeHourForecastList;
    }

    public String getSymbolForDay() {
        if(threeHourForecastList.size() > 0) {
            int symbolPosition = threeHourForecastList.size() / 2;
            return threeHourForecastList.get(symbolPosition).getSymbol();
        } else {
            return "";
        }
    }

    public String getFormattedDate() {
        try {
            SimpleDateFormat initialFormat = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat targetFormat = new SimpleDateFormat("MMM dd yyyy");
            Date initialDate = initialFormat.parse(this.date);
            String[] strDate = targetFormat.format(initialDate).split(" ");
            return strDate[0].concat(" ").concat(strDate[1]).concat(", ").concat(strDate[2]);
        } catch (Exception e) {
            return "";
        }
    }

    @Override
    public String toString() {
        return "DayForecast{" +
                "date='" + date + '\'' +
                ", avgTemperature='" + avgTemperature + '\'' +
                ", symbolForDay='" + symbolForDay + '\'' +
                ", threeHourForecastList=" + threeHourForecastList +
                '}';
    }
}
