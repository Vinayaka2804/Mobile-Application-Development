package com.example.srujanpothina.openweatherapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.GestureDetector;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class CityWeatherActivity extends AppCompatActivity implements GetForecastApiData.IData {

    public static final int CITY_UNIT_CHANGED_CODE = 200;
    public static final String MAIN_ACTIVITY = "MainActivity";

    public static final String WEATHER_API_BASEURL = "http://api.openweathermap.org/data/2.5/forecast";
    public static final String QUESTION_DELIM = "?";
    public static final String AMP_DELIM = "&";
    public static final String LOCATION_PARAM = "q=";
    public static final String COMMA_DELIM = ",";
    public static final String MODE_PARAM = "mode=json";
    public static final String UNITS_PARAM = "units=metric";
    public static final String APPID_PARAM = "appid=be4c82a3ed89a551a9cca513987f6a18";

    List<DayForecast> dayForecastListVal;
    String weatherFinalUrl;
    Weather cityWeather;
    String[] currentLocationInfo;
    DatabaseDataManager dm;
    List<City> cityList;

    RecyclerView recycle;
    RecyclerView.Adapter adapter;
    RecyclerView.LayoutManager layoutmanager;

    RecyclerView recyclehour;
    RecyclerView.Adapter adapterhour;
    RecyclerView.LayoutManager layouthourmanager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_city_weather);

        currentLocationInfo = getIntent().getStringArrayExtra(MainActivity.CITY_INFO);

        StringBuilder urlBuilder = new StringBuilder(WEATHER_API_BASEURL);
        weatherFinalUrl = (urlBuilder.append(QUESTION_DELIM)
                .append(LOCATION_PARAM)
                .append(currentLocationInfo[0])
                .append(COMMA_DELIM)
                .append(currentLocationInfo[1])
                .append(AMP_DELIM)
                .append(MODE_PARAM)
                .append(AMP_DELIM)
                .append(UNITS_PARAM)
                .append(AMP_DELIM)
                .append(APPID_PARAM))
                .toString();

        new GetForecastApiData(CityWeatherActivity.this).execute(weatherFinalUrl);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflator = getMenuInflater();
        inflator.inflate(R.menu.city_favorite_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.CitySettings:
                Intent i = new Intent(CityWeatherActivity.this, SettingsActivity.class);
                i.putExtra(MAIN_ACTIVITY, "NO");
                startActivity(i);
                return true;
            case R.id.CitySave:
                //Update/Insert into SQLLite DB
                dm = new DatabaseDataManager(getBaseContext());
                cityList = dm.getAllCities();

                City existingCity = dm.getCity(currentLocationInfo[0], currentLocationInfo[1]);

                if(existingCity == null) {
                    DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
                    Date dateobj = new Date();
                    String avgTemp = "";
                    for(Map.Entry<Date, DayForecast> map : cityWeather.getDayForecastMap().entrySet()) {
                        DayForecast day = map.getValue();
                        avgTemp = day.getAvgTemperature();
                    }
                    City addedCity = new City(currentLocationInfo[0], currentLocationInfo[1], avgTemp, "N", df.format(dateobj));
                    cityList.add(addedCity);
                    Comparator comparator = Collections.reverseOrder();
                    Collections.sort(cityList, comparator);

                    dm.saveCity(addedCity);
                } else {
                    DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
                    Date dateobj = new Date();
                    String avgTemp = "";
                    for(Map.Entry<Date, DayForecast> map : cityWeather.getDayForecastMap().entrySet()) {
                        DayForecast day = map.getValue();
                        avgTemp = day.getAvgTemperature();
                    }
                    existingCity.setTemperaturecelsius(avgTemp);
                    existingCity.setUpdateddate(df.format(dateobj));
                    dm.updateCity(existingCity);
                    cityList = dm.getAllCities();
                    Comparator comparator = Collections.reverseOrder();
                    Collections.sort(cityList, comparator);
                }

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void getWeatherForecast(Weather result) {
        cityWeather = result;

        ((TextView)findViewById(R.id.ctyLabel)).setText(cityWeather.getCity());
        ((TextView)findViewById(R.id.ctryLabel)).setText(cityWeather.getCountry());

        final Map<Date, DayForecast> dayForecast = cityWeather.getDayForecastMap();
        List<DayForecast> dayForecastList = new ArrayList<DayForecast>();
        dayForecastListVal = dayForecastList;
        for(Map.Entry<Date, DayForecast> dayMap : dayForecast.entrySet()) {
            dayForecastList.add(dayMap.getValue());
        }

        recycle = (RecyclerView)findViewById(R.id.myrecyclerview);
        adapter = new CityRecyclerAdapter(dayForecastList,getBaseContext());
        layoutmanager = new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false);
        recycle.setLayoutManager(layoutmanager);
        recycle.setAdapter(adapter);
        recycle.setHasFixedSize(true);


        /*favoritesRecylceView = (RecyclerView) findViewById(R.id.favoritesRecyclerView);
        adapter = new SavedCitiesAdapter(this, cities);
        favoritesRecylceView.setAdapter(adapter);
        favoritesRecylceView.setLayoutManager(new LinearLayoutManager(this));*/

        recycle.addOnItemTouchListener(new RecyclerTouchListener(this,
                recycle, new RecycleClickListener() {
            @Override
            public void onClick(View view, final int position) {
                DayForecast dayforecast = dayForecastListVal.get(position);
                recyclehour = (RecyclerView) findViewById(R.id.bottomrecyclerview);

                recyclehour.setVisibility(View.VISIBLE);
                findViewById(R.id.threeLabel).setVisibility(View.VISIBLE);
                ((TextView)findViewById(R.id.dateLabel)).setVisibility(View.VISIBLE);
                ((TextView)findViewById(R.id.dateLabel)).setText(dayforecast.getFormattedDate());

                adapterhour = new ThreeHourAdapter(getBaseContext(), dayforecast.getThreeHourForecastList());
                recyclehour.setAdapter(adapterhour);
                recyclehour.setLayoutManager(new LinearLayoutManager(getBaseContext(), LinearLayoutManager.HORIZONTAL,false));

            }

            @Override
            public void onLongClick(View view, int position) {
                DayForecast dayforecast = dayForecastListVal.get(position);
                recyclehour = (RecyclerView) findViewById(R.id.bottomrecyclerview);
                adapterhour = new ThreeHourAdapter(getBaseContext(), dayforecast.getThreeHourForecastList());
                recyclehour.setAdapter(adapterhour);
                recyclehour.setLayoutManager(new LinearLayoutManager(getBaseContext(), LinearLayoutManager.HORIZONTAL,false));
            }
        }));

    }

    public static interface RecycleClickListener {
        public void onClick(View view, int position);
        public void onLongClick(View view, int position);
    }

    class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {
        private RecycleClickListener clicklistener;
        private GestureDetector gestureDetector;

        public RecyclerTouchListener(Context context, final RecyclerView recycleView, final RecycleClickListener clicklistener){

            this.clicklistener=clicklistener;
            gestureDetector=new GestureDetector(context,new GestureDetector.SimpleOnGestureListener(){
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child=recycleView.findChildViewUnder(e.getX(),e.getY());
                    if(child!=null && clicklistener!=null){
                        clicklistener.onLongClick(child,recycleView.getChildAdapterPosition(child));
                    }
                }

            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {
            View child = rv.findChildViewUnder(e.getX(),e.getY());
            if(child!=null && clicklistener!=null && gestureDetector.onTouchEvent(e)){
                clicklistener.onClick(child,rv.getChildAdapterPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {

        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {
        }
    }
}
