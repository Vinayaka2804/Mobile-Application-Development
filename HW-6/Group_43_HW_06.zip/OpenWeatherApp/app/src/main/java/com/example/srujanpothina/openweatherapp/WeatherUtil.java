package com.example.srujanpothina.openweatherapp;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class WeatherUtil {

    static public class WeatherJSONParser {

        static Weather parseWeather(String in) throws JSONException {

            Weather weather = null;
            Map<Date, DayForecast> dayForecastMap =  new TreeMap<Date, DayForecast>();
            List<ThreeHourForecast> threeHourForecastList = new ArrayList<ThreeHourForecast>();

            JSONObject root = new JSONObject(in);
            String responseCode = root.getString("cod");

            if (responseCode.equals("200")) {
                boolean cityExists = root.has("city");
                boolean forecastExists = root.has("list");
                JSONObject cityJsonObject = cityExists ? root.getJSONObject("city") : null;
                JSONArray forecastJsonArray = forecastExists ? root.getJSONArray("list") : null;
                Log.d("list is:", forecastJsonArray.length() + "");
                if (cityJsonObject == null
                        || forecastJsonArray == null
                        || forecastJsonArray.length() == 0)
                { //Handle error messsage, if any
                    Log.d("No forecast data:", "returned");
                } else { //Handle the forecast json array
                    weather = new Weather();
                    weather.setCity(cityJsonObject.getString("name"));
                    weather.setCountry(cityJsonObject.getString("country"));

                    ThreeHourForecast threeHourForecast = null;
                    DayForecast dayForecast = new DayForecast();
                    String currentDate = "";

                    for (int i = 0; i < forecastJsonArray.length(); i++) {
                        JSONObject forecastJsonObject = forecastJsonArray.getJSONObject(i);
                        String[] dateTime = forecastJsonObject.getString("dt_txt").split(" ");
                        currentDate = dateTime[0];
                        String time = dateTime[1];

                        threeHourForecast = new ThreeHourForecast();
                        threeHourForecast.setTime(time);

                        //main object from JSON
                        JSONObject mainJsonObject = forecastJsonObject.getJSONObject("main");

                        //Temperature
                        if (mainJsonObject != null && mainJsonObject.getString("temp") != null) {
                            threeHourForecast.setTemperature(mainJsonObject.getString("temp").trim());
                        }

                        //Pressure
                        if (mainJsonObject != null && mainJsonObject.getString("pressure") != null) {
                            threeHourForecast.setPressure(mainJsonObject.getString("pressure").trim());
                        }

                        //Humidity
                        if (mainJsonObject != null && mainJsonObject.getString("humidity") != null) {
                            threeHourForecast.setHumidity(mainJsonObject.getString("humidity").trim());
                        }

                        //Humidity
                        if (mainJsonObject != null && mainJsonObject.getString("humidity") != null) {
                            threeHourForecast.setHumidity(mainJsonObject.getString("humidity").trim());
                        }

                        //wind object from JSON
                        JSONObject windJsonObject = forecastJsonObject.getJSONObject("wind");

                        //Wind speed
                        if (windJsonObject != null && windJsonObject.getString("speed") != null) {
                            threeHourForecast.setWindSpeed(windJsonObject.getString("speed").trim());
                        }

                        //Wind direction degrees
                        if (windJsonObject != null && windJsonObject.getString("deg") != null) {
                            threeHourForecast.setWindDirection(windJsonObject.getString("deg").trim());
                        }

                        //weather array from JSON
                        JSONArray weatherJsonArray = forecastJsonObject.getJSONArray("weather");
                        JSONObject weatherJsonObject = weatherJsonArray != null ? weatherJsonArray.getJSONObject(0) : null;

                        //icon - symbol
                        if (weatherJsonObject != null && weatherJsonObject.getString("icon") != null) {
                            threeHourForecast.setSymbol(weatherJsonObject.getString("icon").trim());
                        }

                        //condition - description
                        if (weatherJsonObject != null && weatherJsonObject.getString("description") != null) {
                            threeHourForecast.setCondition(weatherJsonObject.getString("description").trim());
                        }

                        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                        Date dateFormat = null;
                        try {
                            dateFormat = (Date)formatter.parse(currentDate);
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }

                        if(dayForecastMap.containsKey(dateFormat)) {
                            DayForecast existingDayForecast = dayForecastMap.get(dateFormat);
                            existingDayForecast.getThreeHourForecastList().add(threeHourForecast);
                            dayForecastMap.put(dateFormat, existingDayForecast);
                        } else {
                            threeHourForecastList = new ArrayList<ThreeHourForecast>();
                            threeHourForecastList.add(threeHourForecast);
                            dayForecast = new DayForecast();
                            dayForecast.setDate(currentDate);
                            dayForecast.setThreeHourForecastList(threeHourForecastList);
                            dayForecastMap.put(dateFormat, dayForecast);
                        }
                    }
                    weather.setDayForecastMap(dayForecastMap);
                }
            } else {
                Log.d("API Error code: ", responseCode);
            }
            return weather;
        }
    }
}
