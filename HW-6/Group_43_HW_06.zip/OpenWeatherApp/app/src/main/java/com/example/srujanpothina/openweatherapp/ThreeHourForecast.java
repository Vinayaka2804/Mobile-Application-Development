package com.example.srujanpothina.openweatherapp;

import android.util.Log;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ThreeHourForecast implements Serializable {

    private String time;
    private String formattedTime;
    private String temperature;
    private String windDirection;
    private String windDirectionCode;// JSON doesn't return this
    private String symbol;
    private String windSpeed;
    private String pressure;
    private String pressureUnit = "hPa";
    private String humidity;
    private String condition;

    public ThreeHourForecast(String time, String temperature, String windDirection,
                             String windDirectionCode, String symbol, String windSpeed,
                             String pressure, String pressureUnit, String humidity,
                             String condition) {
        this.time = time;
        this.temperature = temperature;
        this.windDirection = windDirection;
        this.windDirectionCode = windDirectionCode;
        this.symbol = symbol;
        this.windSpeed = windSpeed;
        this.pressure = pressure;
        this.pressureUnit = pressureUnit;
        this.humidity = humidity;
        this.condition = condition;
    }

    public ThreeHourForecast() {
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getWindDirection() {
        return windDirection;
    }

    public void setWindDirection(String windDirection) {
        this.windDirection = windDirection;
    }

    public String getWindDirectionCode() {
        return windDirectionCode;
    }

    public void setWindDirectionCode(String windDirectionCode) {
        this.windDirectionCode = windDirectionCode;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getWindSpeed() {
        return windSpeed;
    }

    public void setWindSpeed(String windSpeed) {
        this.windSpeed = windSpeed;
    }

    public String getPressure() {
        return pressure;
    }

    public void setPressure(String pressure) {
        this.pressure = pressure;
    }

    public String getPressureUnit() {
        return pressureUnit;
    }

    public void setPressureUnit(String pressureUnit) {
        this.pressureUnit = pressureUnit;
    }

    public String getHumidity() {
        return humidity;
    }

    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getFormattedTime() {
        try {
            SimpleDateFormat initialFormat = new SimpleDateFormat("HH:mm");
            SimpleDateFormat targetFormat = new SimpleDateFormat("hh:mm a");
            Date initialDate = initialFormat.parse(this.time);
            return targetFormat.format(initialDate);
        } catch (Exception e) {
            return "";
        }
    }

    @Override
    public String toString() {
        return "ThreeHourForecast{" +
                "time='" + time + '\'' +
                ", temperature='" + temperature + '\'' +
                ", windDirection='" + windDirection + '\'' +
                ", windDirectionCode='" + windDirectionCode + '\'' +
                ", symbol='" + symbol + '\'' +
                ", windSpeed='" + windSpeed + '\'' +
                ", pressure='" + pressure + '\'' +
                ", pressureUnit='" + pressureUnit + '\'' +
                ", humidity='" + humidity + '\'' +
                ", condition='" + condition + '\'' +
                '}';
    }
}
