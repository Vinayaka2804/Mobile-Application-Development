package com.example.srujanpothina.openweatherapp;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;

public class Weather implements Serializable {

    private String city;
    private String country;
    private String temperatureUnit;
    private Map<Date, DayForecast> dayForecastMap = new TreeMap<Date, DayForecast>();

    public Weather(String city, String country, String temperatureUnit, Map<Date, DayForecast> dayForecastMap) {
        this.city = city;
        this.country = country;
        this.temperatureUnit = temperatureUnit;
        this.dayForecastMap = dayForecastMap;
    }

    public Weather() {
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getTemperatureUnit() {
        return temperatureUnit;
    }

    public void setTemperatureUnit(String temperatureUnit) {
        this.temperatureUnit = temperatureUnit;
    }

    public Map<Date, DayForecast> getDayForecastMap() {
        return dayForecastMap;
    }

    public void setDayForecastMap(Map<Date, DayForecast> dayForecastMap) {
        this.dayForecastMap = dayForecastMap;
    }

    @Override
    public String toString() {
        return "Weather{" +
                "city='" + city + '\'' +
                ", country='" + country + '\'' +
                ", temperatureUnit='" + temperatureUnit + '\'' +
                ", dayForecastMap=" + dayForecastMap +
                '}';
    }
}
