package com.example.srujanpothina.openweatherapp;

import java.io.Serializable;

/**
 * Created by SRUJAN POTHINA on 10/19/2016.
 */
public class City implements Serializable, Comparable<City>{

    private Long _id;
    private String cityname;
    private String country;
    private String temperaturecelsius;
    private String favorite;
    private String updateddate;


    public City(String cityname, String country, String temperaturecelsius, String favorite, String updateddate) {
        this.cityname = cityname;
        this.country = country;
        this.temperaturecelsius = temperaturecelsius;
        this.favorite = favorite;
        this.updateddate = updateddate;
    }

    public City(){

    }

    public Long get_id() {
        return _id;
    }

    public void set_id(Long _id) {
        this._id = _id;
    }

    public String getCityname() {
        return cityname;
    }

    public void setCityname(String cityname) {
        this.cityname = cityname;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getTemperaturecelsius() {
        return temperaturecelsius;
    }

    public void setTemperaturecelsius(String temperaturecelsius) {
        this.temperaturecelsius = temperaturecelsius;
    }

    public String getFavorite() {
        return favorite;
    }

    public void setFavorite(String favorite) {
        this.favorite = favorite;
    }

    public String getUpdateddate() {
        return updateddate;
    }

    public void setUpdateddate(String updateddate) {
        this.updateddate = updateddate;
    }

    @Override
    public String toString() {
        return "City{" +
                "_id=" + _id +
                ", cityname='" + cityname + '\'' +
                ", country='" + country + '\'' +
                ", temperaturecelsius='" + temperaturecelsius + '\'' +
                ", favorite='" + favorite + '\'' +
                ", updateddate='" + updateddate + '\'' +
                '}';
    }

    @Override
    public int compareTo(City city) {
        return this.favorite.compareTo(city.getFavorite());
    }
}
