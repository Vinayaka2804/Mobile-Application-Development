package com.example.srujanpothina.openweatherapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by Vinayaka Narayan on 10/19/2016.
 */
public class CityRecyclerAdapter extends RecyclerView.Adapter<CityRecyclerAdapter.RecycleViewholder> {

    private Context mContext;
    List<DayForecast> dayForecastList;
    DayForecast dayForecast;

    public CityRecyclerAdapter(List<DayForecast> weath, Context view) {
        this.dayForecastList = weath;
        this.mContext = view;
    }

    @Override
    public RecycleViewholder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.hourlyweatherlist, parent, false);
        RecycleViewholder recholder = new RecycleViewholder(view);
        return recholder;
    }

    @Override
    public void onBindViewHolder(RecycleViewholder holder, int position) {
        DayForecast day = dayForecastList.get(position);
        holder.vin.setText(day.getFormattedDate());

        SharedPreferences mypref = mContext.getSharedPreferences("WeatherFavorite", Context.MODE_PRIVATE);
        String prefTemp = "C";
        if(mypref.contains("Unit")) {
            prefTemp = mypref.getString("Unit", "C");
        }

        String tempFormatted = Float.valueOf(round(Float.parseFloat(day.getAvgTemperature()))).toString();
        holder.vin1.setText(tempFormatted.concat("°"+prefTemp));

        String img = "http://openweathermap.org/img/w/"+day.getSymbolForDay()+".png";
        Picasso.with(mContext).load(img).into(holder.myimg);
    }

    @Override
    public int getItemCount() {
        return dayForecastList.size();
    }

    public static class RecycleViewholder extends RecyclerView.ViewHolder {

        TextView vin, vin1, date;
        ImageView myimg;

        public RecycleViewholder(View view) {
            super(view);
            vin = (TextView) view.findViewById(R.id.vincity);
            vin1 = (TextView) view.findViewById(R.id.vincountry);
            myimg = (ImageView) view.findViewById(R.id.imageView1);
        }

    }

    private static float round(float d) {
        BigDecimal bd = new BigDecimal(Float.toString(d));
        bd = bd.setScale(2, BigDecimal.ROUND_HALF_UP);
        return bd.floatValue();
    }
}
