package com.bpothina.inclass11;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Message;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ChatRoomActivity extends AppCompatActivity{

    ArrayList<Messages> msgArrayList = new ArrayList<Messages>();
    Messages deletedMessage;
    private ListView userListView;
    private static final String USER_SESSION_ID = "UID";
    private static final String DISPLAY_USER = "SHOW";
    String image_str;
    User currentUser;
    int count = 0;
    private ListViewAdapter adapter;
    UploadTask uploadImagesTask;
    Uri url;
    String selectedImagePath;
    //private ImageView profileImage = (ImageView) findViewById(R.id.addphotobtn);

    DatabaseReference firebaseDatabaseReference = FirebaseDatabase.getInstance().getReference();
    DatabaseReference messagesDbRef;
    DatabaseReference usersDbRef;
    FirebaseStorage storage = FirebaseStorage.getInstance();
    StorageReference imagesRef;//= storage.getReference("firepbimages/child1");
    String userSessionId;
    byte[] image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_room);

        messagesDbRef = firebaseDatabaseReference.child("messages");
        usersDbRef = firebaseDatabaseReference.child("users");
        userSessionId = getIntent().getStringExtra(USER_SESSION_ID);

        userListView = (ListView) findViewById(R.id.chatlistview);
        userListView.setLongClickable(true);

        userListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                deletedMessage = msgArrayList.get(position);
                adapter.remove(deletedMessage);
                adapter.notifyDataSetChanged();
                Query applesQuery;
                if(deletedMessage.getTextMessage().equals("")) {
                    applesQuery = firebaseDatabaseReference.child("messages").orderByChild("textMessage")
                            .equalTo(deletedMessage.getTextMessage());
                } else {
                    applesQuery = firebaseDatabaseReference.child("messages").orderByChild("imageMessage")
                            .equalTo(deletedMessage.getImageMessage());
                }

                applesQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for (DataSnapshot appleSnapshot: dataSnapshot.getChildren()) {
                            appleSnapshot.getRef().removeValue();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });

                return false;
            }

        });



        usersDbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot data : dataSnapshot.getChildren()) {
                    User user = data.getValue(User.class);
                    if (user.getUid().equalsIgnoreCase(userSessionId)) {
                        currentUser = user;
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        getMessages();


        ImageButton button = (ImageButton) findViewById(R.id.addmessagebtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText text = (EditText) findViewById(R.id.chatedittext);
                String chatmsg = text.getText().toString().trim();

                Messages msg = new Messages();
                msg.setUid(userSessionId);
                msg.setFullName(currentUser.getFirstName() + currentUser.getLastName());
                msg.setImageMessage("");
                msg.setTimeAdded("2016/11/16");
                msg.setTextMessage(chatmsg);
                msg.setComments(null);
                firebaseDatabaseReference.child("messages").child(userSessionId + "--Message" + count + "").setValue(msg);

                getMessages();

               /* adapter = new ListViewAdapter
                        (ChatRoomActivity.this, R.layout.userlist, msgArrayList);
                userListView.setAdapter(adapter);
                adapter.setNotifyOnChange(true);*/

            }
        });

        ImageButton imgbutton = (ImageButton) findViewById(R.id.addphotobtn);
        imgbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), 1);

                //String path = "firepbimages/" + userSessionId + "--Message" + count + "";
                //imagesRef = storage.getReference(path);
                /*uploadImagesTask = imagesRef.putBytes(image);
                uploadImagesTask.addOnSuccessListener(ChatRoomActivity.this, new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        url = taskSnapshot.getDownloadUrl();
                        Log.d("downloadUrl:", url.toString());
                    }
                });

                Messages msg = new Messages();
                msg.setUid(userSessionId);
                msg.setFullName(currentUser.getFirstName() + currentUser.getLastName());
                msg.setImageMessage(url.toString());
                msg.setTimeAdded("2016/11/16");
                msg.setTextMessage("");
                msg.setComments(null);

                firebaseDatabaseReference.child("messages").child(userSessionId + "--Message" + count + "").setValue(msg);

                getMessages();*/


                /*adapter = new ListViewAdapter
                        (ChatRoomActivity.this, R.layout.userlist, msgArrayList);
                userListView.setAdapter(adapter);
                adapter.setNotifyOnChange(true);*/
            }

        });





    }

    private void signOut() {
        FirebaseAuth firebaseAuthentication = FirebaseAuth.getInstance();
        firebaseAuthentication.signOut();
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                Uri selectedImageUri = data.getData();
                //selectedImagePath = getPath(selectedImageUri);
                InputStream is = null;
                try {
                    is = getContentResolver().openInputStream(selectedImageUri);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                //System.out.println("Image Path : " + selectedImagePath);

                Bitmap bitmap = BitmapFactory.decodeStream(is);
                try {

                    is.close();

                } catch (IOException e) {
                    e.printStackTrace();
                }
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                image = stream.toByteArray();
                try {
                    stream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                image_str = Base64.encodeToString(image, 0);

                count++;
                getUrl();

            }
        }
    }

    private void getUrl() {
        String path = "firepbimages/" + userSessionId + "--Message" + count + "";
        getValue(path);


    }

    private void getValue(String path1) {
        imagesRef = storage.getReference(path1);
        /*uploadImagesTask = imagesRef.putBytes(image);
        uploadImagesTask = imagesRef.putBytes(image);*/
        imagesRef.putBytes(image).addOnSuccessListener(ChatRoomActivity.this, new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                url = taskSnapshot.getDownloadUrl();
                Log.d("downloadUrl:", url.toString());
                Messages msg = new Messages();
                msg.setUid(userSessionId);
                msg.setFullName(currentUser.getFirstName() + currentUser.getLastName());
                msg.setImageMessage(url.toString());
                msg.setTimeAdded("2016/11/16");
                msg.setTextMessage("");
                msg.setComments(null);

                firebaseDatabaseReference.child("messages").child(userSessionId + "--Message" + count + "").setValue(msg);

                getMessages();
            }
        });
    }

    public String getPath(Uri uri) {
        String[] projection = {MediaStore.Images.Media.DATA};
        Cursor cursor = managedQuery(uri, projection, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }

    private void getMessages() {
        messagesDbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                msgArrayList = new ArrayList<Messages>();
                count = 0;
                for (DataSnapshot data : dataSnapshot.getChildren()) {
                    Messages msg = data.getValue(Messages.class);
                    if (msg.getUid().equalsIgnoreCase(userSessionId)) {
                        count++;
                    } else {
                        msgArrayList.add(msg);
                    }
                }

                adapter = new ListViewAdapter
                        (ChatRoomActivity.this, R.layout.userlist, msgArrayList);
                userListView.setAdapter(adapter);
                adapter.setNotifyOnChange(true);

               /* userListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Intent showExpenseIntent = new Intent(ChatRoomActivity.this, MessagesActivity.class);
                        Bundle expenseBundle = new Bundle();
                        expenseBundle.putSerializable(DISPLAY_USER, usersArrayList.get(position));
                        showExpenseIntent.putExtras(expenseBundle);
                        startActivity(showExpenseIntent);
                        finish();
                    }
                })*/;


            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }


}

