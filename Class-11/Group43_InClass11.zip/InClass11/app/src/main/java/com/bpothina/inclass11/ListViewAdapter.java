package com.bpothina.inclass11;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by BhaBhaHP on 11/14/2016.
 */

public class ListViewAdapter extends ArrayAdapter<Messages> {

    List<Messages> userData;
    Context mContext;
    int mResource;
    Messages user;

    public ListViewAdapter(Context context, int resource, List<Messages> users) {
        super(context, resource, users);
        this.mContext = context;
        this.userData = users;
        this.mResource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(mResource, parent, false);
        }

        user = userData.get(position);
        convertView.setLongClickable(true);

        if(!user.getImageMessage().isEmpty()) {
            ImageView imageView = (ImageView) convertView.findViewById(R.id.imagechatview);
            /*byte[] decodedString = Base64.decode(user.getImageMessage(), Base64.DEFAULT);
            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            imageView.setImageBitmap(decodedByte);*/

            Picasso.with(mContext).load(user.getImageMessage()).into(imageView);

            TextView textViewExpenseName = (TextView) convertView.findViewById(R.id.textChat);
            textViewExpenseName.setText(user.getFullName() + user.getTimeAdded());
        } else {
            TextView textViewExpenseName = (TextView) convertView.findViewById(R.id.textChat);
            textViewExpenseName.setText(user.getTextMessage() + "\n" + user.getFullName() + user.getTimeAdded());
        }

        return convertView;
    }
}