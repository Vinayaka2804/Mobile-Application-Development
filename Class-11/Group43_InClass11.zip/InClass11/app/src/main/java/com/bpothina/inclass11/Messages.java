package com.bpothina.inclass11;

import android.support.v4.app.NotificationCompat;

import java.io.Serializable;
import java.util.List;

/**
 * Created by BhaBhaHP on 11/14/2016.
 */

public class Messages implements Serializable {

    private String fullName;
    private String uid;
    private String textMessage;
    private String imageMessage;
    private String timeAdded;
    private List<String> comments;

    public Messages(String fullName, String uid, String textMessage, String imageMessage, String timeAdded, List<String> comments) {
        this.fullName = fullName;
        this.uid = uid;
        this.textMessage = textMessage;
        this.imageMessage = imageMessage;
        this.timeAdded = timeAdded;
        this.comments = comments;
    }

    public Messages() {

    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getTextMessage() {
        return textMessage;
    }

    public void setTextMessage(String textMessage) {
        this.textMessage = textMessage;
    }

    public String getImageMessage() {
        return imageMessage;
    }

    public void setImageMessage(String imageMessage) {
        this.imageMessage = imageMessage;
    }

    public String getTimeAdded() {
        return timeAdded;
    }

    public void setTimeAdded(String timeAdded) {
        this.timeAdded = timeAdded;
    }

    public List<String> getComments() {
        return comments;
    }

    public void setComments(List<String> comments) {
        this.comments = comments;
    }

    @Override
    public String toString() {
        return "Messages{" +
                "fullName='" + fullName + '\'' +
                ", uid='" + uid + '\'' +
                ", textMessage='" + textMessage + '\'' +
                ", imageMessage='" + imageMessage + '\'' +
                ", timeAdded='" + timeAdded + '\'' +
                ", comments=" + comments +
                '}';
    }
}
