/*
    Walter Harmon
    Walter Starke
    Nicholas Brooks
    Vinayaka Narayan
    Inclass 05
    Photos
 */
package com.example.durhamharmon.inclass05;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URI;
import java.net.URL;



public class MainActivity extends Activity {
int index;
    String[] arrKeywords = {"UNCC", "Android", "Winter", "Aurora", "Wonders"};
    String[] arrURL;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText txtSearch = (EditText) findViewById(R.id.txtSearch);
        Button btnGo = (Button) findViewById(R.id.btnGo);
        ImageButton btnLeft = (ImageButton) findViewById(R.id.btnLeft);
        ImageButton btnRight = (ImageButton) findViewById(R.id.btnRight);
        ImageView imgShow = (ImageView) findViewById(R.id.imgShow);

        final AlertDialog.Builder searchTerms = new AlertDialog.Builder(MainActivity.this);
        searchTerms.setTitle("Choose A Keyword");
        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(
                MainActivity.this,
                android.R.layout.select_dialog_singlechoice);

        for(int i = 0; i < arrKeywords.length; i++)
        {
            arrayAdapter.add(arrKeywords[i]);
        }

        searchTerms.setAdapter(
                arrayAdapter,
                new DialogInterface.OnClickListener()

                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String strName = arrayAdapter.getItem(which);
                        String initialString = "http://dev.theappsdr.com/apis/photos/index.php?keyword=";
                        StringBuilder urlString = new StringBuilder();
                        urlString.append(initialString).append(strName);
                        new getLinks().execute(urlString.toString());
                        txtSearch.setText(strName.toString());

                    }
                });

        btnGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isConnected()) {
                    searchTerms.show();
                }
                else
                    Toast.makeText(MainActivity.this, "Not Connected to Network", Toast.LENGTH_SHORT).show();
            }
        });
        btnLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decreaseIndex();
                new getImage().execute(arrURL);
            }
        });
        btnRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                increaseIndex();
                new getImage().execute(arrURL);
            }
        });
        //new getLinks().execute("http://dev.theappsdr.com/apis/photos/index.php?keyword=uncc")
;
    }

    public class getLinks extends AsyncTask<String, Void, String[]>{
ProgressDialog pdURL = new ProgressDialog(MainActivity.this);
        @Override
        protected void onPostExecute(String[] strings) {
            super.onPostExecute(strings);
            index = 1;
            new getImage().execute(strings);

            pdURL.dismiss();
        }

        @Override
        protected String[] doInBackground(String... params) {

            URL url = null;
            try {
                url = new URL(params[0]);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection con = null;
            try {
                con = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                con.setRequestMethod("GET");
            } catch (ProtocolException e) {
                e.printStackTrace();
            }
            try {
                con.connect();
            } catch (IOException e) {
                e.printStackTrace();
            }

            int statusCode = 0;
            try {
                statusCode = con.getResponseCode();
            } catch (IOException e) {
                e.printStackTrace();
            }

            if(statusCode == HttpURLConnection.HTTP_OK)
            {
                try {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    String line = reader.readLine();
                    while(line != null){
                        sb.append(line);
                        line = reader.readLine();
                    }
                    //Log.d("demo",sb.toString());

                    arrURL = sb.toString().split(";");

                    for(int i = 0; i <arrURL.length; i++)
                    {
                        Log.d("split", arrURL[i].toString());

                    }



                } catch (IOException e) {
                    e.printStackTrace();
                }
            }


            return arrURL;
        }
        @Override
        protected void  onPreExecute(){
            super.onPreExecute();
            pdURL.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            pdURL.setTitle("Loading Dictionary ...");
            pdURL.show();
        }
    }
    public class getImage extends AsyncTask<String, Void, Bitmap>{
        ProgressDialog pdURL = new ProgressDialog(MainActivity.this);

        @Override
        protected Bitmap doInBackground(String... params) {
            publishProgress();


           try {
               URL url = new URL(params[index]);
               HttpURLConnection con = (HttpURLConnection) url.openConnection();
               con.setRequestMethod("GET");
               InputStream in = con.getInputStream();
               Bitmap image = BitmapFactory.decodeStream(in);
               return image;

           } catch (ProtocolException e) {
               e.printStackTrace();
           } catch (MalformedURLException e) {
               e.printStackTrace();
           } catch (IOException e) {
               e.printStackTrace();
           }
            return null;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            ImageView imgShow = (ImageView) findViewById(R.id.imgShow);
            imgShow.setImageBitmap(bitmap);
            pdURL.dismiss();
        }
        @Override
        protected void  onPreExecute(){
            super.onPreExecute();
            pdURL.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            pdURL.setTitle("Loading Photo ...");
            pdURL.show();
        }
    }

    public void increaseIndex() {
        index++;
        if(index > arrURL.length - 1 ){
            index = 1;
        }
        Log.d("increase", String.valueOf(index));
    }
    public void decreaseIndex() {
        index--;
        if(index == 0){
            index = arrURL.length - 1;
        }
        Log.d("decrease", String.valueOf(index));
    }
    public boolean isConnected(){
        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = cm.getActiveNetworkInfo();
        if(info != null && info.isConnected())
        {
            return true;
        }
        return false;
    }
}
