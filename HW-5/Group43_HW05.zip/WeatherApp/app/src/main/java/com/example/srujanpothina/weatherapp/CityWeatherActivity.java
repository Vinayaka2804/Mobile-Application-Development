/*
Group 43_HW5 - Bharat Pothina, Vinayaka Narayan
 CityWeatherActivity.java
 */
package com.example.srujanpothina.weatherapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class CityWeatherActivity extends AppCompatActivity implements GetHourlyApiData.IData {

    public static String NEWS_DETAILS = "NewsDetails";
    public static String LOCATION_INFO = "CurrentLocation";
    public static String MAX_MIN_TEMP = "MaxMinTemperature";
    public static final String HOURYLY_COMMON_URL = "http://api.wunderground.com/api/9f5f46af65a922d8/hourly/q/";
    public static final String JSON_EXTENSION = ".json";
    public static final String SEPERATOR = "/";
    String[] currentLocationInfo;
    String hourlyWeatherApiUrl;
    ArrayList<Weather> hourlyList = new ArrayList<Weather>();
    String errorMsg = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_city_weather);

        currentLocationInfo = getIntent().getStringArrayExtra(MainActivity.CITY_INFO);
        StringBuilder urlBuilder = new StringBuilder(HOURYLY_COMMON_URL);
        hourlyWeatherApiUrl = (urlBuilder.append(currentLocationInfo[1])
                .append(SEPERATOR)
                .append(currentLocationInfo[0])
                .append(JSON_EXTENSION))
                .toString();

        new GetHourlyApiData(CityWeatherActivity.this).execute(hourlyWeatherApiUrl);
    }

    @Override
    public void getHourlyWeather(HashMap<String, ArrayList<Weather>> resultMap) {
        for(Map.Entry<String, ArrayList<Weather>> result : resultMap.entrySet()) {
            String key = result.getKey();
            if(key.equals("DATA")){
                hourlyList = result.getValue();
            } else if (key.equals("NOERROR")) {
                errorMsg = "SUCCESS";
            } else {
                errorMsg = key;
            }
        }
        ListView listView = (ListView) findViewById(R.id.hourlyTempListView);
        if(errorMsg.equals("SUCCESS") && !hourlyList.isEmpty()) {
            HourlyAdapter adapter = new HourlyAdapter(this, R.layout.hourly_weather_layout, hourlyList);
            ((TextView) findViewById(R.id.cityLocationLabel)).setText(
                    "Current Location: "
                            .concat(currentLocationInfo[0].replaceAll("_", " "))
                            .concat(", ")
                            .concat(currentLocationInfo[1]));
            listView.setAdapter(adapter);
        } else {
            Toast.makeText(CityWeatherActivity.this, errorMsg.concat(". Please wait, Navigating back..."), Toast.LENGTH_LONG).show();
            CountDownTimer timer =  new CountDownTimer(5000, 1000) {
                TextView errorLbl = (TextView)findViewById(R.id.cityLocationLabel);
                public void onTick(long millisUntilFinished) {
                }
                public void onFinish() {
                    Intent i = new Intent(CityWeatherActivity.this, MainActivity.class);
                    startActivity(i);
                    finish();
                }
            };
            timer.start();
        }

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ArrayList<Integer> temperatures = new ArrayList<Integer>();
                for (Weather weather : hourlyList) {
                    temperatures.add(Integer.parseInt(weather.getTemperature()));
                }
                Intent detailsIntent = new Intent(CityWeatherActivity.this, DetailsActivity.class);
                detailsIntent.putExtra(NEWS_DETAILS, hourlyList.get(position));
                detailsIntent.putExtra(LOCATION_INFO,
                        (currentLocationInfo[0].replaceAll("_", " ")).concat(", ").concat(currentLocationInfo[1]));
                detailsIntent.putExtra(MAX_MIN_TEMP,
                        (Collections.max(temperatures).toString()).concat("_").concat(Collections.min(temperatures).toString()));
                startActivity(detailsIntent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflator = getMenuInflater();
        inflator.inflate(R.menu.favorite_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.Favorites:
                SharedPreferences mypref = getSharedPreferences("Weather", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = mypref.edit();

                Set<String> favoritesSet = null;
                String favMsg = "";
                if(mypref.contains("Favorites")){
                    favoritesSet = mypref.getStringSet("Favorites", null);
                }
                Set<String> newFavoritesSet = favoritesSet;
                if (newFavoritesSet != null && newFavoritesSet.size() > 0) {
                    boolean updateFlag = false;
                    String updateEntry = "";
                    StringBuilder sb = null;

                    for (String favorite : newFavoritesSet) {
                        if (favorite.contains(currentLocationInfo[1] + "&" + currentLocationInfo[0].replaceAll("_", " "))){
                            updateFlag = true;
                            updateEntry = favorite;
                            break;
                        }
                    }
                    if(updateFlag) {
                        newFavoritesSet.remove(updateEntry);
                        String[] entryValues = updateEntry.split("&");
                        sb = new StringBuilder(entryValues[1]);
                        sb.append("&")
                                .append(entryValues[0].replaceAll("_", " "))
                                .append("&")
                                .append(currentDate())
                                .append("&")
                                .append(hourlyList.get(0).getTemperature());
                        newFavoritesSet.add(sb.toString());
                        favMsg = "Updated Favorites Record";
                    } else {
                        sb = new StringBuilder(currentLocationInfo[1]);
                        sb.append("&")
                                .append(currentLocationInfo[0].replaceAll("_", " "))
                                .append("&")
                                .append(currentDate())
                                .append("&")
                                .append(hourlyList.get(0).getTemperature());
                        newFavoritesSet.add(sb.toString());
                        favMsg = "Added to Favorites";
                    }
                } else {
                    newFavoritesSet = new HashSet<String>();
                    StringBuilder sb = new StringBuilder(currentLocationInfo[1]);
                    sb.append("&")
                            .append(currentLocationInfo[0].replaceAll("_", " "))
                            .append("&")
                            .append(currentDate())
                            .append("&")
                            .append(hourlyList.get(0).getTemperature());
                    newFavoritesSet.add(sb.toString());
                    favMsg = "Added to Favorites";
                }

                editor.clear();
                editor.putStringSet("Favorites", newFavoritesSet);
                editor.commit();
                Toast.makeText(CityWeatherActivity.this, favMsg, Toast.LENGTH_LONG).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(CityWeatherActivity.this, MainActivity.class);
        startActivity(i);
        finish();
    }

    private String currentDate() {
        DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
        Date date = new Date();
        return df.format(date);
    }
}
