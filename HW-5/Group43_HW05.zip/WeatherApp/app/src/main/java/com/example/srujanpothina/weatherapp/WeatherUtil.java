/*
Group 43_HW5 - Bharat Pothina, Vinayaka Narayan
WeatherUtil.java
 */

package com.example.srujanpothina.weatherapp;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class WeatherUtil {

    static public class WeatherJSONParser {

        static HashMap<String, ArrayList<Weather>> parseHourlyWeather(String in) throws JSONException {
            HashMap<String, ArrayList<Weather>> resultMap = new HashMap<String, ArrayList<Weather>>();
            ArrayList<Weather> weatherList = new ArrayList<Weather>();
            JSONObject root = new JSONObject(in);
            JSONObject responseJsonObject = root.getJSONObject("response");
            String errorMsg = "NOERROR";

            if (responseJsonObject != null) {
                //Handle error messsage, if any
                if(responseJsonObject.has("error") && responseJsonObject.getJSONObject("error") != null) {
                JSONObject errorJsonObject = responseJsonObject.getJSONObject("error");
                    String errorDescription = errorJsonObject.getString("description");
                    if (errorDescription != null && !errorDescription.trim().isEmpty()) {
                        errorMsg = errorDescription.trim();
                    }
                } else { //Handle the hourly forecast json array
                    JSONArray hourlyForecastJsonArray = root.getJSONArray("hourly_forecast");
                    Weather weather = null;
                    for (int i = 0; i < hourlyForecastJsonArray.length(); i++) {
                        weather = new Weather();
                        JSONObject hourlyForecastJsonObject = hourlyForecastJsonArray.getJSONObject(i);

                        //time
                        JSONObject fctTimeJsonObject = hourlyForecastJsonObject.getJSONObject("FCTTIME");
                        if (fctTimeJsonObject != null && fctTimeJsonObject.getString("civil") != null) {
                            weather.setTime(fctTimeJsonObject.getString("civil").trim());
                        }

                        //temperature
                        JSONObject tempJsonObject = hourlyForecastJsonObject.getJSONObject("temp");
                        if (tempJsonObject != null && tempJsonObject.getString("english") != null) {
                            weather.setTemperature(tempJsonObject.getString("english").trim());
                        }

                        //dewpoint
                        JSONObject dewpointJsonObject = hourlyForecastJsonObject.getJSONObject("dewpoint");
                        if (dewpointJsonObject != null && dewpointJsonObject.getString("english") != null) {
                            weather.setDewpoint(dewpointJsonObject.getString("english").trim());
                        }

                        //clouds
                        weather.setClouds(hourlyForecastJsonObject.getString("condition").trim());

                        //iconurl
                        weather.setIconUrl(hourlyForecastJsonObject.getString("icon_url"));

                        //windspeed
                        JSONObject windSpeedJsonObject = hourlyForecastJsonObject.getJSONObject("wspd");
                        if (windSpeedJsonObject != null && windSpeedJsonObject.getString("english") != null) {
                            weather.setWindSpeed(windSpeedJsonObject.getString("english").trim());
                        }

                        //winddirection
                        JSONObject windDirectionJsonObject = hourlyForecastJsonObject.getJSONObject("wdir");
                        if (windDirectionJsonObject != null && windDirectionJsonObject.getString("dir") != null) {
                            weather.setWindDirection(windDirectionJsonObject.getString("dir").trim());
                        }
                        if (windDirectionJsonObject != null && windDirectionJsonObject.getString("degrees") != null) {
                            weather.setWindDirectionDegrees(windDirectionJsonObject.getString("degrees").trim());
                        }

                        //climateType
                        weather.setClimateType(hourlyForecastJsonObject.getString("wx"));

                        //humidity
                        weather.setHumidity(hourlyForecastJsonObject.getString("humidity"));

                        //feelslike
                        JSONObject feelsLikeJsonObject = hourlyForecastJsonObject.getJSONObject("feelslike");
                        if (feelsLikeJsonObject != null && feelsLikeJsonObject.getString("english") != null) {
                            weather.setFeelsLike(feelsLikeJsonObject.getString("english").trim());
                        }

                        //pressure
                        JSONObject mslpJsonObject = hourlyForecastJsonObject.getJSONObject("mslp");
                        if (mslpJsonObject != null && mslpJsonObject.getString("metric") != null) {
                            weather.setPressure(mslpJsonObject.getString("metric").trim());
                        }
                        weatherList.add(weather);
                    }
                }
            }
            resultMap.put(errorMsg, null);
            resultMap.put("DATA", weatherList);
            return resultMap;
        }
    }
}
