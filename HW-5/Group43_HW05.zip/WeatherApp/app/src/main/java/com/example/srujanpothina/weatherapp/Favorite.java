/*
Group 43_HW5 - Bharat Pothina, Vinayaka Narayan
 Favorite.java
 */

package com.example.srujanpothina.weatherapp;

import java.io.Serializable;

public class Favorite implements Serializable {
    private String state;
    private String city;
    private String updatedDate;
    private String currentTemperature;

    public Favorite(String state, String city, String updatedDate, String currentTemperature) {
        this.state = state;
        this.city = city;
        this.updatedDate = updatedDate;
        this.currentTemperature = currentTemperature;
    }

    public Favorite() {
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getCurrentTemperature() {
        return currentTemperature;
    }

    public void setCurrentTemperature(String currentTemperature) {
        this.currentTemperature = currentTemperature;
    }

    @Override
    public String toString() {
        return "Favorite{" +
                "currentTemperature='" + currentTemperature + '\'' +
                ", updatedDate='" + updatedDate + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                '}';
    }
}
