/*
Group 43_HW5 - Bharat Pothina, Vinayaka Narayan
 DetailsActivity.java
 */
package com.example.srujanpothina.weatherapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class DetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        Weather details = new Weather();
        details = (Weather) getIntent().getSerializableExtra(CityWeatherActivity.NEWS_DETAILS);
        String currentLocation = getIntent().getStringExtra(CityWeatherActivity.LOCATION_INFO);
        String[] maxMinTemp = (getIntent().getStringExtra(CityWeatherActivity.MAX_MIN_TEMP)).split("_");

        ((TextView)findViewById(R.id.detailsCurrentLoc)).setText(currentLocation.concat(" (" + details.getTime() + ")"));
        ImageView iconImage = (ImageView) findViewById(R.id.detailsImageView);
        iconImage.setMinimumHeight(170);
        iconImage.setMinimumWidth(170);
        iconImage.setMaxHeight(170);
        iconImage.setMaxWidth(170);
        Picasso.with(getBaseContext()).load(details.getIconUrl()).into(iconImage);

        ((TextView)findViewById(R.id.detailsTemp)).setText(details.getTemperature().concat("°F"));
        ((TextView)findViewById(R.id.detailsCondition)).setText(details.getClimateType());
        ((TextView)findViewById(R.id.detailsMaxTemp)).setText(maxMinTemp[0].concat(" Fahrenheit"));
        ((TextView)findViewById(R.id.detailsMinTemp)).setText(maxMinTemp[1].concat(" Fahrenheit"));

        ((TextView)findViewById(R.id.detailsFeelsLike)).setText(details.getFeelsLike().concat(" Fahrenheit"));
        ((TextView)findViewById(R.id.detailsHumidity)).setText(details.getHumidity().concat("%"));
        ((TextView)findViewById(R.id.detailsDew)).setText(details.getDewpoint().concat(" Fahrenheit"));
        ((TextView)findViewById(R.id.detailsPressure)).setText(details.getPressure().concat(" hPa"));
        ((TextView)findViewById(R.id.detailsClouds)).setText(details.getClouds());

        ((TextView)findViewById(R.id.detailsWinds))
                .setText(details.getWindSpeed().concat(" mph, ").concat(details.getWindDirectionDegrees())
                .concat("° ").concat("West"));
    }
}