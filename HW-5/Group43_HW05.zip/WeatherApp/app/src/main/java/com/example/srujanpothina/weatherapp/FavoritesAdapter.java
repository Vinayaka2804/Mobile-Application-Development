/*
Group 43_HW5 - Bharat Pothina, Vinayaka Narayan
FavoritesAdapter.java
 */

package com.example.srujanpothina.weatherapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class FavoritesAdapter extends ArrayAdapter<Favorite> {
    Context mContext;
    List<Favorite> mObjects;
    int mResource;

    public FavoritesAdapter(Context context, int resource, List<Favorite> objects) {
        super(context, resource, objects);
        this.mContext = context;
        this.mObjects = objects;
        this.mResource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.favorite_locations_layout, parent, false);
        }

        Favorite favorite = mObjects.get(position);
        TextView textView = (TextView) convertView.findViewById(R.id.favLocation);
        textView.setText(favorite.getCity().concat(", ").concat(favorite.getState()));

        TextView textView2 = (TextView) convertView.findViewById(R.id.favDetail);
        textView2.setText(favorite.getCurrentTemperature().concat("° F").concat("\n")
                .concat("Updated on: ").concat(favorite.getUpdatedDate()));

        return convertView;
    }
}

