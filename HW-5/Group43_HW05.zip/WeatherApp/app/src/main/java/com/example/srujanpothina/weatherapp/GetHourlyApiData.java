/*
Group 43_HW5 - Bharat Pothina, Vinayaka Narayan
GetHourlyApiData.java
 */

package com.example.srujanpothina.weatherapp;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;

public class GetHourlyApiData extends AsyncTask<String, Void, HashMap<String, ArrayList<Weather>>> {

    CityWeatherActivity cityWeatherActivity;
    ProgressDialog weatherLoadingProgress;
    ArrayList<Weather> hourlyWeather = new ArrayList<Weather>();
    HashMap<String, ArrayList<Weather>> apiResult = new HashMap<String, ArrayList<Weather>>();

    public GetHourlyApiData(CityWeatherActivity activity)
    {
        cityWeatherActivity = activity;
    }

    public GetHourlyApiData() {
    }

    @Override
    protected HashMap<String, ArrayList<Weather>> doInBackground(String... params) {
        URL url = null;
        try {
            url = new URL(params[0]);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.connect();

            int responseStatusCode = con.getResponseCode();
            if(responseStatusCode == HttpURLConnection.HTTP_OK)
            {
                BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line= reader.readLine();
                while(line!=null)
                {
                    sb.append(line);
                    line=reader.readLine();
                }
                apiResult = WeatherUtil.WeatherJSONParser.parseHourlyWeather(sb.toString());
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return apiResult;
    }

    @Override
    protected void onPreExecute()
    {
        super.onPreExecute();
        weatherLoadingProgress = new ProgressDialog(cityWeatherActivity);
        weatherLoadingProgress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        weatherLoadingProgress.setTitle("Loading Hourly Data");
        weatherLoadingProgress.show();
    }

    @Override
    protected void onPostExecute(HashMap<String, ArrayList<Weather>> resultMap)
    {
        super.onPostExecute(resultMap);
        weatherLoadingProgress.dismiss();
        cityWeatherActivity.getHourlyWeather(resultMap);
    }

    static public interface IData {
        public void getHourlyWeather(HashMap<String, ArrayList<Weather>> resultMap);
    }
}
