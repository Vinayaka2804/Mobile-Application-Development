/*
Group 43_HW5 - Bharat Pothina, Vinayaka Narayan
MainActivity.java
 */

package com.example.srujanpothina.weatherapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.w3c.dom.Text;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    public static final String CITY_INFO = "CityInfo";
    public static final int GET_WEATHER_CODE = 100;
    public final static String DEFAULT = "DEFAULT";
    String city;
    String state;
    String[] currentLocationInfo;
    Set<String> favoritesSet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences sharedPref = getSharedPreferences("Weather", Context.MODE_PRIVATE);
        if (sharedPref.contains("Favorites")) {
            Set<String> testSet = null;
            favoritesSet = sharedPref.getStringSet("Favorites", testSet);
            if (favoritesSet == null || favoritesSet.isEmpty()) {
                Log.d("Favorites key is empty", "Empty");
                ((TextView)findViewById(R.id.noFavoritesText)).setVisibility(View.VISIBLE);
                ((TextView)findViewById(R.id.favoritesLabel)).setVisibility(View.INVISIBLE);
                ((ListView) findViewById(R.id.favoritesListView)).setVisibility(View.INVISIBLE);
            } else {
                ArrayList<Favorite> favorites = new ArrayList<Favorite>();
                for (String favStr : favoritesSet) {
                    String[] fav = favStr.split("&");
                    Favorite favorite = new Favorite(fav[0], fav[1], fav[2], fav[3]);
                    favorites.add(favorite);
                }
                ((TextView)findViewById(R.id.noFavoritesText)).setVisibility(View.INVISIBLE);
                ((TextView)findViewById(R.id.favoritesLabel)).setVisibility(View.VISIBLE);
                assignFavoritesList(favorites);
            }
        } else {
            Log.d("No favorites", "");
            ((TextView)findViewById(R.id.noFavoritesText)).setVisibility(View.VISIBLE);
            ((TextView)findViewById(R.id.favoritesLabel)).setVisibility(View.INVISIBLE);
            ((ListView) findViewById(R.id.favoritesListView)).setVisibility(View.INVISIBLE);
        }

        //On click of Submit
        findViewById(R.id.submitButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Get entered City and State
                EditText cityText = (EditText) findViewById(R.id.cityText);
                city = cityText.getText().toString().trim().replaceAll(" ", "_");
                EditText stateText = (EditText) findViewById(R.id.stateText);
                state = stateText.getText().toString().trim().replaceAll(" ", "_");
                boolean isInputEmpty = false;
                if (city.isEmpty()) {
                    cityText.setError("City cannot be blank");
                    isInputEmpty = true;
                }
                if (state.isEmpty()) {
                    stateText.setError("State cannot be blank");
                    isInputEmpty = true;
                }

                if(!isInputEmpty) {
                    currentLocationInfo = new String[]{city, state};
                    Intent i = new Intent(MainActivity.this, CityWeatherActivity.class);
                    i.putExtra(CITY_INFO, currentLocationInfo);
                    startActivity(i);
                }
            }
        });
    }

    private void assignFavoritesList(final ArrayList<Favorite> result) {
        final ListView listView = (ListView) findViewById(R.id.favoritesListView);
        final FavoritesAdapter adapter = new FavoritesAdapter(this, R.layout.favorite_locations_layout, result);
        listView.setAdapter(adapter);
        adapter.setNotifyOnChange(true);
        listView.setVisibility(View.VISIBLE);

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Favorite removedFavorite = result.get(position);
                adapter.remove(removedFavorite);
                adapter.notifyDataSetChanged();
                Toast.makeText(MainActivity.this, "City Deleted", Toast.LENGTH_LONG).show();
                boolean isRemoved = false;
                String removedStr = "";
                for(String favoriteStr : favoritesSet) {
                    removedStr = removedFavorite.getState()
                                        .concat("&")
                                        .concat(removedFavorite.getCity())
                                        .concat("&")
                                        .concat(removedFavorite.getUpdatedDate())
                                        .concat("&")
                                        .concat(removedFavorite.getCurrentTemperature());
                    if(favoriteStr.equals(removedStr)){
                        isRemoved = true;
                    }
                }
                if(isRemoved){
                    favoritesSet.remove(removedStr);
                    SharedPreferences sharedPref = getSharedPreferences("Weather", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.clear();
                    editor.putStringSet("Favorites", favoritesSet);
                    editor.commit();
                    if(favoritesSet.isEmpty()) {
                        ((TextView)findViewById(R.id.favoritesLabel)).setVisibility(View.INVISIBLE);
                        ((ListView) findViewById(R.id.favoritesListView)).setVisibility(View.INVISIBLE);
                        ((TextView)findViewById(R.id.noFavoritesText)).setVisibility(View.VISIBLE);
                    }
                }
                return true;
            }
        });
    }
}
