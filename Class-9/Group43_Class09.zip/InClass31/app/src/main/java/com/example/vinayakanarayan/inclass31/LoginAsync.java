package com.example.vinayakanarayan.inclass31;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONException;

import java.io.IOException;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by Vinayaka Narayan on 10/31/2016.
 */
public class LoginAsync extends AsyncTask<String,Void,String> {

    LoginActivity activity;
    Response responseVal;

    public LoginAsync(LoginActivity activity)
    {
        this.activity = activity;
    }

    String token;
    @Override
    protected String doInBackground(String... params) {

        OkHttpClient client = new OkHttpClient();

        RequestBody formBody = new FormBody.Builder()
                .add("email", params[0])
                .add("password",params[1])
                .build();

        Request request = new Request.Builder()
                .url("http://ec2-54-166-14-133.compute-1.amazonaws.com/api/login")
                .post(formBody)
                .build();
        try {
            responseVal = client.newCall(request).execute();
            token = responseVal.body().string();
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            token=SignupJsonParser.SignupUtil.parsesignup(token);
            Log.d("Our Token",token);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return token;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        activity.getToken(token);
    }

    static interface IData {
        void getToken(String token);
    }
}
