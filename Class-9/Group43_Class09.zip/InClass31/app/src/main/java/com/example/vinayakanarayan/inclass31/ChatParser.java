package com.example.vinayakanarayan.inclass31;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Vinayaka Narayan on 10/31/2016.
 */
public class ChatParser {

    static public class SignupUtil
    {
        static ArrayList<Chat> parsesignup(String in) throws JSONException
        {
            ArrayList<Chat> chats = new ArrayList<Chat>();
            JSONObject root = new JSONObject(in);

            if(root.has("status")&&(root.getString("status").equals("ok")))
            {
                Log.d("Token in parser",root.getString("status"));
               JSONArray array = root.getJSONArray("messages");

                for(int i = 0; i<array.length(); i++){
                    JSONObject obj = array.getJSONObject(i);
                    Chat chat = new Chat();
                    chat.setMessageUserName(obj.getString("UserFname"));
                    chat.setMessage(obj.getString("Comment"));
                    chat.setTime(obj.getString("CreatedAt"));
                    chat.setImageName(obj.getString("FileThumbnailId"));
                    chats.add(chat);
                }


            }
            return  chats;
        }


    }

}

