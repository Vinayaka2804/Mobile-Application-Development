package com.example.vinayakanarayan.inclass31;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import org.ocpsoft.prettytime.PrettyTime;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created by Vinayaka Narayan on 10/31/2016.
 */
public class ChatAdapter extends ArrayAdapter {

    ArrayList<Chat> mytunes = new ArrayList<Chat>();
    Context context;
    int mresourse;
    public ChatAdapter(Context context, int resource, ArrayList<Chat> itunes)
    {
        super(context, resource, itunes);
        this.context=context;
        this.mytunes = itunes;
        this.mresourse=resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if(convertView==null) {
            LayoutInflater inflator = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView= inflator.inflate(mresourse, parent, false);
        }
        Chat chat = mytunes.get(position);
        TextView listmessage = (TextView) convertView.findViewById(R.id.listmessage);
        listmessage.setText(chat.getMessage());

        TextView name = (TextView) convertView.findViewById(R.id.namemessage);
        name.setText(chat.getMessageUserName());

        TextView time = (TextView) convertView.findViewById(R.id.timemessage);

        String dateStr = chat.getTime();
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        try {
            startDate = (Date)formatter.parse(dateStr);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        PrettyTime p = new PrettyTime(startDate);
        String formattedTime = p.format(new Date(System.currentTimeMillis() + 1000*60*10));

        time.setText(formattedTime);

        //ImageView image = (ImageView) convertView.findViewById(R.id.imageView);


        /*




        Chat itune = mytunes.get(position);
        ImageView myupperimage = (ImageView)convertView.findViewById(R.id.chatname);
        ImageView priceimageview= (ImageView)convertView.findViewById(R.id.imageViewprice);


        TextView chatname = (TextView) convertView.findViewById(R.id.chatname);
        String image = itune.getApp_thumbnail();
        Picasso.with(context).load(image).into(myupperimage);

        //setting price image
        String price = itune.getApp_price();
        Log.d("This is the price",price);

        TextView lowertext= (TextView) convertView.findViewById(R.id.lowertext);
        lowertext.setText(itune.getApp_price());


        title.setText(itune.getApp_name());*/
        return convertView;

    }
}
