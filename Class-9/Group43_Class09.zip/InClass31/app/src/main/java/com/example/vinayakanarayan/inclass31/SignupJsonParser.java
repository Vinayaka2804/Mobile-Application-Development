package com.example.vinayakanarayan.inclass31;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by Vinayaka Narayan on 10/31/2016.
 */
public class SignupJsonParser {

    static public class SignupUtil
    {
        static String parsesignup(String in) throws JSONException
        {
            JSONObject root = new JSONObject(in);

            if(root.has("status")&&(root.getString("status").equals("ok")))
            {
                Log.d("Token in parser",root.getString("status"));
               return root.getString("token");

            }
            return  null;
        }


    }

}

