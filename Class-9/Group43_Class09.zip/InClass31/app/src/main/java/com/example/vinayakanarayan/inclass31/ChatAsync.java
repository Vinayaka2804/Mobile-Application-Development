package com.example.vinayakanarayan.inclass31;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by Vinayaka Narayan on 10/31/2016.
 */
public class ChatAsync extends AsyncTask<String,Void,ArrayList<Chat>> {

    AppCompatActivity activity;
    Response responseVal;
    String token;

    public ChatAsync(AppCompatActivity activity)
    {
        this.activity = activity;
    }

    ArrayList<Chat> chats = new ArrayList<Chat>();
    @Override
    protected ArrayList<Chat> doInBackground(String... params) {
        String signup= params[0];
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .header("Authorization", "BEARER " + signup)
                .url("http://ec2-54-166-14-133.compute-1.amazonaws.com/api/messages")
                .get()
                .build();
        try {
            responseVal = client.newCall(request).execute();
            token = responseVal.body().string();
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            chats=ChatParser.SignupUtil.parsesignup(token);
            Log.d("chats list:",chats.toString());

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return chats;
    }

    @Override
    protected void onPostExecute(ArrayList<Chat> s) {
        super.onPostExecute(s);
        if(activity.getClass().equals(MainActivity.class)) {
            MainActivity mainActivity = (MainActivity) activity;
            mainActivity.getChats(s);
        } else {
            ChatActivity chatActivity = (ChatActivity) activity;
            chatActivity.getChats(s);
        }
    }

    static interface IData {
        void getChats(ArrayList<Chat> token);
    }
}
