package com.example.vinayakanarayan.inclass31;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONException;

import java.io.IOException;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by Vinayaka Narayan on 10/31/2016.
 */
public class AddMessageAsync extends AsyncTask<String,Void,Void> {

    ChatActivity activity;


    public AddMessageAsync(ChatActivity activity) {
        this.activity = activity;
    }

    String token;

    @Override
    protected Void doInBackground(String... params) {
        String msg = params[0];
        OkHttpClient client = new OkHttpClient();

        RequestBody formBody = new FormBody.Builder()
                .add("Type", "TEXT")
                .add("Comment", msg)
                .build();

        Request request = new Request.Builder()
                .header("Authorization", "BEARER " + params[1])
                .url("http://ec2-54-166-14-133.compute-1.amazonaws.com/api/message/add")
                .post(formBody)
                .build();
        try {
            client.newCall(request).execute();

        } catch (IOException e) {
            e.printStackTrace();
        }


        return null;
    }
}

