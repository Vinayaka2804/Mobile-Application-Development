package com.example.vinayakanarayan.inclass31;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

/**
 * Created by Vinayaka Narayan on 10/31/2016.
 */
public class Chat implements Parcelable {

    private String messageUserName, message, time, imageName;

    public Chat(){

    }

    public Chat(String messageUserName, String message, String time, String imageName) {

        this.messageUserName = messageUserName;
        this.message = message;
        this.time = time;
        this.imageName = imageName;
    }

    private Chat(Parcel in) {
        this.messageUserName = in.readString();
        this.message = in.readString();
        this.time = in.readString();
        this.imageName = in.readString();

    }


    public String getMessageUserName() {
        return messageUserName;
    }

    public void setMessageUserName(String messageUserName) {
        this.messageUserName = messageUserName;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    @Override
    public String toString() {
        return "Chat{" +
                ", messageUserName='" + messageUserName + '\'' +
                ", message='" + message + '\'' +
                ", time='" + time + '\'' +
                ", imageName='" + imageName + '\'' +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {


        dest.writeString(messageUserName);
        dest.writeString(message);
        dest.writeString(time);
        dest.writeString(imageName);

    }

    public static final Parcelable.Creator<Chat> CREATOR = new Parcelable.Creator<Chat>() {
        @Override
        public Chat createFromParcel(Parcel in) {
            return new Chat(in);
        }

        @Override
        public Chat[] newArray(int size) {
            return new Chat[size];
        }
    };
}
