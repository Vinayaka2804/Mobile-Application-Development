package com.example.vinayakanarayan.inclass31;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class ChatActivity extends AppCompatActivity implements ChatAsync.IData{

    ListView mylist;
    ArrayList<Chat> chats;
    SharedPreferences shred;
    SharedPreferences.Editor edit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        String signedUserName = getIntent().getStringExtra("signedUser");
        chats = getIntent().getParcelableArrayListExtra("chatlist");
        ((TextView)findViewById(R.id.chatname)).setText(signedUserName);
        Log.d("chats.activity", chats.size() + "");

        findViewById(R.id.imageButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shred = getSharedPreferences("Fav", Context.MODE_PRIVATE);
                edit = shred.edit();
                edit.clear();
                edit.commit();
                Intent i = new Intent(ChatActivity.this, LoginActivity.class);
                startActivity(i);
            }
        });

        mylist = (ListView)findViewById(R.id.listView);
        ChatAdapter adapter = new ChatAdapter(this,R.layout.chatmessages, chats);
        mylist.setAdapter(adapter);
        adapter.setNotifyOnChange(true);
        ((ImageButton)findViewById(R.id.addmessageimagbutton)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = ((EditText)findViewById(R.id.chattext)).getText().toString();
                if(text != null && !text.isEmpty()) {
                    shred = getSharedPreferences("Fav", Context.MODE_PRIVATE);
                    String tokenval = shred.getString("Token", "");
                    String[] params= {text, tokenval};

                    new AddMessageAsync(ChatActivity.this).execute(params);

                    new ChatAsync(ChatActivity.this).execute(tokenval);

                    mylist = (ListView)findViewById(R.id.listView);
                    ChatAdapter adapter = new ChatAdapter(ChatActivity.this,R.layout.chatmessages, chats);
                    mylist.setAdapter(adapter);
                    adapter.setNotifyOnChange(true);

                }
            }
        });


        /*((ImageButton)findViewById(R.id.addmessageimagbutton)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = ((EditText)findViewById(R.id.chattext)).getText().toString();
                if(text != null && !text.isEmpty()) {
                    shred = getSharedPreferences("Fav", Context.MODE_PRIVATE);
                    String tokenval = shred.getString("Token", "");
                    String[] params= {text, tokenval};

                    new AddMessageAsync(ChatActivity.this).execute(params);

                    new ChatAsync(ChatActivity.this).execute(tokenval);

                    mylist = (ListView)findViewById(R.id.listView);
                    ChatAdapter adapter = new ChatAdapter(ChatActivity.this,R.layout.chatmessages, chats);
                    mylist.setAdapter(adapter);
                    adapter.setNotifyOnChange(true);

                }
            }
        });*/



    }

    @Override
    public void getChats(ArrayList<Chat> token) {
        chats = token;
    }
}
