package com.example.vinayakanarayan.inclass31;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity implements  LoginAsync.IData{

    String tokenval;
    SharedPreferences shred;
    SharedPreferences.Editor edit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        findViewById(R.id.signupbtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(LoginActivity.this, MainActivity.class);
                i.putExtra("temp", "signup");
                startActivity(i);
            }
        });

        findViewById(R.id.loginbtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText email = (EditText) findViewById(R.id.emailText);
                EditText pwd = (EditText) findViewById(R.id.pwdText);
                String[] params = {email.getText().toString(), pwd.getText().toString()};
                new LoginAsync(LoginActivity.this).execute(params);

            }
        });

    }

    @Override
    public void getToken(String token) {
        tokenval = token;
        shred = getSharedPreferences("Fav", Context.MODE_PRIVATE);

        edit = shred.edit();
        edit.putString("Token", token);
        //edit.putString("UserName", signedUser);
        edit.commit();
        Intent i = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(i);
    }
}
