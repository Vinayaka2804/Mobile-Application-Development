package com.example.vinayakanarayan.inclass31;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONException;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by Vinayaka Narayan on 10/31/2016.
 */
public class SignupAsync extends AsyncTask<Signup,Void,String> {

    MainActivity activity;
    Response responseVal;

    public SignupAsync(MainActivity activity)
    {
        this.activity = activity;
    }

    String token;
    @Override
    protected String doInBackground(Signup... params) {
        Signup signup= params[0];
        OkHttpClient client = new OkHttpClient();

        RequestBody formBody = new FormBody.Builder()
                .add("email", signup.getEmail())
                .add("password",signup.getPwd())
                .add("fname",signup.getFname())
                .add("lname",signup.getLname())
                .build();

        Request request = new Request.Builder()
                .url("http://ec2-54-166-14-133.compute-1.amazonaws.com/api/signup")
                .post(formBody)
                .build();
        try {
            responseVal = client.newCall(request).execute();
            token = responseVal.body().string();
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            token=SignupJsonParser.SignupUtil.parsesignup(token);
            Log.d("Our Token",token);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return token;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        activity.getToken(token);
    }

    static interface IData {
        void getToken(String token);
    }
}
