package com.example.vinayakanarayan.inclass31;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.LoginFilter;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity implements SignupAsync.IData, ChatAsync.IData{

    public String token;
    SharedPreferences shred;
    SharedPreferences.Editor edit;
    ArrayList<Chat> chatList = new ArrayList<Chat>();
    String signedUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        shred = getSharedPreferences("Fav", Context.MODE_PRIVATE);
        if(shred != null && shred.contains("Token")) {
            new ChatAsync(MainActivity.this).execute(shred.getString("Token", ""));

        } else {
            if(getIntent() != null && getIntent().getStringExtra("temp")!= null && getIntent().getStringExtra("temp").equals("signup")){

            } else {
                Intent i = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(i);
            }
        }




        findViewById(R.id.signbtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fname = ((EditText)findViewById(R.id.fname)).getText().toString();
                String lname = ((EditText)findViewById(R.id.lname)).getText().toString();
                signedUser = fname.concat(" ").concat(lname);
                String email = ((EditText)findViewById(R.id.email)).getText().toString();
                String pwd = ((EditText)findViewById(R.id.password)).getText().toString();
                String repeat = ((EditText)findViewById(R.id.repeatpassword)).getText().toString();

                Signup signup = new Signup(fname, lname, email, pwd);

                if(pwd.equals(repeat)) {
                    new SignupAsync(MainActivity.this).execute(signup);
                }
            }
        });
    }

    @Override
    public void getToken(String result) {
        token = result;
        shred = getSharedPreferences("Fav", Context.MODE_PRIVATE);
        edit = shred.edit();
        edit.putString("Token", token);
        edit.putString("UserName", signedUser);
        edit.commit();

        new ChatAsync(MainActivity.this).execute(token);
    }

    @Override
    public void getChats(ArrayList<Chat> chats) {
        chatList= chats;
        Intent i = new Intent(MainActivity.this, ChatActivity.class);
        i.putExtra("signedUser", shred.getString("UserName", ""));
        i.putParcelableArrayListExtra("chatlist", chatList);
        startActivity(i);
    }
}
